// مكونات UI: Toast، Modal، Drawer، Confirm، Skeleton، Empty، مخططات SVG
import { el, icon } from './core.js';

// ---------- Toast ----------
export function toast(msg, type = 'ok', ms = 3200) {
  const box = document.getElementById('toasts');
  if (!box) return;
  const t = el(`<div class="toast ${type}">${icon(type === 'err' ? 'alert' : type === 'info' ? 'bell' : 'checkCircle')}<span>${msg}</span></div>`);
  box.appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity .3s'; setTimeout(() => t.remove(), 320); }, ms);
}

// ---------- Modal ----------
export function openModal({ title, body, footer, wide = false, onClose }) {
  const root = document.getElementById('modal-root');
  const ov = el(`<div class="overlay">
    <div class="modal ${wide ? 'wide' : ''}">
      <div class="modal-head"><h3>${title}</h3><button class="icon-btn" data-close>${icon('x')}</button></div>
      <div class="modal-body"></div>
      ${footer ? `<div class="modal-foot">${footer}</div>` : ''}
    </div>
  </div>`);
  const bodyEl = ov.querySelector('.modal-body');
  if (typeof body === 'string') bodyEl.innerHTML = body;
  else if (body) bodyEl.appendChild(body);
  ov.querySelector('[data-close]').onclick = () => close(ov);
  ov.addEventListener('mousedown', (e) => { if (e.target === ov) close(ov); });
  const onKey = (e) => { if (e.key === 'Escape') { close(ov); document.removeEventListener('keydown', onKey); } };
  document.addEventListener('keydown', onKey);
  function close(node) { node.remove(); document.removeEventListener('keydown', onKey); onClose && onClose(); }
  ov.__close = () => close(ov);
  root.appendChild(ov);
  return ov;
}
export function closeModal(node) { node && node.__close && node.__close(); }

// ---------- Drawer (من الجانب) ----------
export function openDrawer({ title, body, wide = false, onClose }) {
  const root = document.getElementById('drawer-root');
  const ov = el(`<div class="overlay" style="padding:0;align-items:stretch;justify-content:flex-end;background:transparent;backdrop-filter:none;pointer-events:none">
    <div style="position:absolute;inset:0" data-backdrop style2=""></div>
    <div class="drawer" style="pointer-events:auto">${wide ? '' : ''}
      <div class="drawer-head"><h3 style="font-weight:800;font-size:1.02rem">${title}</h3><button class="icon-btn" data-close>${icon('x')}</button></div>
      <div class="drawer-body"></div>
    </div>
  </div>`);
  // خلفية معتمة
  const bd = ov.querySelector('[data-backdrop]');
  bd.style.cssText = 'position:absolute;inset:0;background:rgba(10,15,25,.45);backdrop-filter:blur(2px);pointer-events:auto;';
  const bodyEl = ov.querySelector('.drawer-body');
  if (typeof body === 'string') bodyEl.innerHTML = body;
  else if (body) bodyEl.appendChild(body);
  ov.querySelector('[data-close]').onclick = () => close();
  bd.onclick = () => close();
  const onKey = (e) => { if (e.key === 'Escape') { close(); document.removeEventListener('keydown', onKey); } };
  document.addEventListener('keydown', onKey);
  function close() { ov.remove(); document.removeEventListener('keydown', onKey); onClose && onClose(); }
  root.appendChild(ov);
  return ov;
}

// ---------- Confirm ----------
export function confirmDialog(message, { title = 'تأكيد الحذف', danger = true, okText = 'حذف' } = {}) {
  return new Promise((resolve) => {
    const ov = openModal({
      title,
      body: `<p style="font-size:.95rem;line-height:1.8">${message}</p>`,
      footer: `<button class="btn" id="cf-no">إلغاء</button><button class="btn ${danger ? 'btn-danger' : 'btn-primary'}" id="cf-yes">${okText}</button>`,
      onClose: () => resolve(false),
    });
    let done = false;
    const finish = (v) => { if (done) return; done = true; ov.__close(); resolve(v); };
    ov.querySelector('#cf-no').onclick = () => finish(false);
    ov.querySelector('#cf-yes').onclick = () => finish(true);
    ov.__close = () => { if (!done) { done = true; resolve(false); } ov.remove(); };
  });
}

// ---------- Skeleton / Empty ----------
export function skeleton(n = 4, h = 84) {
  return `<div style="display:grid;gap:12px">${Array.from({ length: n }).map(() => `<div class="skel" style="height:${h}px;border-radius:14px"></div>`).join('')}</div>`;
}
export function emptyState(iconName, title, sub, cta) {
  return `<div class="empty">
    <div class="ic">${icon(iconName)}</div>
    <h4>${title}</h4>
    ${sub ? `<p>${sub}</p>` : ''}
    ${cta || ''}
  </div>`;
}

// ---------- Dropdown (موائم عام) ----------
export function bindDropdown(btnSel, menuHtml, { align = 'end' } = {}) {
  const btn = document.querySelector(btnSel);
  if (!btn) return;
  let menu = null;
  const close = () => { menu && menu.remove(); menu = null; btn.classList.remove('open'); };
  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    if (menu) { close(); return; }
    menu = el(`<div class="dd-menu" style="inset-inline-end:${align === 'end' ? '0' : 'auto'};inset-inline-start:${align === 'start' ? '0' : 'auto'}">${menuHtml}</div>`);
    btn.parentElement.appendChild(menu);
    menu.addEventListener('click', (e) => e.stopPropagation());
  });
  document.addEventListener('click', close, { once: true });
  return close;
}

// ---------- Charts (SVG خالص) ----------
export function barChart({ labels, values, color = 'var(--primary)', height = 170, unit = '' }) {
  const max = Math.max(...values, 1);
  const W = 600, H = height, padB = 26, padT = 12;
  const n = values.length || 1;
  const bw = Math.min(38, (W - 20) / n - 8);
  const bw2 = W / n;
  let bars = '';
  values.forEach((v, i) => {
    const h = Math.round(((H - padB - padT) * v) / max);
    const x = i * bw2 + (bw2 - bw) / 2;
    const y = H - padB - h;
    const lbl = String(labels[i]).includes('-') ? String(labels[i]).slice(5, 10) : String(labels[i]).slice(0, 14);
    bars += `<rect x="${x}" y="${y}" width="${bw}" height="${Math.max(h, v > 0 ? 3 : 0)}" rx="5" fill="${color}" opacity="${v > 0 ? 1 : .18}"/>
      <text x="${x + bw / 2}" y="${H - 8}" text-anchor="middle" font-size="10" fill="var(--faint)" font-weight="600">${lbl}</text>
      ${v > 0 ? `<text x="${x + bw / 2}" y="${y - 5}" text-anchor="middle" font-size="10.5" fill="var(--muted)" font-weight="700">${v}${unit}</text>` : ''}`;
  });
  return `<svg viewBox="0 0 ${W} ${H}">${bars}</svg>`;
}

export function lineChart({ labels, series, height = 190, colors = ['var(--primary)', 'var(--gold)'] }) {
  const W = 600, H = height, padB = 26, padT = 14, padL = 8, padR = 8;
  const max = Math.max(...series.flatMap((s) => s.values), 1);
  const n = labels.length || 1;
  const x = (i) => padL + (i * (W - padL - padR)) / Math.max(n - 1, 1);
  const y = (v) => H - padB - ((H - padB - padT) * v) / max;
  let out = `<line x1="${padL}" y1="${H - padB}" x2="${W - padR}" y2="${H - padB}" stroke="var(--border)" stroke-width="1"/>`;
  // خط إرشادي
  for (let g = 1; g <= 3; g++) {
    const gy = padT + ((H - padB - padT) * g) / 4;
    out += `<line x1="${padL}" y1="${gy}" x2="${W - padR}" y2="${gy}" stroke="var(--border)" stroke-width=".6" stroke-dasharray="3 4" opacity=".7"/>`;
  }
  series.forEach((s, si) => {
    const pts = s.values.map((v, i) => `${x(i)},${y(v)}`).join(' ');
    const area = `${x(0)},${H - padB} ${pts} ${x(n - 1)},${H - padB}`;
    out += `<polygon points="${area}" fill="${colors[si % colors.length]}" opacity=".09"/>`;
    out += `<polyline points="${pts}" fill="none" stroke="${colors[si % colors.length]}" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>`;
    s.values.forEach((v, i) => { if (n <= 31 || i % Math.ceil(n / 15) === 0) out += `<circle cx="${x(i)}" cy="${y(v)}" r="2.6" fill="${colors[si % colors.length]}"/>`; });
  });
  labels.forEach((l, i) => {
    const lbl = String(l).includes('-') ? String(l).slice(5, 10) : String(l).slice(0, 12);
    if (n <= 14 || i % Math.ceil(n / 10) === 0) out += `<text x="${x(i)}" y="${H - 8}" text-anchor="middle" font-size="9.5" fill="var(--faint)" font-weight="600">${lbl}</text>`;
  });
  return `<svg viewBox="0 0 ${W} ${H}">${out}</svg>`;
}

export function donut({ segments, size = 170, thickness = 26, centerLabel, centerSub }) {
  const total = segments.reduce((s, x) => s + x.value, 0) || 1;
  const R = (size - thickness) / 2;
  const C = 2 * Math.PI * R;
  let offset = 0;
  let arcs = '';
  segments.forEach((s) => {
    const frac = s.value / total;
    const dash = frac * C;
    arcs += `<circle cx="${size / 2}" cy="${size / 2}" r="${R}" fill="none" stroke="${s.color}" stroke-width="${thickness}"
      stroke-dasharray="${dash} ${C - dash}" stroke-dashoffset="${-offset}" transform="rotate(-90 ${size / 2} ${size / 2})" stroke-linecap="butt"/>`;
    offset += dash;
  });
  return `<svg viewBox="0 0 ${size} ${size}" style="max-width:${size}px;margin:0 auto;display:block">
    ${total === 0 || segments.every((s) => !s.value) ? `<circle cx="${size/2}" cy="${size/2}" r="${R}" fill="none" stroke="var(--border)" stroke-width="${thickness}"/>` : arcs}
    <text x="50%" y="48%" text-anchor="middle" font-size="${size / 7}" font-weight="800" fill="var(--text)">${centerLabel ?? ''}</text>
    <text x="50%" y="60%" text-anchor="middle" font-size="${size / 13}" font-weight="600" fill="var(--muted)">${centerSub ?? ''}</text>
  </svg>`;
}

export function progressRing(value, size = 86, color = 'var(--primary)') {
  const R = (size - 10) / 2;
  const C = 2 * Math.PI * R;
  const frac = Math.min(Math.max(Number(value) || 0, 0), 100) / 100;
  return `<svg viewBox="0 0 ${size} ${size}" style="width:${size}px;height:${size}px">
    <circle cx="${size/2}" cy="${size/2}" r="${R}" fill="none" stroke="var(--border)" stroke-width="8"/>
    <circle cx="${size/2}" cy="${size/2}" r="${R}" fill="none" stroke="${color}" stroke-width="8" stroke-linecap="round"
      stroke-dasharray="${C * frac} ${C}" transform="rotate(-90 ${size/2} ${size/2})"/>
    <text x="50%" y="53%" text-anchor="middle" font-size="${size/4.4}" font-weight="800" fill="var(--text)">${value}%</text>
  </svg>`;
}
