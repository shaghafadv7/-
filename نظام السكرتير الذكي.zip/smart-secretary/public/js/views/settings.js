// الإعدادات — حساب، شركة، نظام، إشعارات، نسخ احتياطي
import { api } from '../api.js';
import { state } from '../state.js';
import { icon, esc, avatarHtml } from '../core.js';
import { toast, openModal, confirmDialog } from '../ui.js';

const TABS = [
  ['account', 'الحساب', 'user'],
  ['company', 'الشركة', 'building'],
  ['system', 'النظام', 'settings'],
  ['notify', 'الإشعارات', 'bell'],
  ['backup', 'النسخ الاحتياطي', 'database'],
];

export async function render(root, ctx) {
  const q = ctx.query;
  const tab = TABS.find(([k]) => k === q.get('tab')) ? q.get('tab') : 'account';
  const u = state.user;
  const s = state.settings || {};
  root.innerHTML = `
    <div class="page-head"><div><div class="page-title">الإعدادات</div><div class="page-sub">خصص تجربتك على السكرتير الذكي</div></div></div>
    <div class="settings-tabs">${TABS.map(([k, l, ic]) => `<button class="chip ${tab === k ? 'active' : ''}" data-tab="${k}">${icon(ic)} ${l}</button>`).join('')}</div>
    <div id="st-body"><div class="skel" style="height:300px"></div></div>`;
  root.querySelectorAll('[data-tab]').forEach((b) => {
    b.onclick = () => {
      const p = new URLSearchParams(location.hash.split('?')[1] || '');
      p.set('tab', b.dataset.tab);
      location.hash = '#/settings?' + p.toString();
    };
  });
  const box = root.querySelector('#st-body');
  if (tab === 'account') renderAccount(box, u);
  if (tab === 'company') renderCompany(box);
  if (tab === 'system') renderSystem(box, s);
  if (tab === 'notify') renderNotify(box, s);
  if (tab === 'backup') renderBackup(box);
}

function card(title, inner, perm = true) {
  return `<div class="card"><div class="card-head"><h3>${title}</h3></div><div class="card-pad">${inner}</div></div>`;
}

function renderAccount(box, u) {
  box.innerHTML = `
    <div class="grid-2">
      <div>
        ${card('الملف الشخصي', `
          <div class="flex aic gap-14 mb-14">${avatarHtml(u.name, u.avatar, 'lg')}
            <div>${u.avatar ? `<label class="btn btn-sm" style="cursor:pointer">${icon('upload')} تغيير الصورة<input type="file" id="av-up" accept="image/*" class="hidden"/></label>` : ''}
            <div class="xs faint mt-8">JPG أو PNG حتى 3 م.ب</div></div>
          </div>
          <div class="field"><label>الاسم</label><input class="input" id="uf-name" value="${esc(u.name)}"/></div>
          <div class="field"><label>البريد الإلكتروني</label><input class="input" value="${esc(u.email)}" disabled style="opacity:.6"/></div>
          <div class="field"><label>رقم الجوال</label><input class="input" id="uf-phone" value="${esc(u.phone || '')}"/></div>
          <button class="btn btn-primary" id="uf-save">${icon('check')} حفظ</button>`)}
        <div class="mt-14">${card('تغيير كلمة المرور', `
          <div class="field"><label>كلمة المرور الحالية</label><input type="password" class="input" id="pw-old"/></div>
          <div class="field"><label>كلمة المرور الجديدة (6+ أحرف)</label><input type="password" class="input" id="pw-new"/></div>
          <button class="btn btn-primary" id="pw-save">${icon('shield')} تغيير</button>`)}
        </div>
      </div>
      <div>${card('الجلسة الحالية', `
        <div class="kv">
          <span class="k">الحساب</span><span>${esc(u.email)}</span>
          <span class="k">الدور</span><span>${u.role === 'admin' ? 'مدير النظام' : u.role === 'secretary' ? 'سكرتير' : 'موظف'}</span>
          <span class="k">الصلاحيات</span><span>${(u.permissions || []).length} صلاحية</span>
          <span class="k">آخر دخول</span><span>${u.last_login_at || '—'}</span>
        </div>
        <div class="divider"></div>
        <button class="btn btn-danger" id="uf-logout">${icon('logout')} تسجيل الخروج</button>`)}
      </div>
    </div>`;
  box.querySelector('#uf-save')?.addEventListener('click', async () => {
    await api.put('/api/auth/profile', { name: box.querySelector('#uf-name').value, phone: box.querySelector('#uf-phone').value });
    state.user.name = box.querySelector('#uf-name').value;
    toast('تم حفظ الملف الشخصي');
  });
  box.querySelector('#pw-save')?.addEventListener('click', async () => {
    try {
      await api.put('/api/auth/password', { oldPassword: box.querySelector('#pw-old').value, newPassword: box.querySelector('#pw-new').value });
      toast('تم تغيير كلمة المرور');
      box.querySelector('#pw-old').value = ''; box.querySelector('#pw-new').value = '';
    } catch (e) { /* toast handled */ }
  });
  box.querySelector('#av-up')?.addEventListener('change', async (e) => {
    const f = e.target.files[0];
    if (!f) return;
    const fd = new FormData(); fd.append('avatar', f);
    const r = await api.post('/api/settings/avatar', fd);
    state.user.avatar = r.avatar;
    toast('تم تحديث الصورة');
    renderAccount(box, state.user);
  });
  box.querySelector('#uf-logout')?.addEventListener('click', () => import('../state.js').then((s) => s.logout()));
}

async function renderCompany(box) {
  let co = state.company || {};
  try { const r = await api.get('/api/settings'); co = r.company; } catch { /* */ }
  const canEdit = state.perm('settings.edit');
  box.innerHTML = `<div style="max-width:640px">${card('بيانات الشركة', `
    <div class="field"><label>اسم الشركة</label><input class="input" id="co-name" value="${esc(co.name || '')}" ${canEdit ? '' : 'disabled'}/></div>
    <div class="form-grid">
      <div class="field"><label>رقم الهاتف</label><input class="input" id="co-phone" value="${esc(co.phone || '')}" ${canEdit ? '' : 'disabled'}/></div>
      <div class="field"><label>البريد</label><input class="input" id="co-email" value="${esc(co.email || '')}" ${canEdit ? '' : 'disabled'}/></div>
    </div>
    <div class="field"><label>العنوان</label><input class="input" id="co-addr" value="${esc(co.address || '')}" ${canEdit ? '' : 'disabled'}/></div>
    ${canEdit ? '<button class="btn btn-primary" id="co-save">' + icon('check') + ' حفظ</button>' : '<div class="xs faint">صلاحية التعديل: مدير النظام فقط</div>'}`)}</div>`;
  box.querySelector('#co-save')?.addEventListener('click', async () => {
    const r = await api.put('/api/settings', { company: { name: box.querySelector('#co-name').value, phone: box.querySelector('#co-phone').value, email: box.querySelector('#co-email').value, address: box.querySelector('#co-addr').value } });
    state.company = r.company;
    toast('تم حفظ بيانات الشركة');
  });
}

function renderSystem(box, s) {
  const sys = window.__systemSettings || {};
  box.innerHTML = `
    <div class="grid-2">
      ${card('المظهر', `
        <div class="field"><label>الوضع</label>
          <div class="seg" style="width:100%"><button data-th="light" class="${(s.theme || 'light') === 'light' ? 'active' : ''}" style="flex:1">${icon('sun')} فاتح</button>
          <button data-th="dark" class="${s.theme === 'dark' ? 'active' : ''}" style="flex:1">${icon('moon')} داكن</button></div></div>
        <div class="field"><label>اللون الرئيسي</label>
          <div class="flex gap-10">
            ${[['emerald', '#0e8074'], ['navy', '#1e3a5f'], ['violet', '#6d5bd0'], ['amber', '#b45309'], ['rose', '#be185d']].map(([k, c]) =>
              `<span class="color-dot ${s.primary === k ? 'active' : ''}" data-pc="${k}" style="background:${c}" title="${k}"></span>`).join('')}
          </div></div>`) }
      ${card('اللغة والمنطقة', `
        <div class="field"><label>اللغة</label>
          <div class="seg" style="width:100%"><button data-lang="ar" class="${(s.language || 'ar') === 'ar' ? 'active' : ''}" style="flex:1">العربية</button>
          <button data-lang="en" class="${s.language === 'en' ? 'active' : ''}" style="flex:1">English</button></div>
          <div class="xs faint mt-8">الواجهة العربية كاملة — الإنجليزية قيد التوسع للوحدات العامة</div></div>
        <div class="field"><label>المنطقة الزمنية</label><input class="input" value="Asia/Riyadh (GMT+3)" disabled style="opacity:.6"/></div>
        <div class="field"><label>العملة</label><input class="input" id="sy-cur" value="${esc(sys.currency || 'SAR')}" ${state.perm('settings.edit') ? '' : 'disabled'}/></div>
        ${state.perm('settings.edit') ? '<button class="btn btn-primary" id="sy-save">' + icon('check') + ' حفظ النظام</button>' : ''}`)}
    </div>`;
  // جلب إعدادات النظام
  api.get('/api/settings', { silent: true }).then((r) => { window.__systemSettings = r.system; }).catch(() => {});
  box.querySelectorAll('[data-th]').forEach((b) => (b.onclick = () => import('../state.js').then((s) => s.saveUserSettings({ theme: b.dataset.th }))));
  box.querySelectorAll('[data-pc]').forEach((b) => (b.onclick = () => import('../state.js').then((s) => s.saveUserSettings({ primary: b.dataset.pc }))));
  box.querySelectorAll('[data-lang]').forEach((b) => (b.onclick = () => import('../state.js').then((s) => s.saveUserSettings({ language: b.dataset.lang }))));
  box.querySelector('#sy-save')?.addEventListener('click', async () => {
    const sys2 = window.__systemSettings || {};
    await api.put('/api/settings', { system: { ...sys2, currency: box.querySelector('#sy-cur').value } });
    toast('تم حفظ إعدادات النظام');
  });
}

function renderNotify(box, s) {
  const n = s.notify || {};
  box.innerHTML = `<div style="max-width:640px">${card('تفضيلات الإشعارات', `
    ${[['tasks', 'إشعارات المهام', 'تنبيهات المهام العاجلة والمتأخرة'], ['events', 'إشعارات المواعيد', 'تذكير بالاجتماعات والمواعيد القادمة'], ['followups', 'إشعارات المتابعة', 'تنبيه بالمتابعات المستحقة']].map(([k, l, d]) => `
      <div class="flex aic jcb" style="padding:10px 0;border-bottom:1px solid var(--border)">
        <div><div class="bold small">${l}</div><div class="xs muted">${d}</div></div>
        <label class="switch"><input type="checkbox" data-nt="${k}" ${n[k] !== false ? 'checked' : ''}/><span class="tr"></span></label>
      </div>`).join('')}
    <div class="flex aic jcb" style="padding:10px 0">
      <div><div class="bold small">إشعارات المتصفح</div><div class="xs muted">تنبيهات النظام خارج التطبيق (Notification API)</div></div>
      <label class="switch"><input type="checkbox" id="nt-browser" ${n.browser ? 'checked' : ''}/><span class="tr"></span></label>
    </div>`)}</div>`;
  box.querySelectorAll('[data-nt]').forEach((cb) => {
    cb.onchange = () => import('../state.js').then((s) => s.saveUserSettings({ notify: { ...(s.settings.notify || {}), [cb.dataset.nt]: cb.checked } }));
  });
  box.querySelector('#nt-browser').onchange = async (e) => {
    if (e.target.checked) {
      if (!('Notification' in window)) { toast('المتصفح لا يدعم الإشعارات', 'err'); e.target.checked = false; return; }
      const perm = await Notification.requestPermission();
      if (perm !== 'granted') { toast('لم يتم منح إذن الإشعارات', 'err'); e.target.checked = false; return; }
    }
    import('../state.js').then((s) => s.saveUserSettings({ notify: { ...(s.settings.notify || {}), browser: e.target.checked } }));
  };
}

function renderBackup(box) {
  const canExport = state.perm('settings.edit');
  const canRestore = state.perm('users.manage');
  box.innerHTML = `
    <div class="grid-3" style="max-width:900px">
      <div class="card card-pad" style="text-align:center">
        <div class="stat-icon si-primary" style="margin:0 auto 12px">${icon('downloadCloud')}</div>
        <div class="xtr" style="margin-bottom:6px">نسخة احتياطية</div>
        <p class="xs muted" style="margin-bottom:14px">تنزيل كل بياناتك في ملف JSON واحد</p>
        <button class="btn btn-primary" id="bk-dl" ${canExport ? '' : 'disabled'}>${icon('download')} تنزيل النسخة</button>
      </div>
      <div class="card card-pad" style="text-align:center">
        <div class="stat-icon si-warn" style="margin:0 auto 12px">${icon('refresh')}</div>
        <div class="xtr" style="margin-bottom:6px">استعادة</div>
        <p class="xs muted" style="margin-bottom:14px">استبدال كل البيانات بنسخة سابقة (لا رجوع!)</p>
        <label class="btn" style="cursor:pointer" ${canRestore ? '' : 'disabled'}>${icon('upload')} اختيار ملف الاستعادة<input type="file" id="bk-file" accept="application/json" class="hidden"/></label>
      </div>
      <div class="card card-pad" style="text-align:center">
        <div class="stat-icon si-info" style="margin:0 auto 12px">${icon('database')}</div>
        <div class="xtr" style="margin-bottom:6px">تصدير البيانات</div>
        <p class="xs muted" style="margin-bottom:14px">تنزيل نسخة من البيانات للاحتفاظ أو التحليل</p>
        <button class="btn" id="bk-data" ${canExport ? '' : 'disabled'}>${icon('copy')} تصدير JSON</button>
      </div>
    </div>`;
  box.querySelector('#bk-dl')?.addEventListener('click', () => api.download('/api/settings/backup', 'smart-secretary-backup.json').then(() => toast('تم تنزيل النسخة الاحتياطية')));
  box.querySelector('#bk-data')?.addEventListener('click', () => api.download('/api/settings/export-data', 'smart-secretary-data.json').then(() => toast('تم التصدير')));
  box.querySelector('#bk-file')?.addEventListener('change', async (e) => {
    const f = e.target.files[0];
    if (!f) return;
    const ok = await confirmDialog('سيتم استبدال كل البيانات الحالية بالمحتوى في هذا الملف. هل أنت متأكد؟', { title: 'تنبيه استعادة', okText: 'استعادة' });
    if (!ok) return;
    try {
      const text = await f.text();
      const payload = JSON.parse(text);
      const r = await api.post('/api/settings/restore', payload);
      toast('تمت الاستعادة — يُفضل تسجيل الدخول مجددًا');
      setTimeout(() => location.reload(), 1200);
    } catch (err) {
      toast('فشل الاستعادة: ' + err.message, 'err');
    }
  });
}
