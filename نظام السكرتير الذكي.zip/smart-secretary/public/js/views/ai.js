// AI Secretary — مساعد يعمل بالسؤال الطبيعي
import { api } from '../api.js';
import { state, goRoute } from '../state.js';
import { icon, esc, KIND_ICONS } from '../core.js';
import { toast, openModal } from '../ui.js';

const SUGGESTIONS = [
  'ما الأشياء التي يجب أن أتابعها اليوم؟',
  'ما المتابعات المستحقة؟',
  'ما المهام العاجلة أو المتأخرة؟',
  'من ينتظر ردّي؟',
  'ما اجتماعات ومواعيدي القادمة؟',
  'ملخص مصروفات هذا الشهر',
  'حالة أحمد الغامدي',
  'الإنتاجية هذا الأسبوع',
];

export async function render(root, ctx) {
  root.innerHTML = `
    <div class="page-head">
      <div><div class="page-title">المساعد الذكي</div>
      <div class="page-sub">اسأل بالعربية: ملخصات، ترتيب أولويات، استخراج مهام من محاضر، وتلخيص أشخاص ومشاريع</div></div>
      <div class="page-actions">
        <button class="btn" id="ai-day">${icon('sun')} ملخص اليوم</button>
        <button class="btn" id="ai-extract">${icon('sparkles')} استخراج مهام من نص</button>
      </div>
    </div>
    <div class="card" style="height:calc(100vh - 240px);display:flex;flex-direction:column">
      <div class="card-pad" style="flex:1;overflow-y:auto" id="ai-chat">
        <div class="ai-msg bot">${icon('sparkles')} <br/>أهلًا! أنا مساعدك الشخصي. اسألني عن يومك، متابعاتك، مهامك، أو اطلب تلخيصًا — وسأجيب من بياناتك الفعلية.</div>
      </div>
      <div class="card-pad" style="padding:12px 16px">
        <div style="display:flex;gap:6px;overflow-x:auto;padding-bottom:10px">
          ${SUGGESTIONS.map((s) => `<span class="chip" data-sugg="${esc(s)}">${esc(s)}</span>`).join('')}
        </div>
        <div class="input-row">
          <input class="input" id="ai-input" placeholder="اكتب سؤالك… مثال: من ينتظر ردي اليوم؟" style="padding:12px 15px"/>
          <button class="btn btn-primary" id="ai-send" style="padding:0 22px">${icon('send')}</button>
        </div>
      </div>
    </div>`;

  const chat = root.querySelector('#ai-chat');
  const input = root.querySelector('#ai-input');

  const scrollBottom = () => (chat.scrollTop = chat.scrollHeight);

  async function ask(message) {
    if (!message.trim()) return;
    input.value = '';
    chat.insertAdjacentHTML('beforeend', `<div class="ai-msg user">${esc(message)}</div>`);
    scrollBottom();
    const thinking = document.createElement('div');
    thinking.className = 'ai-msg bot';
    thinking.innerHTML = '<span class="skeleton" style="display:inline-block;width:180px;height:16px"></span>';
    chat.appendChild(thinking);
    scrollBottom();
    try {
      const r = await api.post('/api/ai/chat', { message });
      thinking.remove();
      chat.insertAdjacentHTML('beforeend', aiMsgHtml(r));
      scrollBottom();
    } catch (e) {
      thinking.remove();
      if (e.status !== 0) chat.insertAdjacentHTML('beforeend', `<div class="ai-msg bot" style="color:var(--danger)">تعذر الوصول للخادم — حاول مجددًا</div>`);
    }
  }
  root.querySelector('#ai-send').onclick = () => ask(input.value);
  input.onkeydown = (e) => { if (e.key === 'Enter') ask(input.value); };
  root.querySelectorAll('[data-sugg]').forEach((c) => (c.onclick = () => ask(c.dataset.sugg)));

  root.querySelector('#ai-day').onclick = async () => {
    try {
      const r = await api.post('/api/ai/summarize', { scope: 'day' });
      chat.insertAdjacentHTML('beforeend', `<div class="ai-msg bot">${icon('sun')} <b>${esc(r.title)}</b>\n${esc(r.text)}
        <div class="kv mt-8" style="grid-template-columns:1fr 1fr">${r.stats.map((s) => `<span class="k">${esc(s.label)}</span><span class="xtr">${esc(s.value)}</span>`).join('')}</div></div>`);
      scrollBottom();
    } catch { toast('تعذر إنشاء الملخص', 'err'); }
  };

  root.querySelector('#ai-extract').onclick = () => {
    openModal({
      title: `${icon('sparkles')} استخراج مهام من نص`,
      wide: true,
      body: `<p class="small muted mb-8">ألصق محضر اجتماع أو ملاحظة، وسأستخرج المهام المقترحة:</p>
        <textarea class="textarea" id="ex-text" rows="7" placeholder="مثال:\n- إرسال العقد لأحمد الغامدي غدًا\n- إعداد تقرير المبيعات قبل نهاية الأسبوع\nتم الاتفاق على زيادة الميزانية 15%"></textarea>`,
      footer: `<button class="btn" id="ex-cancel">إلغاء</button><button class="btn btn-primary" id="ex-go">${icon('sparkles')} استخراج</button>`,
    });
    const ov = document.querySelector('#modal-root .modal');
    ov.querySelector('#ex-cancel').onclick = () => ov.__close();
    ov.querySelector('#ex-go').onclick = async () => {
      const text = ov.querySelector('#ex-text').value;
      if (!text.trim()) { toast('أدخل النص أولًا', 'info'); return; }
      const r = await api.post('/api/ai/extract-tasks', { text });
      ov.__close();
      if (!r.candidates.length) { toast('لم يتم العثور على مهام واضحة', 'info'); return; }
      const ov2 = openModal({
        title: 'مهام مقترحة — راجعها وأعدّلها',
        wide: true,
        body: `<div style="max-height:50vh;overflow-y:auto">${r.candidates.map((c, i) => `<div class="checkline" data-i="${i}">
          <div class="cb on">${icon('check')}</div>
          <input class="input" style="border:none;background:none;padding:6px 0;font-weight:600" value="${esc(c.text)}"/>
        </div>`).join('')}</div>`,
        footer: `<button class="btn" id="ex2-no">إلغاء</button><button class="btn btn-primary" id="ex2-yes">إنشاء المهام المحددة</button>`,
      });
      ov2.querySelector('#ex2-no').onclick = () => ov2.__close();
      ov2.querySelector('#ex2-yes').onclick = async () => {
        const chosen = [...ov2.querySelectorAll('.checkline')].filter((row) => row.querySelector('.cb').classList.contains('on'))
          .map((row) => ({ title: row.querySelector('input').value }))
          .filter((t) => t.title.trim());
        if (!chosen.length) { toast('اختر مهمة واحدة على الأقل', 'info'); return; }
        for (const t of chosen) await api.post('/api/tasks', { title: t.title, priority: 'medium' });
        ov2.__close();
        toast(`تم إنشاء ${chosen.length} مهمة`);
      };
      ov2.querySelectorAll('.cb').forEach((cb) => (cb.onclick = () => cb.classList.toggle('on')));
    };
  };

  function aiMsgHtml(r) {
    return `<div class="ai-msg bot">${esc(r.reply)}
      ${(r.sections || []).map((s) => `<div class="ai-section">
        <div class="h">${icon(KIND_ICONS[s.icon] || 'circle')} ${esc(s.title)}</div>
        ${s.items.map((it) => `<div class="it" data-go="${esc(it.route || '')}"><div class="bold">${esc(it.title)}</div>${it.sub ? `<div class="s">${esc(it.sub)}</div>` : ''}</div>`).join('')}
      </div>`).join('')}</div>`;
  }
  // ربط العناصر الناقلة بعد كل render — نبقيها معلقة (delegation)
  chat.addEventListener('click', (e) => {
    const it = e.target.closest('[data-go]');
    if (it && it.dataset.go) goRoute(it.dataset.go);
  });
}
