// الملفات والمستندات
import { api, getToken } from '../api.js';
import { state } from '../state.js';
import { icon, esc, fmtDate, FILE_CATS } from '../core.js';
import { emptyState, confirmDialog, toast, openModal } from '../ui.js';
import { fileForm, loadFormOptions } from '../forms.js';

function dlUrl(id) { return `/api/files/${id}/download?tk=${encodeURIComponent(getToken())}`; }
function sizeFmt(n) {
  n = Number(n) || 0;
  if (n > 1024 * 1024) return (n / 1024 / 1024).toFixed(1) + ' م.ب';
  if (n > 1024) return (n / 1024).toFixed(0) + ' ك.ب';
  return n + ' بايت';
}

export async function render(root, ctx) {
  const q = ctx.query;
  root.innerHTML = `
    <div class="page-head">
      <div><div class="page-title">الملفات</div><div class="page-sub" id="fl-sub">مستنداتك منظمة ومربوطة بأعمالك</div></div>
      <div class="page-actions">${state.perm('files.create') ? `<button class="btn btn-primary" id="fl-upload">${icon('upload')} رفع ملف</button>` : ''}</div>
    </div>
    <div class="toolbar">
      <input class="input" id="fl-q" placeholder="بحث بالاسم…" value="${esc(q.get('q') || '')}"/>
      <select class="select" id="fl-cat"><option value="">كل التصنيفات</option>${Object.entries(FILE_CATS).map(([k, v]) => `<option value="${k}" ${q.get('category') === k ? 'selected' : ''}>${v}</option>`).join('')}</select>
    </div>
    <div id="fl-body"><div class="skel" style="height:300px"></div></div>`;
  ['fl-q', 'fl-cat'].forEach((id) => {
    const inp = root.querySelector('#' + id);
    inp.addEventListener(inp.tagName === 'SELECT' ? 'change' : 'input', () => {
      const p = new URLSearchParams(location.hash.split('?')[1] || '');
      const k = id === 'fl-q' ? 'q' : 'category';
      if (inp.value) p.set(k, inp.value); else p.delete(k);
      location.hash = '#/files' + (p.toString() ? '?' + p.toString() : '');
    });
  });
  const upBtn = root.querySelector('#fl-upload');
  if (upBtn) upBtn.onclick = async () => { await loadFormOptions(); const r = await fileForm(); if (r) render(root, ctx); };

  try {
    const p = new URLSearchParams(Object.fromEntries(q.entries()));
    p.set('limit', '60');
    const data = await api.get(`/api/files?${p.toString()}`);
    root.querySelector('#fl-sub').textContent = `${data.total} ملف`;
    const box = root.querySelector('#fl-body');
    if (!data.items.length) { box.innerHTML = emptyState('folder', 'لا ملفات', 'ارفع مستنداتك واربطها بالأشخاص والمشاريع', state.perm('files.create') ? '<button class="btn btn-primary" id="fl-up2">رفع ملف</button>' : '');
      const b = box.querySelector('#fl-up2'); if (b) b.onclick = upBtn.onclick; return; }
    box.innerHTML = `<div class="grid-3">${data.items.map((f) => `
      <div class="card" style="overflow:hidden">
        ${isImage(f.mime) ? `<div style="height:140px;background:var(--surface2);display:flex;align-items:center;justify-content:center;overflow:hidden">
          <img src="${dlUrl(f.id)}" alt="" style="max-height:140px;object-fit:contain"/></div>` : ''}
        <div class="card-pad" style="padding:13px 15px">
          <div class="flex aic gap-10">
            <div class="stat-icon ${f.category === 'contract' ? 'si-danger' : f.category === 'invoice' ? 'si-warn' : f.category === 'report' ? 'si-violet' : 'si-info'}" style="width:40px;height:40px;flex:none">${icon('file')}</div>
            <div style="min-width:0;flex:1">
              <div class="bold small" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${esc(f.original_name)}">${esc(f.original_name)}</div>
              <div class="xs faint">${FILE_CATS[f.category] || f.category} • ${sizeFmt(f.size)} • ${fmtDate(f.created_at)}</div>
            </div>
          </div>
          ${(f.first_name || f.project_name) ? `<div class="xs mt-8" style="color:var(--muted)">${f.first_name ? '👤 ' + esc(f.first_name) : ''}${f.project_name ? ' • 💼 ' + esc(f.project_name) : ''}</div>` : ''}
          <div class="flex gap-6 mt-14">
            <button class="btn btn-sm" data-act="preview" data-id="${f.id}">${icon('eye')} معاينة</button>
            <a class="btn btn-sm" href="${dlUrl(f.id)}" download>${icon('download')}</a>
            ${state.perm('files.edit') ? `<button class="icon-btn" data-act="rename" data-id="${f.id}" title="إعادة تسمية">${icon('edit')}</button>` : ''}
            ${state.perm('files.delete') ? `<button class="icon-btn danger" data-act="del" data-id="${f.id}" title="حذف">${icon('trash')}</button>` : ''}
          </div>
        </div>
      </div>`).join('')}</div>`;
    box.querySelectorAll('[data-act]').forEach((btn) => {
      btn.onclick = async (e) => {
        e.preventDefault();
        const f = data.items.find((x) => x.id === Number(btn.dataset.id));
        const act = btn.dataset.act;
        if (act === 'preview') {
          if (isImage(f.mime)) return window.open(dlUrl(f.id), '_blank');
          openModal({
            title: f.original_name,
            wide: true,
            body: `<div class="kv mb-8"><span class="k">التصنيف</span><span>${FILE_CATS[f.category]}</span>
              <span class="k">الحجم</span><span>${sizeFmt(f.size)}</span>
              <span class="k">أُضيف</span><span>${fmtDate(f.created_at)}${f.uploader ? ' بواسطة ' + esc(f.uploader) : ''}</span>
              ${f.project_name ? `<span class="k">المشروع</span><span>${esc(f.project_name)}</span>` : ''}</div>
              <a class="btn btn-primary" href="${dlUrl(f.id)}" download>${icon('download')} تنزيل الملف</a>`,
          });
        }
        if (act === 'rename') {
          const ov = openModal({ title: 'إعادة تسمية', body: `<div class="field"><label>الاسم الجديد</label><input class="input" id="rn-name" value="${esc(f.original_name)}"/></div>`,
            footer: `<button class="btn" id="rn-no">إلغاء</button><button class="btn btn-primary" id="rn-yes">حفظ</button>` });
          ov.querySelector('#rn-no').onclick = () => ov.__close();
          ov.querySelector('#rn-yes').onclick = async () => {
            await api.patch(`/api/files/${f.id}`, { original_name: ov.querySelector('#rn-name').value });
            ov.__close(); toast('تم إعادة التسمية'); render(root, ctx);
          };
        }
        if (act === 'del') {
          if (await confirmDialog(`حذف «${f.original_name}»؟ سيتم حذفه من القرص أيضًا.`)) {
            await api.del('/api/files/' + f.id);
            render(root, ctx);
          }
        }
      };
    });
  } catch {
    root.querySelector('#fl-body').innerHTML = emptyState('alert', 'تعذر التحميل');
  }
}
function isImage(mime) { return String(mime || '').startsWith('image/'); }
