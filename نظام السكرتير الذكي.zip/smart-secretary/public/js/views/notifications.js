// مركز الإشعارات (صفحة كاملة)
import { api } from '../api.js';
import { state } from '../state.js';
import { icon, esc, relTime, KIND_ICONS, KIND_BG } from '../core.js';
import { emptyState, toast } from '../ui.js';

export async function render(root, ctx) {
  const q = ctx.query;
  const type = q.get('type') || '';
  const unread = q.get('unreadOnly') ? '1' : '';
  root.innerHTML = `
    <div class="page-head">
      <div><div class="page-title">مركز الإشعارات</div><div class="page-sub">تنبيهات مهامك ومواعيدك ومتابعاتك</div></div>
      <div class="page-actions"><button class="btn" id="np-all">${icon('check')} تحديد الكل كمقروء</button></div>
    </div>
    <div class="toolbar">
      <div class="seg">
        <button data-f="" class="${!type && !unread ? 'active' : ''}">الكل</button>
        <button data-u="1" class="${unread ? 'active' : ''}">غير المقروءة</button>
        ${['task', 'meeting', 'reminder', 'followup'].map((t) => `<button data-t="${t}" class="${type === t ? 'active' : ''}">${{ task: 'مهام', meeting: 'اجتماعات', reminder: 'تذكيرات', followup: 'متابعات' }[t]}</button>`).join('')}
      </div>
    </div>
    <div class="card" id="np-body"><div class="skel" style="height:200px"></div></div>`;
  root.querySelectorAll('[data-f], [data-u], [data-t]').forEach((b) => {
    b.onclick = () => {
      const p = new URLSearchParams(location.hash.split('?')[1] || '');
      p.delete('type'); p.delete('unreadOnly');
      if (b.dataset.t) p.set('type', b.dataset.t);
      if (b.dataset.u) p.set('unreadOnly', '1');
      location.hash = '#/notifications' + (p.toString() ? '?' + p.toString() : '');
    };
  });
  root.querySelector('#np-all').onclick = async () => {
    await api.post('/api/notifications/read-all', {});
    state.unread = 0;
    import('../state.js').then((s) => s.renderNotifBadge());
    toast('تم تحديد الكل كمقروء');
    render(root, ctx);
  };
  try {
    const p = new URLSearchParams();
    if (type) p.set('type', type);
    if (unread) p.set('unreadOnly', '1');
    const { items } = await api.get(`/api/notifications?limit=100&${p.toString()}`);
    const box = root.querySelector('#np-body');
    box.innerHTML = items.length ? items.map((n) => {
      const ic = KIND_ICONS[n.type] || 'bell';
      const bg = KIND_BG[n.type] || 'si-primary';
      const route = n.entity ? `#/${n.entity}` : '';
      return `<div class="notif-item ${n.is_read ? '' : 'unread'}" data-id="${n.id}" data-route="${route}" style="border-bottom:1px solid var(--border)">
        <div class="notif-ic ${bg}">${icon(ic)}</div>
        <div style="flex:1;min-width:0"><div class="notif-t">${esc(n.title)}</div>${n.body ? `<div class="notif-b">${esc(n.body)}</div>` : ''}
        <div class="notif-time">${relTime(n.created_at)}</div></div>
        ${n.is_read ? '<span class="xs faint">مقروء</span>' : '<button class="btn btn-sm btn-soft" data-read>' + icon('check') + ' كمقروء</button>'}
      </div>`;
    }).join('') : emptyState('bell', 'لا إشعارات', 'ستظهر هنا تنبيهات المهام والمواعيد والمتابعات');
    box.querySelectorAll('[data-id]').forEach((it) => {
      it.onclick = async (e) => {
        const readBtn = e.target.closest('[data-read]');
        if (readBtn) {
          await api.post(`/api/notifications/${it.dataset.id}/read`, {});
          it.classList.remove('unread');
          readBtn.outerHTML = '<span class="xs faint">مقروء</span>';
          const { count } = await api.get('/api/notifications/unread-count', { silent: true });
          state.unread = count;
          import('../state.js').then((s) => s.renderNotifBadge());
          return;
        }
        await api.post(`/api/notifications/${it.dataset.id}/read`, {}, { silent: true });
        if (it.dataset.route) location.hash = it.dataset.route;
      };
    });
  } catch {
    root.querySelector('#np-body').innerHTML = emptyState('alert', 'تعذر التحميل');
  }
}
