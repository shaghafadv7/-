// المشاريع — بطاقات + Dashboard لكل مشروع
import { api } from '../api.js';
import { state } from '../state.js';
import { icon, esc, fmtDate, fmtMoney, fmtTime, PROJECT_STATUS, TASK_STATUS, PRIORITIES, relDay, KIND_ICONS } from '../core.js';
import { emptyState, confirmDialog, toast, progressRing } from '../ui.js';
import { projectForm, taskForm, loadFormOptions } from '../forms.js';

export async function render(root, ctx, sub) {
  if (sub === 'detail') return renderDetail(root, ctx, ctx.segments[1]);
  root.innerHTML = `
    <div class="page-head">
      <div><div class="page-title">المشاريع</div><div class="page-sub">كل أعمالك في مكان واحد</div></div>
      <div class="page-actions">${state.perm('projects.create') ? `<button class="btn btn-primary" id="pj-add">${icon('plus')} مشروع جديد</button>` : ''}</div>
    </div>
    <div id="pj-body"><div class="skel" style="height:300px"></div></div>`;
  const addBtn = root.querySelector('#pj-add');
  if (addBtn) addBtn.onclick = async () => { await loadFormOptions(); const r = await projectForm(); if (r) render(root, ctx); };
  try {
    const { items } = await api.get('/api/projects');
    const box = root.querySelector('#pj-body');
    if (!items.length) { box.innerHTML = emptyState('briefcase', 'لا مشاريع', 'أنشئ مشروعك الأول لتتبع أعمالك', state.perm('projects.create') ? '<button class="btn btn-primary" id="pj-add2">مشروع جديد</button>' : '');
      const b = box.querySelector('#pj-add2'); if (b) b.onclick = addBtn.onclick; return; }
    box.innerHTML = `<div class="grid-3">${items.map((p) => `
      <div class="card" data-id="${p.id}" style="cursor:pointer;overflow:hidden">
        <div style="height:5px;background:${p.color || 'var(--primary)'}"></div>
        <div class="card-pad">
          <div class="flex aic jcb">
            <div class="xtr" style="font-size:1.02rem">${esc(p.name)}</div>
            <span class="badge ${p.status === 'active' ? 'b-completed' : p.status === 'on_hold' ? 'b-needs' : 'b-completed'}">${PROJECT_STATUS[p.status] || p.status}</span>
          </div>
          <div class="small muted mt-8">${esc([p.client_name, p.due_date ? 'حتى ' + fmtDate(p.due_date) : ''].filter(Boolean).join(' • '))}</div>
          <div class="flex aic gap-14 mt-20">
            ${progressRing(p.progress, 68)}
            <div class="small" style="line-height:2">
              <div class="flex gap-6">${icon('checkSquare')} <span>${p.done_tasks}/${p.total_tasks} مهمة</span></div>
              <div class="flex gap-6">${icon('user')} <span>${p.contact ? esc(p.first_name + (p.last_name || '')) : '—'}</span></div>
              <div class="flex gap-6">${icon('dollar')} <span>مصروفات مرتبطة</span></div>
            </div>
          </div>
          <div class="progress thin mt-14"><div class="bar" style="width:${p.progress}%"></div></div>
        </div>
      </div>`).join('')}</div>`;
    box.querySelectorAll('[data-id]').forEach((c) => (c.onclick = () => (location.hash = `#/projects/${c.dataset.id}`)));
  } catch {
    root.querySelector('#pj-body').innerHTML = emptyState('alert', 'تعذر التحميل');
  }
}

async function renderDetail(root, ctx, id) {
  root.innerHTML = `<div class="skel" style="height:400px"></div>`;
  let d;
  try { d = await api.get(`/api/projects/${id}`); } catch {
    root.innerHTML = emptyState('briefcase', 'المشروع غير موجود', '', '<button class="btn btn-primary" onclick="location.hash=\'#/projects\'">عودة للمشاريع</button>');
    return;
  }
  const p = d.project;
  root.innerHTML = `
    <a href="#/projects" class="btn btn-ghost btn-sm mb-8">${icon('chevR')} عودة للمشاريع</a>
    <div class="card" style="border-inline-start:5px solid ${p.color || 'var(--primary)'}">
      <div class="card-pad">
        <div class="flex aic gap-14 wrap jcb">
          <div style="min-width:240px">
            <div class="flex aic gap-10"><h2 style="font-size:1.4rem;font-weight:800">${esc(p.name)}</h2>
              <span class="badge ${p.status === 'active' ? 'b-completed' : 'b-needs'}">${PROJECT_STATUS[p.status]}</span></div>
            <div class="small muted mt-8">${esc(p.description || '')}</div>
            <div class="flex gap-14 wrap mt-8 small" style="color:var(--muted)">
              ${p.client_name ? `<span class="flex aic gap-6">${icon('building')} ${esc(p.client_name)}</span>` : ''}
              ${p.contact ? `<a href="#/contacts/${p.contact.id}" class="flex aic gap-6" style="color:var(--primary);font-weight:700">${icon('user')} ${esc(p.contact.first_name + (p.contact.last_name || ''))}</a>` : ''}
              ${p.due_date ? `<span class="flex aic gap-6" ${p.due_date < new Date().toISOString().slice(0, 10) && p.status !== 'completed' ? 'style="color:var(--danger);font-weight:700"' : ''}>${icon('clock')} حتى ${fmtDate(p.due_date)} (${relDay(p.due_date)})</span>` : ''}
              ${p.start_date ? `<span class="flex aic gap-6">${icon('calendar')} بدأ ${fmtDate(p.start_date)}</span>` : ''}
            </div>
          </div>
          ${progressRing(p.progress, 92, p.color || 'var(--primary)')}
          <div class="page-actions">
            ${state.perm('projects.edit') ? `<button class="btn" id="pj-edit">${icon('edit')} تعديل</button>` : ''}
            ${state.perm('projects.delete') ? `<button class="btn btn-danger" id="pj-del">${icon('trash')}</button>` : ''}
          </div>
        </div>
        <div class="stat-grid mt-20" style="grid-template-columns:repeat(4,1fr)">
          ${miniStat('checkSquare', `${d.statusCounts.completed}/${countTotal(d)}`, 'مهام مكتملة')}
          ${miniStat('video', d.meetings.length, 'اجتماعات قادمة')}
          ${miniStat('dollar', fmtMoney(d.expenses.total), 'المصروفات')}
          ${miniStat('file', d.files.length, 'ملفات')}
        </div>
      </div>
    </div>
    <div class="flex gap-8 wrap no-print mt-14">
      ${state.perm('tasks.create') ? `<button class="btn btn-soft" id="pj-task">${icon('plus')} مهمة للمشروع</button>` : ''}
    </div>
    <div class="grid-2 mt-14">
      <div>
        <div class="section-title">${icon('checkSquare')} المهام <span class="count">(${countTotal(d)})</span></div>
        <div class="card">
          ${Object.entries(d.statusCounts).filter(([, n]) => n > 0).map(([st, n]) => `<div style="display:flex;align-items:center;gap:10px;padding:10px 16px;border-bottom:1px solid var(--border);font-size:.88rem">
            <span class="badge b-${st}">${TASK_STATUS[st]}</span><span class="muted small">عدد</span><b class="mt-auto" style="margin-inline-start:auto">${n}</b></div>`).join('') || '<div class="empty" style="padding:20px">لا مهام</div>'}
        </div>
        <div class="section-title mt-20">${icon('video')} الاجتماعات القادمة</div>
        <div class="card">
          ${d.meetings.length ? d.meetings.map((m) => `<div class="row-card" data-go="#/meetings">
            <div class="tl-dot kind-meeting">${icon('video')}</div>
            <div class="list-main"><div class="list-t">${esc(m.title)}</div><div class="list-s"><span>${fmtDate(m.start_at)} · ${fmtTime(m.start_at)}</span></div></div>
          </div>`).join('') : '<div class="empty" style="padding:18px">لا اجتماعات قادمة</div>'}
        </div>
        <div class="section-title mt-20">${icon('folder')} أحدث الملفات</div>
        <div class="card">
          ${d.files.length ? d.files.map((f) => `<div class="row-card" data-go="#/files">
            <div class="tl-dot kind-event">${icon('file')}</div>
            <div class="list-main"><div class="list-t">${esc(f.original_name)}</div><div class="list-s"><span>${fmtDate(f.created_at)}</span></div></div>
          </div>`).join('') : '<div class="empty" style="padding:18px">لا ملفات</div>'}
        </div>
      </div>
      <div>
        <div class="section-title">${icon('activity')} خط الزمن</div>
        <div class="card card-pad">
          ${d.timeline.length ? `<div class="timeline">${d.timeline.map((i) => `
            <div class="tl-item" data-route="${i.kind === 'meeting' ? '#/meetings' : i.kind === 'task' ? '#/tasks' : ''}">
              <div class="tl-dot kind-${i.kind === 'meeting' ? 'meeting' : 'task'}">${icon(KIND_ICONS[i.kind] || 'circle')}</div>
              <div class="tl-body"><div class="tl-title">${esc(i.title)}</div><div class="tl-sub"><span>${i.sub}</span><span class="faint">${fmtDate(i.date)}</span></div></div>
            </div>`).join('')}</div>` : '<div class="empty" style="padding:18px">لا نشاط بعد</div>'}
        </div>
        <div class="section-title mt-20">${icon('edit')} أحدث الملاحظات</div>
        <div class="card">
          ${d.notes.length ? d.notes.map((n) => `<div class="row-card" data-go="#/notes">
            <div class="tl-dot kind-reminder">${icon('edit')}</div>
            <div class="list-main"><div class="list-t">${esc(n.title)}</div><div class="list-s"><span>${fmtDate(n.created_at)}</span></div></div>
          </div>`).join('') : '<div class="empty" style="padding:18px">لا ملاحظات</div>'}
        </div>
        ${d.contacts.length ? `<div class="section-title mt-20">${icon('users')} جهات الاتصال</div>
        <div class="card card-pad small" style="line-height:2.2">${d.contacts.map((c) => `<a href="#/contacts/${c.id}" style="color:var(--primary);font-weight:700">${esc(c.first_name + (c.last_name ? ' ' + c.last_name : ''))}</a> <span class="muted">— ${esc(c.job_title || '')}</span><br/>`).join('')}</div>` : ''}
      </div>
    </div>`;
  root.querySelectorAll('[data-go]').forEach((r) => { if (r.dataset.go) r.onclick = () => (location.hash = r.dataset.go); });
  const editBtn = root.querySelector('#pj-edit');
  if (editBtn) editBtn.onclick = async () => { const r = await projectForm(p); if (r) renderDetail(root, ctx, id); };
  const delBtn = root.querySelector('#pj-del');
  if (delBtn) delBtn.onclick = async () => {
    if (await confirmDialog('حذف المشروع؟ بياناته المرتبطة ستبقى لكن تفقد الارتباط.')) {
      await api.del('/api/projects/' + id);
      location.hash = '#/projects';
    }
  };
  const taskBtn = root.querySelector('#pj-task');
  if (taskBtn) taskBtn.onclick = async () => { await loadFormOptions(); const r = await taskForm({ project_id: p.id }); if (r) renderDetail(root, ctx, id); };
}
function countTotal(d) { return Object.values(d.statusCounts).reduce((a, b) => a + b, 0); }
function miniStat(ic, val, label) {
  return `<div class="stat-card" style="cursor:default"><div class="stat-icon si-primary">${icon(ic)}</div>
    <div><div class="stat-value" style="font-size:1.25rem">${val}</div><div class="stat-label">${label}</div></div></div>`;
}
