// إدارة المهام — List + Kanban (Drag & Drop) + Calendar
import { api } from '../api.js';
import { state } from '../state.js';
import { icon, esc, fmtDate, fmtTime, relDay, PRIORITIES, TASK_STATUS, todayISO } from '../core.js';
import { emptyState, confirmDialog, toast } from '../ui.js';
import { taskForm, loadFormOptions, setContactOpts, setProjectOpts, contactOpts, projectOpts } from '../forms.js';

const COLUMNS = [
  { key: 'new', label: 'جديدة', color: 'var(--info)' },
  { key: 'in_progress', label: 'قيد التنفيذ', color: 'var(--primary)' },
  { key: 'waiting', label: 'بانتظار الرد', color: 'var(--warn)' },
  { key: 'completed', label: 'مكتملة', color: 'var(--ok)' },
  { key: 'cancelled', label: 'ملغاة', color: 'var(--faint)' },
];

export async function render(root, ctx) {
  const q = ctx.query;
  const view = q.get('view') || 'kanban';
  root.innerHTML = `
    <div class="page-head">
      <div><div class="page-title">المهام</div><div class="page-sub" id="ts-sub">نظم أعمالك اليومية</div></div>
      <div class="page-actions">
        <div class="tabs" id="ts-tabs">
          <button class="tab" data-v="kanban">${icon('grid')} كانبان</button>
          <button class="tab" data-v="list">${icon('list')} قائمة</button>
          <button class="tab" data-v="cal">${icon('calendar')} تقويم</button>
        </div>
        ${state.perm('tasks.create') ? `<button class="btn btn-primary" id="ts-add">${icon('plus')} مهمة</button>` : ''}
      </div>
    </div>
    <div class="toolbar" id="ts-toolbar">
      <input class="input" id="ts-q" placeholder="بحث في المهام…" value="${esc(q.get('q') || '')}"/>
      <select class="select" id="ts-status"><option value="">كل الحالات</option>${Object.entries(TASK_STATUS).map(([k, v]) => `<option value="${k}" ${q.get('status') === k ? 'selected' : ''}>${v}</option>`).join('')}</select>
      <select class="select" id="ts-prio"><option value="">كل الأولويات</option>${Object.entries(PRIORITIES).map(([k, v]) => `<option value="${k}" ${q.get('priority') === k ? 'selected' : ''}>${v}</option>`).join('')}</select>
      <select class="select" id="ts-due">
        <option value="">كل المواعيد</option>
        <option value="today" ${q.get('due') === 'today' ? 'selected' : ''}>اليوم</option>
        <option value="overdue" ${q.get('due') === 'overdue' ? 'selected' : ''}>متأخرة</option>
        <option value="week" ${q.get('due') === 'week' ? 'selected' : ''}>هذا الأسبوع</option>
      </select>
      <select class="select" id="ts-proj"><option value="">كل المشاريع</option>${(window.__projects || []).map((p) => `<option value="${p.id}" ${q.get('project') === String(p.id) ? 'selected' : ''}>${esc(p.name)}</option>`).join('')}</select>
    </div>
    <div id="ts-body"><div class="skel" style="height:300px"></div></div>`;

  root.querySelectorAll('#ts-tabs .tab').forEach((b) => {
    b.classList.toggle('active', b.dataset.v === view);
    b.onclick = () => { location.hash = '#/tasks?view=' + b.dataset.v; };
  });
  const setQ = (k, v) => {
    const params = new URLSearchParams(location.hash.split('?')[1] || '');
    if (v) params.set(k, v); else params.delete(k);
    const s = params.toString();
    location.hash = '#/tasks' + (s ? '?' + s : '') + (params.get('view') ? '' : '');
  };
  // view يبقى محفوظًا
  root.querySelectorAll('#ts-toolbar [id]').forEach((inp) => {
    const ev2 = (inp.tagName === 'SELECT' ? 'change' : 'input');
    inp.addEventListener(ev2, () => {
      const k = { ts_q: 'q', ts_status: 'status', ts_prio: 'priority', ts_due: 'due', ts_proj: 'project' }[inp.id];
      const params = new URLSearchParams(location.hash.split('?')[1] || '');
      if (inp.value) params.set(k, inp.value); else params.delete(k);
      params.set('view', view);
      location.hash = '#/tasks?' + params.toString();
    });
  });
  const addBtn = root.querySelector('#ts-add');
  if (addBtn) addBtn.onclick = async () => { await loadFormOptions(); const r = await taskForm(); if (r) render(root, ctx); };

  try {
    const c = await api.get('/api/contacts?limit=200', { silent: true }).catch(() => ({ items: [] }));
    const p = await api.get('/api/projects', { silent: true }).catch(() => ({ items: [] }));
    setContactOpts(c.items); setProjectOpts(p.items); window.__projects = p.items;
    root.querySelector('#ts-proj').innerHTML = '<option value="">كل المشاريع</option>' + p.items.map((x) => `<option value="${x.id}">${esc(x.name)}</option>`).join('');
    const data = await api.get(`/api/tasks?limit=300&${new URLSearchParams(Object.fromEntries(q.entries()).filter(([k]) => k !== 'view'))}`);
    if (view === 'kanban') renderKanban(root.querySelector('#ts-body'), data.items, () => render(root, ctx));
    else if (view === 'list') renderList(root.querySelector('#ts-body'), data, () => render(root, ctx));
    else renderCalView(root.querySelector('#ts-body'), data.items);
  } catch {
    root.querySelector('#ts-body').innerHTML = emptyState('alert', 'تعذر تحميل المهام');
  }
}

// ---------- Kanban ----------
function renderKanban(box, items, refresh) {
  const today = todayISO();
  box.innerHTML = `<div class="kanban">${COLUMNS.map((col) => {
    const colItems = items.filter((t) => t.status === col.key);
    return `<div class="kb-col" data-status="${col.key}">
      <div class="kb-col-head"><span class="dot" style="background:${col.color}"></span>${col.label}<span class="n">${colItems.length}</span></div>
      <div class="kb-body">${colItems.map((t) => kbCard(t, today)).join('')}</div>
    </div>`;
  }).join('')}</div>`;

  let dragged = null;
  box.querySelectorAll('.kb-card').forEach((card) => {
    card.draggable = true;
    card.addEventListener('dragstart', (e) => {
      dragged = card; card.classList.add('dragging');
      e.dataTransfer.effectAllowed = 'move';
      try { e.dataTransfer.setData('text/plain', card.dataset.id); } catch { /* */ }
    });
    card.addEventListener('dragend', () => card.classList.remove('dragging'));
    card.addEventListener('click', () => openTask(card.dataset.id, refresh));
  });
  box.querySelectorAll('.kb-col').forEach((col) => {
    col.addEventListener('dragover', (e) => { e.preventDefault(); col.classList.add('drag-over'); });
    col.addEventListener('dragleave', () => col.classList.remove('drag-over'));
    col.addEventListener('drop', async (e) => {
      e.preventDefault(); col.classList.remove('drag-over');
      if (!dragged) return;
      const id = dragged.dataset.id;
      const newStatus = col.dataset.status;
      // Optimistic: انقل البطاقة
      const to = col.querySelector('.kb-body');
      to.appendChild(dragged);
      updateColCounts(box);
      try {
        await api.post(`/api/tasks/${id}/status`, { status: newStatus }, { silent: true });
        toast('تم تحديث الحالة');
      } catch {
        renderKanban(box, items, refresh);
      }
    });
  });
}
function updateColCounts(box) {
  box.querySelectorAll('.kb-col').forEach((col) => {
    const n = col.querySelectorAll('.kb-card').length;
    col.querySelector('.n').textContent = n;
  });
}
function kbCard(t, today) {
  const late = t.due_date && t.due_date < today && t.status !== 'completed' && t.status !== 'cancelled';
  return `<div class="kb-card" data-id="${t.id}">
    <span class="prio-stripe ps-${t.priority}"></span>
    <div class="t">${esc(t.title)}</div>
    <div class="meta">
      <span class="badge b-${t.priority}">${PRIORITIES[t.priority]}</span>
      ${t.due_date ? `<span class="due ${late ? 'late' : ''}">${icon('clock')} ${relDay(t.due_date)}</span>` : ''}
      ${t.project_name ? `<span class="xs faint">${esc(t.project_name)}</span>` : ''}
      ${t.first_name ? `<span class="xs faint">👤 ${esc(t.first_name)}</span>` : ''}
    </div>
  </div>`;
}

// ---------- List ----------
function renderList(box, data, refresh) {
  const today = todayISO();
  if (!data.items.length) { box.innerHTML = emptyState('checkSquare', 'لا مهام', 'أنشئ مهمتك الأولى وابدأ التنظيم'); return; }
  box.innerHTML = `<div class="card table-wrap"><table class="table"><thead><tr>
    <th>المهمة</th><th>الحالة</th><th>الأولوية</th><th>الموعد النهائي</th><th>المشروع</th><th style="width:110px"></th>
  </tr></thead><tbody>
  ${data.items.map((t) => {
    const late = t.due_date && t.due_date < today && !['completed', 'cancelled'].includes(t.status);
    return `<tr data-id="${t.id}">
      <td><div class="bold">${esc(t.title)}</div>${t.description ? `<div class="xs faint" style="max-width:340px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(t.description)}</div>` : ''}</td>
      <td><select class="select ts-status-sel" style="width:auto;padding:5px 30px 5px 10px;font-size:.8rem">
        ${Object.entries(TASK_STATUS).map(([k, v]) => `<option value="${k}" ${t.status === k ? 'selected' : ''}>${v}</option>`).join('')}</select></td>
      <td><span class="badge b-${t.priority}">${PRIORITIES[t.priority]}</span></td>
      <td>${t.due_date ? `<span class="${late ? 'xtr' : ''}" style="${late ? 'color:var(--danger)' : ''}">${fmtDate(t.due_date)}${t.due_time ? ' · ' + fmtTime(t.due_time) : ''}</span>${late ? ' <span class="badge b-overdue">متأخرة</span>' : ''}` : '<span class="faint">—</span>'}</td>
      <td class="small">${t.project_name ? esc(t.project_name) : '<span class="faint">—</span>'}</td>
      <td><div class="row-actions">
        ${state.perm('tasks.edit') ? `<button class="icon-btn" data-act="edit" title="تعديل">${icon('edit')}</button>` : ''}
        ${state.perm('tasks.delete') ? `<button class="icon-btn danger" data-act="del" title="حذف">${icon('trash')}</button>` : ''}
      </div></td>
    </tr>`;
  }).join('')}
  </tbody></table></div>
  ${data.total > data.items.length ? `<button class="load-more" data-off="${data.offset + data.limit}">تحميل المزيد (${data.total - data.items.length} متبقي)</button>` : ''}`;

  box.querySelectorAll('.ts-status-sel').forEach((sel) => {
    sel.onchange = async () => {
      const id = sel.closest('tr').dataset.id;
      try { await api.post(`/api/tasks/${id}/status`, { status: sel.value }, { silent: true }); toast('تم تحديث الحالة'); }
      catch { sel.value = sel.options[0].value; }
    };
  });
  box.querySelectorAll('tr[data-id]').forEach((tr) => {
    tr.querySelectorAll('[data-act]').forEach((btn) => {
      btn.onclick = async (e) => {
        e.stopPropagation();
        const id = tr.dataset.id;
        if (btn.dataset.act === 'edit') { const r = await taskForm({ id }); if (r) refresh(); }
        if (btn.dataset.act === 'del') {
          if (await confirmDialog('حذف هذه المهمة نهائيًا؟')) { await api.del('/api/tasks/' + id); refresh(); }
        }
      };
    });
  });
  const more = box.querySelector('.load-more');
  if (more) more.onclick = async () => {
    const params = new URLSearchParams(location.hash.split('?')[1] || '');
    const limit = Number(params.get('limit') || 100) + 100;
    const next = await api.get(`/api/tasks?limit=${limit}&${[...params.entries()].filter(([k]) => k !== 'limit' && k !== 'view').map(([k, v]) => `${k}=${v}`).join('&')}`);
    renderList(box, next, refresh);
  };
}

// ---------- Task Calendar (شهر مبسط) ----------
function renderCalView(box, items) {
  const now = new Date();
  const y = now.getFullYear(), m = now.getMonth();
  const first = new Date(y, m, 1);
  const startDow = (first.getDay() + 6) % 7; // أسبوع يبدأ الأحد
  const daysIn = new Date(y, m + 1, 0).getDate();
  const cells = [];
  for (let i = 0; i < startDow; i++) cells.push(null);
  for (let d = 1; d <= daysIn; d++) cells.push(d);
  while (cells.length % 7) cells.push(null);
  const byDate = {};
  for (const t of items) if (t.due_date) (byDate[t.due_date.slice(0, 10)] ||= []).push(t);
  const today = todayISO();
  const monthName = new Intl.DateTimeFormat('ar', { month: 'long', year: 'numeric' }).format(now);
  box.innerHTML = `
    <div class="card card-pad">
      <div class="cal-head">${['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'].map((d) => `<div>${d}</div>`).join('')}</div>
      <div class="cal-grid">${cells.map((d) => {
        if (!d) return '<div class="cal-cell other" style="min-height:80px"></div>';
        const ds = `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
        const dayItems = byDate[ds] || [];
        return `<div class="cal-cell ${ds === today ? 'today' : ''}" data-date="${ds}" style="min-height:80px">
          <div class="cal-day">${d}</div>
          ${dayItems.slice(0, 3).map((t) => `<div class="cal-chip cc-task" style="border-inline-start:3px solid var(--${t.priority === 'urgent' ? 'danger' : t.priority === 'high' ? 'warn' : 'primary'})">${esc(t.title.slice(0, 22))}</div>`).join('')}
          ${dayItems.length > 3 ? `<div class="cal-more">+${dayItems.length - 3} أخرى</div>` : ''}
        </div>`;
      }).join('')}</div>
    </div>`;
}

// ---------- فتح مهمة (drawer) ----------
export async function openTask(id, refresh) {
  try {
    const { row } = await api.get(`/api/tasks/${id}`);
    const t = row;
    const { openDrawer } = await import('../ui.js');
    const body = el(`<div>
      <div class="flex aic gap-10 mb-8"><span class="badge b-${t.priority}">${PRIORITIES[t.priority]}</span><span class="badge b-${t.status}">${TASK_STATUS[t.status]}</span>
        ${t.due_date ? `<span class="small muted">${icon('clock')} حتى ${fmtDate(t.due_date)}${t.due_time ? ' ' + fmtTime(t.due_time) : ''}</span>` : ''}</div>
      <h2 style="font-size:1.2rem;font-weight:800;line-height:1.5">${esc(t.title)}</h2>
      ${t.description ? `<p class="small muted mt-8" style="line-height:1.8">${esc(t.description)}</p>` : ''}
      <div class="kv mt-14">
        <span class="k">المشروع</span><span>${t.project_name ? esc(t.project_name) : '—'}</span>
        <span class="k">الشخص</span><span>${t.first_name ? esc(t.first_name + (t.last_name || '')) : '—'}</span>
        <span class="k">تاريخ البداية</span><span>${t.start_date ? fmtDate(t.start_date) : '—'}</span>
        <span class="k">أُنشئت</span><span>${fmtDate(t.created_at)}</span>
        ${t.notes ? `<span class="k">ملاحظات</span><span style="line-height:1.7">${esc(t.notes)}</span>` : ''}
      </div>
      <div class="divider"></div>
      <div class="seg" style="width:100%">${COLUMNS.slice(0, 4).map((c) => `<button data-st="${c.key}" class="${t.status === c.key ? 'active' : ''}" style="flex:1">${c.label}</button>`).join('')}</div>
      <div class="flex gap-8 mt-14">
        ${state.perm('tasks.edit') ? `<button class="btn" id="tk-edit">${icon('edit')} تعديل</button>` : ''}
        ${state.perm('tasks.delete') ? `<button class="btn btn-danger" id="tk-del">${icon('trash')} حذف</button>` : ''}
      </div>
    </div>`);
    openDrawer({
      title: 'التفاصيل',
      body,
      onClose: refresh,
    });
    const drawer = document.querySelector('#drawer-root .drawer');
    body.querySelectorAll('[data-st]').forEach((b) => {
      b.onclick = async () => {
        await api.post(`/api/tasks/${t.id}/status`, { status: b.dataset.st }, { silent: true });
        toast('تم تحديث الحالة');
        drawer.querySelector('.drawer').remove();
        if (refresh) refresh();
      };
    });
    body.querySelector('#tk-edit')?.addEventListener('click', async () => {
      const r = await taskForm(t);
      if (r) { drawer.querySelector('.drawer').remove(); refresh && refresh(); }
    });
    body.querySelector('#tk-del')?.addEventListener('click', async () => {
      if (await confirmDialog('حذف هذه المهمة؟')) {
        await api.del('/api/tasks/' + t.id);
        drawer.querySelector('.drawer').remove();
        refresh && refresh();
      }
    });
  } catch { /* handled */ }
}
