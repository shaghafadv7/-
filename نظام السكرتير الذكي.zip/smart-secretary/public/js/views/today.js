// قسم "يومي" — Timeline اليوم الكامل مع الإجراءات
import { api } from '../api.js';
import { state } from '../state.js';
import { icon, esc, fmtDateFull, fmtTime, TASK_STATUS } from '../core.js';
import { emptyState, confirmDialog } from '../ui.js';
import { eventForm, taskForm, reminderForm, loadFormOptions } from '../forms.js';

function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export async function render(root, ctx) {
  const date = ctx.query.get('date') || todayStr();
  root.innerHTML = `
    <div class="page-head">
      <div>
        <div class="page-title">يومي</div>
        <div class="page-sub">${fmtDateFull(date)}</div>
      </div>
      <div class="page-actions">
        <button class="btn" id="td-prev">${icon('chevR')} السابق</button>
        <button class="btn" id="td-next">التالي ${icon('chevL')}</button>
        <button class="btn btn-primary" id="td-add">${icon('plus')} إضافة حدث</button>
      </div>
    </div>
    <div class="card"><div class="card-pad" id="td-timeline"><div class="skel" style="height:200px"></div></div></div>`;

  const shift = (n) => {
    const d = new Date(date + 'T12:00:00');
    d.setDate(d.getDate() + n);
    const p = (x) => String(x).padStart(2, '0');
    const nd = `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
    location.hash = `#/today?date=${nd}`;
  };
  root.querySelector('#td-prev').onclick = () => shift(-1);
  root.querySelector('#td-next').onclick = () => shift(1);
  root.querySelector('#td-add').onclick = async () => { await loadFormOptions(); const r = await eventForm(); if (r) { const { render: r2 } = await import('./today.js'); r2(root, ctx); } };

  try {
    const d = await api.get(`/api/dashboard/today?date=${date}`);
    const box = root.querySelector('#td-timeline');
    if (!d.items.length) {
      box.innerHTML = emptyState('sun', 'لا أحداث لهذا اليوم', 'أضف موعدًا أو اجتماعًا أو مهمة لموعدها اليوم',
        `<button class="btn btn-primary" id="td-add2">${icon('plus')} إضافة حدث</button>`);
      box.querySelector('#td-add2').onclick = root.querySelector('#td-add').onclick;
      return;
    }
    box.innerHTML = `<div class="timeline">${d.items.map(itemHtml).join('')}</div>`;
    bindItems(box, date);
  } catch {
    root.querySelector('#td-timeline').innerHTML = emptyState('alert', 'تعذر التحميل');
  }
  await loadFormOptions();
}

function itemHtml(i) {
  const ic = { event: 'calendar', meeting: 'video', task: 'checkSquare', reminder: 'bell', call: 'phone' }[i.kind] || 'calendar';
  const done = i.status === 'completed' || i.status === 'done' || i.status === 'fired';
  let actions = '';
  if (i.kind === 'task') {
    actions = `<button class="icon-btn" data-act="toggle" title="إكمال / إرجاع">${icon('checkCircle')}</button>`;
    if (state.perm('tasks.delete')) actions += `<button class="icon-btn danger" data-act="del" title="حذف">${icon('trash')}</button>`;
  }
  if (i.kind === 'event') {
    actions = state.perm('calendar.edit') ? `<button class="icon-btn" data-act="edit" title="تعديل">${icon('edit')}</button>` : '';
    if (state.perm('calendar.delete')) actions += `<button class="icon-btn danger" data-act="del" title="حذف">${icon('trash')}</button>`;
  }
  if (i.kind === 'reminder') {
    actions = state.perm('reminders.edit') ? `<button class="icon-btn" data-act="toggle" title="إنجاز">${icon('check')}</button>` : '';
    if (state.perm('reminders.delete')) actions += `<button class="icon-btn danger" data-act="del" title="حذف">${icon('trash')}</button>`;
  }
  if (i.kind === 'meeting') {
    actions = `<a class="icon-btn" href="#/meetings" title="فتح">${icon('external')}</a>`;
  }
  return `<div class="tl-item ${done ? 'done' : ''}" data-id="${i.id}" data-kind="${i.kind}">
    <div class="tl-time">${fmtTime(i.time) || '—'}</div>
    <div class="tl-dot kind-${i.kind}">${icon(ic)}</div>
    <div class="tl-body">
      <div class="tl-title">${esc(i.title)}
        ${i.kind === 'task' && !done ? `<span class="badge b-${i.status}">${TASK_STATUS[i.status] || i.status}</span>` : ''}
        ${i.kind === 'reminder' && i.status === 'pending' ? '<span class="badge b-needs">قادم</span>' : ''}
        <span class="tl-actions">${actions}</span></div>
      ${i.sub ? `<div class="tl-sub">${esc(i.sub)}</div>` : ''}
    </div>
  </div>`;
}

async function bindItems(box, date) {
  box.querySelectorAll('.tl-item').forEach((el2) => {
    el2.querySelector('.tl-actions')?.addEventListener('click', async (e) => {
      const btn = e.target.closest('[data-act]');
      if (!btn) return;
      const id = el2.dataset.id;
      const kind = el2.dataset.kind;
      const act = btn.dataset.act;
      try {
        if (act === 'toggle' && kind === 'task') {
          const isDone = el2.classList.contains('done');
          // Optimistic UI
          el2.classList.toggle('done');
          const badge = el2.querySelector('.badge');
          if (badge) badge.outerHTML = isDone ? '' : '<span class="badge b-completed">مكتملة</span>';
          await api.post(`/api/tasks/${id}/status`, { status: isDone ? 'in_progress' : 'completed' }, { silent: true });
        } else if (act === 'toggle' && kind === 'reminder') {
          await api.post(`/api/reminders/${id}/status`, { status: 'done' });
          el2.classList.add('done');
        } else if (act === 'del') {
          const ok = await confirmDialog('هل أنت متأكد من حذف هذا العنصر؟');
          if (!ok) return;
          const path = { task: '/api/tasks', event: '/api/events', reminder: '/api/reminders' }[kind];
          await api.del(`${path}/${id}`);
          el2.remove();
        } else if (act === 'edit' && kind === 'event') {
          const ev = await api.get(`/api/events`, { silent: true }).then((r) => r.items.find((x) => x.id === id)).catch(() => null);
          if (ev) { await eventForm(ev); render(box, date); }
        }
      } catch { /* handled */ }
    });
  });
  // إعادة عرض بعد تعديل الموعد
  async function render(box2, date2) {
    const d = await api.get(`/api/dashboard/today?date=${date2}`);
    box2.innerHTML = d.items.length ? `<div class="timeline">${d.items.map(itemHtml).join('')}</div>` : '';
    bindItems(box2, date2);
  }
}
