// سجل العمليات (Audit Log)
import { api } from '../api.js';
import { icon, esc, fmtDateTime } from '../core.js';
import { emptyState } from '../ui.js';

const ACTION_LABELS = { create: 'إنشاء', update: 'تعديل', delete: 'حذف', status: 'تغيير حالة', login: 'دخول', logout: 'خروج', minutes: 'محضر', restore: 'استعادة', ai: 'ذكاء' };

export async function render(root, ctx) {
  const q = ctx.query;
  root.innerHTML = `
    <div class="page-head">
      <div><div class="page-title">سجل العمليات</div><div class="page-sub">من فعل ماذا ومتى — شفافية كاملة</div></div>
    </div>
    <div class="toolbar">
      <input class="input" id="au-q" placeholder="بحث في التفاصيل…" value="${esc(q.get('q') || '')}"/>
      <select class="select" id="au-entity"><option value="">كل الكيانات</option>${['tasks', 'contacts', 'meetings', 'files', 'followups', 'users', 'notes', 'events', 'expenses', 'calls', 'reminders', 'projects', 'settings', 'roles', 'auth'].map((e) => `<option value="${e}" ${q.get('entity') === e ? 'selected' : ''}>${e}</option>`).join('')}</select>
      <input type="date" class="input" id="au-from" value="${q.get('from') || ''}"/>
      <input type="date" class="input" id="au-to" value="${q.get('to') || ''}"/>
    </div>
    <div id="au-body"><div class="skel" style="height:300px"></div></div>`;
  ['au-q', 'au-entity', 'au-from', 'au-to'].forEach((id) => {
    const inp = root.querySelector('#' + id);
    inp.addEventListener(inp.tagName === 'SELECT' ? 'change' : 'input', () => {
      const p = new URLSearchParams(location.hash.split('?')[1] || '');
      const k = { 'au-q': 'q', 'au-entity': 'entity', 'au-from': 'from', 'au-to': 'to' }[id];
      if (inp.value) p.set(k, inp.value); else p.delete(k);
      location.hash = '#/audit' + (p.toString() ? '?' + p.toString() : '');
    });
  });
  let offset = 0;
  const PAGE = 30;
  const load = async (off = 0) => {
    offset = off;
    const p = new URLSearchParams(Object.fromEntries(q.entries()));
    p.set('limit', String(PAGE)); p.set('offset', String(off));
    const data = await api.get(`/api/audit?${p.toString()}`);
    const box = root.querySelector('#au-body');
    if (!data.items.length) { box.innerHTML = emptyState('activity', 'لا عمليات مسجلة', 'تظهر هنا كل العمليات: إنشاء، تعديل، حذف، دخول'); return; }
    const html = `<div class="card"><div class="card-pad" style="padding:0">
      ${data.items.map((a) => `<div style="display:flex;gap:12px;padding:12px 18px;border-bottom:1px solid var(--border);align-items:flex-start">
        <div class="tl-dot kind-${['create'].includes(a.action) ? 'task' : ['delete'].includes(a.action) ? 'followup' : 'event'}" style="width:34px;height:34px;flex:none">${icon({ create: 'plus', delete: 'trash', update: 'edit', status: 'refresh', login: 'user', logout: 'logout', minutes: 'edit', restore: 'refresh', ai: 'sparkles' }[a.action] || 'circle')}</div>
        <div style="flex:1;min-width:0">
          <div class="small">${a.details ? esc(a.details) : `${ACTION_LABELS[a.action] || a.action} — ${a.entity || ''}`}</div>
          <div class="xs faint mt-8">${esc(a.user_name || 'النظام')} • ${a.entity ? `كيان: ${a.entity}${a.entity_id ? '#' + a.entity_id : ''}` : ''} • ${fmtDateTime(a.created_at)}</div>
        </div>
        <span class="badge soft">${ACTION_LABELS[a.action] || a.action}</span>
      </div>`).join('')}
    </div>
    ${data.offset + PAGE < data.total ? `<button class="load-more" id="au-more">تحميل المزيد (${data.total - data.offset - PAGE} متبقي)</button>` : ''}</div>`;
    if (off === 0) box.innerHTML = html;
    else {
      const prev = box.querySelector('.load-more');
      prev && prev.insertAdjacentHTML('beforebegin', data.items.map((a) => `<div style="display:flex;gap:12px;padding:12px 18px;border-bottom:1px solid var(--border);align-items:flex-start">
        <div class="small" style="flex:1">${a.details ? esc(a.details) : a.action}</div>
        <span class="badge soft">${ACTION_LABELS[a.action] || a.action}</span></div>`).join(''));
    }
    const more = box.querySelector('#au-more');
    if (more) more.onclick = () => load(off + PAGE);
  };
  try { await load(0); } catch { root.querySelector('#au-body').innerHTML = emptyState('alert', 'تعذر التحميل'); }
}
