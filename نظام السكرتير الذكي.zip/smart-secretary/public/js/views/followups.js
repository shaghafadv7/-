// المتابعات — محرك المتابعة المركزي
import { api } from '../api.js';
import { state } from '../state.js';
import { icon, esc, fmtDate, todayISO, relDay, FOLLOWUP_STATUS, PRIORITIES } from '../core.js';
import { emptyState, confirmDialog, toast, openModal } from '../ui.js';
import { followupForm, loadFormOptions } from '../forms.js';

export async function render(root, ctx) {
  const q = ctx.query;
  root.innerHTML = `
    <div class="page-head">
      <div><div class="page-title">المتابعات</div><div class="page-sub" id="fu-sub"></div></div>
      <div class="page-actions">
        <button class="btn" id="fu-filter-overdue" style="color:var(--danger)">${icon('alert')} المستحقة</button>
        ${state.perm('followups.create') ? `<button class="btn btn-primary" id="fu-add">${icon('plus')} متابعة جديدة</button>` : ''}
      </div>
    </div>
    <div id="fu-due-banner"></div>
    <div class="toolbar">
      <input class="input" id="fu-q" placeholder="بحث في المتابعات…" value="${esc(q.get('q') || '')}"/>
      <select class="select" id="fu-status"><option value="">كل الحالات</option>${Object.entries(FOLLOWUP_STATUS).map(([k, v]) => `<option value="${k}" ${q.get('status') === k ? 'selected' : ''}>${v}</option>`).join('')}</select>
      <select class="select" id="fu-due"><option value="">كل المواعيد</option>
        <option value="today" ${q.get('due') === 'today' ? 'selected' : ''}>المستحقة اليوم</option>
        <option value="week" ${q.get('due') === 'week' ? 'selected' : ''}>هذا الأسبوع</option>
        <option value="overdue" ${q.get('due') === 'overdue' ? 'selected' : ''}>المتأخرة</option></select>
    </div>
    <div id="fu-body"><div class="skel" style="height:300px"></div></div>`;

  const base = () => {
    const p = new URLSearchParams(location.hash.split('?')[1] || '');
    const s = p.toString();
    return s ? s : '';
  };
  root.querySelectorAll('#fu-toolbar, .toolbar [id]')?.length;
  ['fu-q', 'fu-status', 'fu-due'].forEach((id) => {
    const inp = root.querySelector('#' + id);
    inp.addEventListener(inp.tagName === 'SELECT' ? 'change' : 'input', () => {
      const p = new URLSearchParams(location.hash.split('?')[1] || '');
      const k = { 'fu-q': 'q', 'fu-status': 'status', 'fu-due': 'due' }[id];
      if (inp.value) p.set(k, inp.value); else p.delete(k);
      location.hash = '#/followups' + (p.toString() ? '?' + p.toString() : '');
    });
  });
  const filterBtn = root.querySelector('#fu-filter-overdue');
  filterBtn.onclick = () => { location.hash = '#/followups?due=today'; };
  const addBtn = root.querySelector('#fu-add');
  if (addBtn) addBtn.onclick = async () => { await loadFormOptions(); const r = await followupForm(); if (r) render(root, ctx); };

  try {
    const params = new URLSearchParams(Object.fromEntries(q.entries()));
    const data = await api.get(`/api/followups?limit=100&${params.toString()}`);
    // عدد المستحقة اليوم (عندما لا يوجد فلتر)
    if (!params.get('due') && !params.get('status')) {
      const all = await api.get('/api/followups?due=today&limit=1', { silent: true });
      const banner = root.querySelector('#fu-due-banner');
      banner.innerHTML = all.total > 0
        ? `<div class="card card-pad flex aic gap-14" style="background:linear-gradient(135deg, var(--danger-soft), transparent);border-color:var(--border)">
            <div class="stat-icon si-danger">${icon('target')}</div>
            <div><div class="xtr" style="color:var(--danger)">لديك ${all.total} متابعة مستحقة اليوم</div>
            <div class="small muted">ابدأ بالتواصل معهم الآن — كل تأخير يبطئ عملك</div></div>
            <button class="btn btn-danger mt-auto" id="fu-now">${icon('zap')} متابعة الآن</button>
          </div>` : '';
      const now = root.querySelector('#fu-now');
      if (now) now.onclick = () => location.hash = '#/followups?due=today';
    }
    const box = root.querySelector('#fu-body');
    root.querySelector('#fu-sub').textContent = data.total ? `${data.total} متابعة` : 'قائمة المتابعات';
    if (!data.items.length) { box.innerHTML = emptyState('target', 'لا متابعات', 'أنشئ متابعة لتتابع الأشخاص والأعمال دون نسيان', state.perm('followups.create') ? '<button class="btn btn-primary" id="fu-add2">متابعة جديدة</button>' : ''); const b = box.querySelector('#fu-add2'); if (b) b.onclick = addBtn.onclick; return; }
    box.innerHTML = `<div class="card table-wrap"><table class="table"><thead><tr>
      <th>الشخص</th><th>الموضوع</th><th>آخر تواصل</th><th>المتابعة القادمة</th><th>الحالة</th><th style="width:170px">إجراءات</th>
    </tr></thead><tbody>${data.items.map((f) => {
      const name = [f.first_name, f.last_name].filter(Boolean).join(' ') || '<span class="faint">غير مرتبط</span>';
      const late = f.next_date && f.next_date < todayISO() && ['waiting', 'needs'].includes(f.status);
      return `<tr data-id="${f.id}">
        <td><a href="#/contacts/${f.contact_id}" style="font-weight:700">${esc(name)}</a>${f.company ? `<div class="xs faint">${esc(f.company)}</div>` : ''}</td>
        <td><div>${esc(f.subject)}</div>${f.project_name ? `<div class="xs faint">${esc(f.project_name)}</div>` : ''}</td>
        <td class="small">${f.last_contact_at ? fmtDate(f.last_contact_at) : '—'}</td>
        <td>${f.next_date ? `<span class="${late ? 'xtr' : ''}" style="${late ? 'color:var(--danger)' : ''}">${fmtDate(f.next_date)} ${late ? '<span class="badge b-overdue">متأخرة</span>' : ''}</span>` : '—'}</td>
        <td><span class="badge b-${f.status}">${FOLLOWUP_STATUS[f.status]}</span></td>
        <td><div class="row-actions" style="opacity:1">
          ${f.phone ? `<a class="icon-btn" href="tel:${esc(f.phone)}" title="اتصال" style="color:var(--ok)">${icon('phone')}</a>` : ''}
          ${f.whatsapp ? `<a class="icon-btn" href="https://wa.me/${esc(f.whatsapp)}" target="_blank" title="واتساب" style="color:var(--ok)">${icon('message')}</a>` : ''}
          ${f.email ? `<a class="icon-btn" href="mailto:${esc(f.email)}" title="بريد" style="color:var(--info)">${icon('mail')}</a>` : ''}
          ${state.perm('followups.edit') ? `<button class="icon-btn" data-act="done" title="تمت المتابعة" style="color:var(--primary)">${icon('checkCircle')}</button>
          <button class="icon-btn" data-act="edit" title="تعديل">${icon('edit')}</button>` : ''}
          ${state.perm('followups.delete') ? `<button class="icon-btn danger" data-act="del" title="حذف">${icon('trash')}</button>` : ''}
        </div></td>
      </tr>`;
    }).join('')}</tbody></table></div>`;

    box.querySelectorAll('tr[data-id]').forEach((tr) => {
      tr.querySelectorAll('[data-act]').forEach((btn) => {
        btn.onclick = async (e) => {
          e.preventDefault(); e.stopPropagation();
          const id = tr.dataset.id;
          if (btn.dataset.act === 'done') markDone(id, () => render(root, ctx));
          if (btn.dataset.act === 'edit') {
            const item = data.items.find((x) => x.id === Number(id));
            const r = await followupForm(item);
            if (r) render(root, ctx);
          }
          if (btn.dataset.act === 'del') {
            if (await confirmDialog('حذف هذه المتابعة؟')) { await api.del('/api/followups/' + id); render(root, ctx); }
          }
        };
      });
    });
  } catch {
    root.querySelector('#fu-body').innerHTML = emptyState('alert', 'تعذر التحميل');
  }
}

async function markDone(id, refresh) {
  const ov = openModal({
    title: 'تمت المتابعة',
    body: `<p class="small muted" style="margin-bottom:14px">سجّلنا التواصل — متى تريد المتابعة القادمة؟</p>
      <div class="seg" style="width:100%">${[[1, 'غدًا'], [3, 'بعد 3 أيام'], [7, 'بعد أسبوع'], [14, 'بعد أسبوعين'], [30, 'بعد شهر']].map(([d, l]) => `<button data-d="${d}" class="${d === 7 ? 'active' : ''}" style="flex:1">${l}</button>`).join('')}</div>`,
    footer: `<button class="btn" id="fd-cancel">إلغاء</button><button class="btn btn-primary" id="fd-ok">${icon('check')} تأكيد</button>`,
  });
  let days = 7;
  ov.querySelectorAll('[data-d]').forEach((b) => (b.onclick = () => {
    ov.querySelectorAll('[data-d]').forEach((x) => x.classList.remove('active'));
    b.classList.add('active'); days = Number(b.dataset.d);
  }));
  ov.querySelector('#fd-cancel').onclick = () => ov.__close();
  ov.querySelector('#fd-ok').onclick = async () => {
    await api.post(`/api/followups/${id}/done`, { next_in_days: days });
    ov.__close();
    toast('تمت المتابعة — رائع!');
    refresh();
  };
}
