// المستخدمون والصلاحيات
import { api } from '../api.js';
import { state } from '../state.js';
import { icon, esc, avatarHtml } from '../core.js';
import { emptyState, confirmDialog, toast, openModal } from '../ui.js';

const ROLE_NAMES = { admin: 'مدير النظام', secretary: 'سكرتير', staff: 'موظف' };

export async function render(root, ctx) {
  root.innerHTML = `
    <div class="page-head">
      <div><div class="page-title">المستخدمون والصلاحيات</div><div class="page-sub">تحكم كامل بمن يدخل النظام وما يمكنه فعله</div></div>
      <div class="page-actions">${state.perm('users.manage') ? `<button class="btn btn-primary" id="us-add">${icon('plus')} مستخدم جديد</button>` : ''}</div>
    </div>
    <div id="us-roles"></div>
    <div class="card mt-14" id="us-body"><div class="skel" style="height:200px"></div></div>`;
  const addBtn = root.querySelector('#us-add');
  if (addBtn) addBtn.onclick = () => addUserModal(() => render(root, ctx));

  try {
    const { items, roles } = await api.get('/api/users');
    // مصفوفة الصلاحيات
    if (state.perm('users.manage')) {
      const perms = await api.get('/api/users/permissions');
      const roleData = {};
      for (const r of roles) {
        roleData[r.name] = r.name === 'admin' ? 'all' : null;
      }
      // جلب صلاحيات كل دور
      for (const r of roles.filter((x) => x.name !== 'admin')) {
        // نستخدم role_permissions عبر roles endpoint غير موجود — نقرأ من المستخدم إن وجد
      }
      root.querySelector('#us-roles').innerHTML = `<div class="card"><div class="card-head"><h3>${icon('shield')} مصفوفة الصلاحيات</h3><span class="xs muted">حدد ما يمكن لكل دور رؤيته</span></div>
        <div class="card-pad" id="perm-matrix"></div></div>`;
      // بناء المصفوفة (نقل صلاحيات الدور الحالي من API: لا يوجد endpoint مباشر — نستخدم PATCH للتخزين)
      const matrix = root.querySelector('#perm-matrix');
      matrix.innerHTML = `<div class="table-wrap"><table class="table"><thead><tr>
        <th style="min-width:160px">الصلاحية</th>
        ${roles.filter((r) => r.name !== 'admin').map((r) => `<th style="text-align:center">${ROLE_NAMES[r.name] || r.name}</th>`).join('')}
        <th style="text-align:center">مدير</th></tr></thead><tbody>
        ${perms.items.map((p) => `<tr>
          <td class="small bold">${esc(p.label)}</td>
          ${roles.filter((r) => r.name !== 'admin').map((r) => `<td style="text-align:center"><input type="checkbox" data-role="${r.name}" data-code="${p.code}" class="perm-cb" ${Array.isArray(r.permissions) && r.permissions.includes(p.code) ? 'checked' : ''}/></td>`).join('')}
          <td style="text-align:center"><input type="checkbox" checked disabled title="كامل الصلاحيات"/></td>
        </tr>`).join('')}
        </tbody></table></div>
        <div class="mt-14"><button class="btn btn-primary" id="pm-save">${icon('check')} حفظ الصلاحيات</button></div>`;
      const saveBtn = matrix.querySelector('#pm-save');
      saveBtn.onclick = async () => {
        for (const r of roles.filter((x) => x.name !== 'admin')) {
          const codes = [...matrix.querySelectorAll(`input[data-role="${r.name}"]:checked`)].map((c) => c.dataset.code);
          await api.put(`/api/users/roles/${r.id}/permissions`, { codes });
        }
        toast('تم حفظ الصلاحيات');
      };
    }

    const box = root.querySelector('#us-body');
    box.innerHTML = `<div class="table-wrap"><table class="table"><thead><tr>
      <th>المستخدم</th><th>البريد</th><th>الدور</th><th>المهام</th><th>آخر دخول</th><th>الحالة</th><th style="width:130px"></th>
    </tr></thead><tbody>${items.map((u) => `<tr data-id="${u.id}">
      <td><div class="flex aic gap-10">${avatarHtml(u.name, u.avatar, 'sm')}<span class="bold">${esc(u.name)}</span></div></td>
      <td class="small">${esc(u.email)}</td>
      <td><select class="select us-role" style="width:auto;padding:5px 30px 5px 10px;font-size:.8rem" ${state.perm('users.manage') ? '' : 'disabled'}>
        ${roles.map((r) => `<option value="${r.id}" ${u.role_id === r.id ? 'selected' : ''}>${ROLE_NAMES[r.name] || r.name}</option>`).join('')}</select></td>
      <td>${u.tasks_count}</td>
      <td class="small">${u.last_login_at ? u.last_login_at.slice(0, 16).replace('T', ' ') : '—'}</td>
      <td><span class="badge ${u.is_active ? 'b-completed' : 'b-cancelled'}">${u.is_active ? 'نشط' : 'معطل'}</span></td>
      <td><div class="row-actions" style="opacity:1">
        ${state.perm('users.manage') ? `
        <button class="icon-btn" data-act="pass" title="إعادة تعيين كلمة المرور">${icon('key') || icon('refresh')}</button>
        <button class="icon-btn" data-act="toggle" title="${u.is_active ? 'تعطيل' : 'تفعيل'}">${icon(u.is_active ? 'x' : 'check')}</button>
        ${u.id !== state.user.id ? `<button class="icon-btn danger" data-act="del" title="حذف">${icon('trash')}</button>` : ''}` : ''}
      </div></td>
    </tr>`).join('')}</tbody></table></div>`;

    box.querySelectorAll('tr[data-id]').forEach((tr) => {
      const u = items.find((x) => x.id === Number(tr.dataset.id));
      tr.querySelector('.us-role')?.addEventListener('change', async (e) => {
        await api.patch('/api/users/' + u.id, { role_id: Number(e.target.value) });
        toast('تم تغيير الدور');
      });
      tr.querySelectorAll('[data-act]').forEach((btn) => {
        btn.onclick = async () => {
          const act = btn.dataset.act;
          if (act === 'pass') {
            const ov = openModal({ title: 'إعادة تعيين كلمة المرور', body: `<div class="field"><label>كلمة المرور الجديدة (6+)</label><input type="password" class="input" id="rp-pass"/></div>`,
              footer: `<button class="btn" id="rp-no">إلغاء</button><button class="btn btn-primary" id="rp-yes">تعيين</button>` });
            ov.querySelector('#rp-no').onclick = () => ov.__close();
            ov.querySelector('#rp-yes').onclick = async () => {
              await api.post(`/api/users/${u.id}/reset-password`, { password: ov.querySelector('#rp-pass').value });
              ov.__close(); toast('تم تعيين كلمة المرور');
            };
          }
          if (act === 'toggle') {
            await api.patch('/api/users/' + u.id, { is_active: u.is_active ? 0 : 1 });
            render(root, ctx);
          }
          if (act === 'del') {
            if (await confirmDialog(`حذف المستخدم «${u.name}»؟`)) { await api.del('/api/users/' + u.id); render(root, ctx); }
          }
        };
      });
    });
  } catch {
    root.querySelector('#us-body').innerHTML = emptyState('alert', 'تعذر التحميل');
  }
}

function addUserModal(refresh) {
  const ov = openModal({
    title: 'مستخدم جديد',
    body: `<div class="field"><label>الاسم</label><input class="input" id="nu-name"/></div>
      <div class="field"><label>البريد</label><input class="input" id="nu-email" type="email"/></div>
      <div class="field"><label>الجوال</label><input class="input" id="nu-phone"/></div>
      <div class="field"><label>الدور</label><select class="select" id="nu-role">
        <option value="2">سكرتير</option><option value="3">موظف</option><option value="1">مدير النظام</option></select></div>
      <div class="field"><label>كلمة المرور (6+ أحرف)</label><input type="password" class="input" id="nu-pass"/></div>`,
    footer: `<button class="btn" id="nu-no">إلغاء</button><button class="btn btn-primary" id="nu-yes">${icon('plus')} إضافة</button>`,
  });
  ov.querySelector('#nu-no').onclick = () => ov.__close();
  ov.querySelector('#nu-yes').onclick = async () => {
    try {
      await api.post('/api/users', {
        name: ov.querySelector('#nu-name').value,
        email: ov.querySelector('#nu-email').value,
        phone: ov.querySelector('#nu-phone').value,
        role_id: Number(ov.querySelector('#nu-role').value),
        password: ov.querySelector('#nu-pass').value,
      });
      ov.__close();
      toast('تمت إضافة المستخدم');
      refresh();
    } catch { /* handled */ }
  };
}
