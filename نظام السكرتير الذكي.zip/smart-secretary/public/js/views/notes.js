// الملاحظات — سريعة/اجتماعات/أشخاص/مشاريع + وسوم ومفضلة وتثبيت
import { api } from '../api.js';
import { state } from '../state.js';
import { icon, esc, fmtDate, relTime, NOTE_TYPES } from '../core.js';
import { emptyState, confirmDialog, openModal } from '../ui.js';
import { noteForm, loadFormOptions } from '../forms.js';

export async function render(root, ctx) {
  const q = ctx.query;
  root.innerHTML = `
    <div class="page-head">
      <div><div class="page-title">الملاحظات</div><div class="page-sub" id="nt-sub"></div></div>
      <div class="page-actions">${state.perm('notes.create') ? `<button class="btn btn-primary" id="nt-add">${icon('plus')} ملاحظة</button>` : ''}</div>
    </div>
    <div class="toolbar">
      <input class="input" id="nt-q" placeholder="بحث في الملاحظات…" value="${esc(q.get('q') || '')}"/>
      <select class="select" id="nt-type"><option value="">كل الأنواع</option>${Object.entries(NOTE_TYPES).map(([k, v]) => `<option value="${k}" ${q.get('type') === k ? 'selected' : ''}>${v}</option>`).join('')}</select>
      <div class="chip" id="nt-pinned">${icon('pin')} المثبتة</div>
      <div class="chip" id="nt-fav">${icon('star')} المفضلة</div>
      <div id="nt-tags" style="display:flex;gap:6px;flex-wrap:wrap"></div>
    </div>
    <div id="nt-body"><div class="skel" style="height:300px"></div></div>`;

  const refreshChips = () => {
    root.querySelector('#nt-pinned').classList.toggle('active', !!q.get('pinned'));
    root.querySelector('#nt-fav').classList.toggle('active', !!q.get('fav'));
  };
  refreshChips();
  const go = (patch) => {
    const p = new URLSearchParams(location.hash.split('?')[1] || '');
    for (const [k, v] of Object.entries(patch)) { if (v) p.set(k, v); else p.delete(k); }
    location.hash = '#/notes' + (p.toString() ? '?' + p.toString() : '');
  };
  ['nt-q', 'nt-type'].forEach((id) => {
    const inp = root.querySelector('#' + id);
    inp.addEventListener(inp.tagName === 'SELECT' ? 'change' : 'input', () => {
      const k = id === 'nt-q' ? 'q' : 'type';
      go({ [k]: inp.value });
    });
  });
  root.querySelector('#nt-pinned').onclick = () => go({ pinned: q.get('pinned') ? null : '1' });
  root.querySelector('#nt-fav').onclick = () => go({ fav: q.get('fav') ? null : '1' });
  const addBtn = root.querySelector('#nt-add');
  if (addBtn) addBtn.onclick = async () => { await loadFormOptions(); const r = await noteForm(); if (r) render(root, ctx); };

  // الوسوم
  let tags = [];
  try { const t = await api.get('/api/notes/tags', { silent: true }); tags = t.items.map((x) => x.name); } catch { tags = []; }
  const tagBox = root.querySelector('#nt-tags');
  tagBox.innerHTML = tags.map((t) => `<div class="chip ${q.get('tag') === t ? 'active' : ''}" data-tag="${esc(t)}">#${esc(t)}</div>`).join('');
  tagBox.querySelectorAll('[data-tag]').forEach((c) => (c.onclick = () => go({ tag: q.get('tag') === c.dataset.tag ? null : c.dataset.tag })));

  try {
    const p = new URLSearchParams(Object.fromEntries(q.entries()));
    p.set('limit', '120');
    const data = await api.get(`/api/notes?${p.toString()}`);
    root.querySelector('#nt-sub').textContent = `${data.items.length} ملاحظة`;
    const box = root.querySelector('#nt-body');
    if (!data.items.length) { box.innerHTML = emptyState('edit', 'لا ملاحظات', 'دوّن فكرة قبل أن تطير', state.perm('notes.create') ? '<button class="btn btn-primary" id="nt-add2">ملاحظة جديدة</button>' : '');
      const b = box.querySelector('#nt-add2'); if (b) b.onclick = addBtn.onclick; return; }
    box.innerHTML = `<div style="columns:3 320px;column-gap:14px">
      ${data.items.map((n) => `<div class="card" data-id="${n.id}" style="break-inside:avoid;margin-bottom:14px;cursor:pointer;overflow:hidden">
        <div class="card-pad" style="padding:15px 17px">
          <div class="flex aic jcb gap-8">
            <div class="xtr" style="font-size:.95rem;display:flex;gap:7px;align-items:center">${n.is_pinned ? `<span class="pin-btn on">${icon('pin')}</span>` : ''}${esc(n.title)}</div>
            <div class="flex gap-6">
              <button class="icon-btn star-btn ${n.is_favorite ? 'on' : ''}" data-star="${n.id}" title="مفضلة">${icon('star')}</button>
              <button class="icon-btn pin-btn ${n.is_pinned ? 'on' : ''}" data-pin="${n.id}" title="تثبيت">${icon('pin')}</button>
            </div>
          </div>
          ${n.content ? `<p class="small mt-8" style="color:var(--muted);white-space:pre-wrap;line-height:1.8;display:-webkit-box;-webkit-line-clamp:5;-webkit-box-orient:vertical;overflow:hidden">${esc(n.content)}</p>` : ''}
          <div class="flex gap-6 wrap mt-14">
            <span class="tag">${NOTE_TYPES[n.type] || n.type}</span>
            ${n.project_name ? `<span class="tag">${esc(n.project_name)}</span>` : ''}
            ${(n.tags || []).map((t) => `<span class="tag">#${esc(t)}</span>`).join('')}
          </div>
          <div class="xs faint mt-8">${fmtDate(n.created_at)} · ${relTime(n.created_at)}</div>
        </div>
      </div>`).join('')}
    </div>`;
    box.querySelectorAll('.card[data-id]').forEach((card) => {
      card.onclick = (e) => {
        if (e.target.closest('[data-star]') || e.target.closest('[data-pin]')) return;
        openNote(card.dataset.id);
      };
    });
    box.querySelectorAll('[data-star]').forEach((b) => (b.onclick = async (e) => {
      e.stopPropagation();
      await api.post(`/api/notes/${b.dataset.star}/toggle-fav`, {});
      b.classList.toggle('on');
    }));
    box.querySelectorAll('[data-pin]').forEach((b) => (b.onclick = async (e) => {
      e.stopPropagation();
      await api.post(`/api/notes/${b.dataset.pin}/toggle-pin`, {});
      b.classList.toggle('on');
      render(root, ctx);
    }));
  } catch {
    root.querySelector('#nt-body').innerHTML = emptyState('alert', 'تعذر التحميل');
  }
}

async function openNote(id) {
  try {
    const { note } = await api.get(`/api/notes/${id}`);
    const ov = openModal({
      title: note.title,
      wide: true,
      body: `<div class="flex gap-6 wrap mb-8"><span class="tag">${NOTE_TYPES[note.type] || note.type}</span>
        ${(note.tags || []).map((t) => `<span class="tag">#${esc(t)}</span>`).join('')}
        <span class="xs faint" style="margin-inline-start:auto">${fmtDate(note.created_at)}</span></div>
        <p style="white-space:pre-wrap;line-height:2;font-size:.95rem">${esc(note.content || '—')}</p>
        ${note.project_name ? `<div class="small mt-14 muted">المشروع: <b>${esc(note.project_name)}</b></div>` : ''}`,
      footer: `<button class="btn" id="nt-del2" style="margin-inline-end:auto;color:var(--danger)">${icon('trash')} حذف</button>
        <button class="btn" id="nt-edit">${icon('edit')} تعديل</button>`,
    });
    ov.querySelector('#nt-edit').onclick = async () => {
      const r = await noteForm(note);
      ov.__close();
      if (r) window.dispatchEvent(new Event('hashchange'));
    };
    ov.querySelector('#nt-del2').onclick = async () => {
      if (await confirmDialog('حذف هذه الملاحظة؟')) {
        await api.del('/api/notes/' + id);
        ov.__close();
        window.dispatchEvent(new Event('hashchange'));
      }
    };
  } catch { /* handled */ }
}
