// الاجتماعات — إدارة + محاضر + إنشاء مهام من المحضر (AI)
import { api } from '../api.js';
import { state } from '../state.js';
import { icon, esc, fmtDateTime, fmtDate, fmtTime, MEETING_STATUS, TASK_STATUS, PRIORITIES, todayISO } from '../core.js';
import { emptyState, confirmDialog, toast, openDrawer, openModal } from '../ui.js';
import { loadFormOptions, setContactOpts } from '../forms.js';

let CONTACTS = [];
async function ensureContacts() {
  if (!CONTACTS.length) {
    try { const { items } = await api.get('/api/contacts?limit=200', { silent: true }); CONTACTS = items; setContactOpts(items); } catch { CONTACTS = []; }
  }
  return CONTACTS;
}

export async function meetingDialog(prefill = {}) {
  const list = await ensureContacts();
  const { meetingForm } = await import('../forms.js');
  return meetingForm(prefill, list);
}

export async function render(root, ctx) {
  const q = ctx.query;
  const tab = q.get('tab') || 'upcoming';
  await ensureContacts();
  root.innerHTML = `
    <div class="page-head">
      <div><div class="page-title">الاجتماعات</div><div class="page-sub">اجتماعاتك، محاضرها، والمهام الناتجة</div></div>
      <div class="page-actions">${state.perm('meetings.create') ? `<button class="btn btn-primary" id="mt-add">${icon('plus')} اجتماع جديد</button>` : ''}</div>
    </div>
    <div class="tabs mb-14">
      <button class="tab" data-t="upcoming">${icon('calendar')} القادمة</button>
      <button class="tab" data-t="past">${icon('clock')} السابقة</button>
    </div>
    <div id="mt-body"><div class="skel" style="height:300px"></div></div>`;
  root.querySelectorAll('.tab').forEach((b) => {
    b.classList.toggle('active', b.dataset.t === tab);
    b.onclick = () => { const p = new URLSearchParams(location.hash.split('?')[1] || ''); p.set('tab', b.dataset.t); location.hash = '#/meetings?' + p.toString(); };
  });
  const addBtn = root.querySelector('#mt-add');
  if (addBtn) addBtn.onclick = async () => { const r = await meetingDialog(); if (r) render(root, ctx); };

  try {
    const { items } = await api.get('/api/meetings?limit=100');
    const today = todayISO();
    const list = items.filter((m) => (tab === 'upcoming' ? (m.status === 'scheduled' && String(m.start_at).slice(0, 10) >= today) : (m.status === 'done' || String(m.start_at).slice(0, 10) < today)));
    const box = root.querySelector('#mt-body');
    if (!list.length) { box.innerHTML = emptyState('video', tab === 'upcoming' ? 'لا اجتماعات قادمة' : 'لا اجتماعات سابقة', tab === 'upcoming' ? 'جدول اجتماعك القادم' : ''); return; }
    box.innerHTML = `<div style="display:grid;gap:12px">${list.map((m) => {
      const att = m.attendees || [];
      return `<div class="card card-pad" data-id="${m.id}" style="cursor:pointer">
        <div class="flex aic gap-14 wrap">
          <div class="stat-icon si-violet" style="width:46px;height:46px">${icon('video')}</div>
          <div style="flex:1;min-width:200px">
            <div class="xtr" style="font-size:1rem">${esc(m.title)}</div>
            <div class="small muted mt-8 flex gap-14 wrap">
              <span class="flex aic gap-6">${icon('calendar')} ${fmtDate(m.start_at)} · ${fmtTime(m.start_at)}</span>
              ${m.location ? `<span class="flex aic gap-6">${icon('mapPin')} ${esc(m.location)}</span>` : ''}
              ${m.link ? `<span class="flex aic gap-6">${icon('link')} رابط</span>` : ''}
              ${m.project_name ? `<span class="flex aic gap-6">${icon('briefcase')} ${esc(m.project_name)}</span>` : ''}
            </div>
            ${att.length ? `<div class="flex aic gap-6 mt-8">${att.slice(0, 4).map((a) => `<span class="badge soft">${esc(a.first_name + (a.last_name ? ' ' + a.last_name : ''))}</span>`).join('')}${att.length > 4 ? `<span class="xs faint">+${att.length - 4}</span>` : ''}</div>` : ''}
          </div>
          <span class="badge b-${m.status}">${MEETING_STATUS[m.status] || m.status}</span>
        </div>
      </div>`;
    }).join('')}</div>`;
    box.querySelectorAll('[data-id]').forEach((card) => (card.onclick = () => openMeeting(card.dataset.id)));
  } catch {
    root.querySelector('#mt-body').innerHTML = emptyState('alert', 'تعذر التحميل');
  }
}

async function openMeeting(id) {
  let d;
  try { d = await api.get(`/api/meetings/${id}`); } catch { return; }
  const m = d.meeting;
  const ov = openDrawer({ title: 'الاجتماع', body: meetingBody(m, d.tasks) });
  const drawer = ov.querySelector('.drawer');
  bindMeetingDrawer(drawer, m, d.tasks);
}

function meetingBody(m, tasks) {
  return `<div>
    <div class="flex aic gap-10 mb-8"><span class="badge b-${m.status}">${MEETING_STATUS[m.status] || m.status}</span>
      ${m.project_name ? `<span class="badge soft">${esc(m.project_name)}</span>` : ''}</div>
    <h2 style="font-size:1.25rem;font-weight:800">${esc(m.title)}</h2>
    <div class="kv mt-14">
      <span class="k">الموعد</span><span>${fmtDateTime(m.start_at)}${m.end_at ? ' — ' + fmtTime(m.end_at) : ''}</span>
      <span class="k">المكان</span><span>${m.location ? esc(m.location) : '—'}</span>
      <span class="k">الرابط</span><span>${m.link ? `<a href="${esc(m.link)}" target="_blank">${esc(m.link)}</a>` : '—'}</span>
      <span class="k">الموضوع</span><span>${m.subject ? esc(m.subject) : '—'}</span>
    </div>
    ${m.agenda ? `<div class="mt-14"><div class="xtr small" style="color:var(--muted)">جدول الأعمال</div><p class="small mt-8" style="white-space:pre-wrap;line-height:1.9">${esc(m.agenda)}</p></div>` : ''}
    <div class="divider"></div>
    <div class="xtr small" style="color:var(--muted)">المحضر والقرارات</div>
    <div class="field mt-8"><textarea class="textarea" id="mt-minutes" rows="4" placeholder="سجل محضر الاجتماع هنا…">${esc(m.minutes || '')}</textarea></div>
    <div class="field"><textarea class="textarea" id="mt-decisions" rows="3" placeholder="القرارات المتخذة (سطر لكل قرار)">${esc(m.decisions || '')}</textarea></div>
    <div class="flex gap-8 wrap">
      <button class="btn btn-primary" id="mt-save-min">${icon('check')} حفظ المحضر</button>
      ${state.perm('tasks.create') ? `<button class="btn" id="mt-extract">${icon('sparkles')} استخراج مهام من المحضر</button>` : ''}
      ${state.perm('meetings.edit') ? `<button class="btn" id="mt-edit">${icon('edit')} تعديل البيانات</button>` : ''}
      ${state.perm('meetings.edit') ? `<button class="btn" id="mt-status">${m.status === 'scheduled' ? icon('checkCircle') + ' إنهاء الاجتماع' : icon('clock') + ' إرجاع لجدولة'}</button>` : ''}
      ${state.perm('meetings.delete') ? `<button class="btn btn-danger" id="mt-del">${icon('trash')}</button>` : ''}
    </div>
    ${tasks.length ? `<div class="divider"></div>
      <div class="xtr small" style="color:var(--muted)">المهام الناتجة (${tasks.length})</div>
      <div class="mt-8">${tasks.map((t) => `<div class="checkline ${t.status === 'completed' ? 'done' : ''}" data-tid="${t.id}">
        <div class="cb" title="تبديل الحالة">${icon('check')}</div>
        <div class="t">${esc(t.title)}</div>
        <span class="badge b-${t.status}">${TASK_STATUS[t.status]}</span>
      </div>`).join('')}</div>` : ''}
  </div>`;
}

function bindMeetingDrawer(drawer, m, tasks) {
  drawer.querySelector('#mt-save-min')?.addEventListener('click', async () => {
    await api.patch(`/api/meetings/${m.id}`, { minutes: drawer.querySelector('#mt-minutes').value, decisions: drawer.querySelector('#mt-decisions').value });
    toast('تم حفظ المحضر');
  });
  drawer.querySelector('#mt-status')?.addEventListener('click', async () => {
    const next = m.status === 'scheduled' ? 'done' : 'scheduled';
    await api.patch(`/api/meetings/${m.id}`, { status: next });
    toast('تم تحديث حالة الاجتماع');
    closeAndReopen();
  });
  drawer.querySelector('#mt-del')?.addEventListener('click', async () => {
    if (await confirmDialog('حذف هذا الاجتماع؟')) { await api.del('/api/meetings/' + m.id); drawer.querySelector('.drawer').remove(); window.dispatchEvent(new Event('hashchange')); }
  });
  drawer.querySelector('#mt-edit')?.addEventListener('click', async () => {
    const r = await meetingDialog(m);
    if (r) closeAndReopen();
  });
  drawer.querySelector('#mt-extract')?.addEventListener('click', extractTasksFlow);
  drawer.querySelectorAll('[data-tid]').forEach((row) => {
    row.querySelector('.cb').onclick = async () => {
      const tid = row.dataset.tid;
      const done = row.classList.contains('done');
      row.classList.toggle('done');
      const badge = row.querySelector('.badge');
      badge.className = 'badge b-' + (done ? 'in_progress' : 'completed');
      badge.textContent = TASK_STATUS[done ? 'in_progress' : 'completed'];
      try { await api.post(`/api/tasks/${tid}/status`, { status: done ? 'in_progress' : 'completed' }, { silent: true }); } catch { row.classList.toggle('done'); }
    };
  });
  async function closeAndReopen() {
    drawer.querySelector('.drawer').remove();
    setTimeout(() => openMeeting(m.id), 60);
  }

  async function extractTasksFlow() {
    const text = drawer.querySelector('#mt-minutes').value;
    if (!text.trim()) { toast('اكتب المحضر أولًا ثم استخرج المهام', 'info'); return; }
    let candidates = [];
    try { const r = await api.post('/api/ai/extract-tasks', { text }); candidates = r.candidates; } catch { candidates = []; }
    if (!candidates.length) { toast('لم يتم العثور على مهام واضحة في النص', 'info'); return; }
    const ov = openModal({
      title: `${icon('sparkles')} مهام مستخرجة من المحضر`,
      wide: true,
      body: `<p class="small muted mb-8">راجع المهام المقترحة وعدّل ما تشاء ثم أنشئها:</p>
        <div style="max-height:46vh;overflow-y:auto">${candidates.map((c, i) => `<div class="checkline" data-i="${i}" style="align-items:flex-start">
          <div class="cb on" style="margin-top:4px">${icon('check')}</div>
          <div style="flex:1"><input class="input" style="border:none;background:none;padding:4px 0;font-weight:600" value="${esc(c.text)}"/>
          <div class="xs faint mt-8 flex gap-10">${c.due_date ? `<span>الموعد: ${fmtDate(c.due_date)}</span>` : ''}${c.suggested_contact ? `<span>مرتبط: ${esc(c.suggested_contact)}</span>` : ''}</div></div>
        </div>`).join('')}</div>`,
      footer: `<button class="btn" id="ex-no">إلغاء</button><button class="btn btn-primary" id="ex-yes">${icon('checkSquare')} إنشاء المهام المحددة</button>`,
    });
    ov.querySelector('#ex-no').onclick = () => ov.__close();
    ov.querySelector('#ex-yes').onclick = async () => {
      const chosen = [...ov.querySelectorAll('.checkline')].filter((row) => {
        const cb = row.querySelector('.cb');
        return cb.classList.contains('on');
      }).map((row) => {
        const i = Number(row.dataset.i);
        const c = candidates[i];
        return { title: row.querySelector('input').value, due_date: c.due_date, contact_id: c.contact_id, priority: c.due_date && c.due_date <= todayISO() ? 'high' : 'medium' };
      }).filter((t) => t.title.trim());
      if (!chosen.length) { toast('اختر مهمة واحدة على الأقل', 'info'); return; }
      await api.post(`/api/meetings/${m.id}/tasks`, { tasks: chosen });
      ov.__close();
      toast(`تم إنشاء ${chosen.length} مهمة`);
      closeAndReopen();
    };
    ov.querySelectorAll('.cb').forEach((cb) => (cb.onclick = () => cb.classList.toggle('on')));
  }
}
