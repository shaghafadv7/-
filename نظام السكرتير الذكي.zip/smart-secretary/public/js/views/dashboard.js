// الصفحة الرئيسية — Dashboard
import { api } from '../api.js';
import { state } from '../state.js';
import { icon, esc, greeting, fmtDateFull, todayISO, fmtTime, fmtMoney, relTime, fmtDate, TASK_STATUS, FOLLOWUP_STATUS, KIND_ICONS } from '../core.js';
import { emptyState } from '../ui.js';
import { loadFormOptions, taskForm } from '../forms.js';

function statCard({ icon: ic, bg, label, value, route, sub }) {
  return `<div class="stat-card" data-route="${route}">
    <div class="stat-icon ${bg}">${icon(ic)}</div>
    <div><div class="stat-value">${value}</div><div class="stat-label">${label}</div>${sub ? `<div class="xs faint">${sub}</div>` : ''}</div>
  </div>`;
}

export async function render(root, ctx) {
  const u = state.user;
  root.innerHTML = `
    <div class="hello-bar">
      <div>
        <div class="hello">${greeting()}، ${esc(u.name.split(' ')[0])} 👋</div>
        <div class="hello-sub">إليك ملخص أعمالك اليوم</div>
      </div>
      <div class="date-chip">${icon('calendar')}<span>${fmtDateFull(todayISO())}</span></div>
    </div>
    <div id="dash-stats"><div class="skel" style="height:84px"></div></div>
    <div class="grid-2 mt-20">
      <div style="min-width:0">
        <div class="card"><div class="card-head"><h3>${icon('clock')} خط اليوم الزمني</h3>
          <a class="btn btn-sm btn-soft" href="#/today">${icon('sun')} يومي</a></div>
          <div class="card-pad" id="dash-timeline"></div></div>
        <div class="grid-2-eq mt-14">
          <div class="card"><div class="card-head"><h3>${icon('alert')} مهام عاجلة</h3><a class="link small" href="#/tasks" style="color:var(--primary);font-weight:600">عرض الكل</a></div>
            <div id="dash-urgent"></div></div>
          <div class="card"><div class="card-head"><h3>${icon('target')} متابعات مستحقة</h3><a class="link small" href="#/followups" style="color:var(--primary);font-weight:600">عرض الكل</a></div>
            <div id="dash-fu"></div></div>
        </div>
      </div>
      <div style="min-width:0">
        <div class="card"><div class="card-head"><h3>${icon('calendar')} المواعيد القادمة</h3></div><div id="dash-events"></div></div>
        <div class="card mt-14"><div class="card-head"><h3>${icon('phone')} آخر الاتصالات</h3><a class="link small" href="#/calls" style="color:var(--primary);font-weight:600">عرض الكل</a></div><div id="dash-calls"></div></div>
        <div class="card mt-14"><div class="card-head"><h3>${icon('activity')} آخر الأنشطة</h3></div><div id="dash-act"></div></div>
        <div class="card mt-14" style="background:linear-gradient(135deg, var(--primary-soft), transparent);border-color:var(--border)">
          <div class="card-pad" id="dash-summary"></div></div>
      </div>
    </div>`;

  try {
    const d = await api.get('/api/dashboard/summary');
    const s = d.stats;
    const statsEl = root.querySelector('#dash-stats');
    statsEl.className = 'stat-grid';
    statsEl.innerHTML =
      statCard({ icon: 'checkSquare', bg: 'si-primary', label: 'مهام اليوم', value: s.todayTasks, route: '#/tasks?due=today' }) +
      statCard({ icon: 'alert', bg: 'si-danger', label: 'المهام المتأخرة', value: s.overdueTasks, route: '#/tasks?due=overdue' }) +
      statCard({ icon: 'calendar', bg: 'si-info', label: 'مواعيد اليوم', value: s.todayEvents, route: '#/today' }) +
      statCard({ icon: 'video', bg: 'si-violet', label: 'اجتماعات قادمة (7 أيام)', value: s.upcomingMeetings, route: '#/meetings' }) +
      statCard({ icon: 'target', bg: 'si-danger', label: 'متابعات مستحقة', value: s.dueFollowups, route: '#/followups' }) +
      statCard({ icon: 'users', bg: 'si-warn', label: 'بانتظار الرد', value: s.pendingReplies, route: '#/workcenter' }) +
      statCard({ icon: 'file', bg: 'si-info', label: 'ملفات جديدة (7 أيام)', value: s.newFiles, route: '#/files' }) +
      statCard({ icon: 'checkCircle', bg: 'si-ok', label: 'مكتملة اليوم', value: s.completedToday, route: '#/tasks?status=completed' });
    statsEl.querySelectorAll('.stat-card').forEach((c) => (c.onclick = () => (location.hash = c.dataset.route)));

    // Timeline
    const tl = root.querySelector('#dash-timeline');
    tl.innerHTML = d.sections.todayTimeline.length
      ? d.sections.todayTimeline.slice(0, 8).map(tlItemHtml).join('')
      : emptyState('sun', 'لا مواعيد اليوم', 'استمتع بيومك أو أضف موعدًا جديدًا');
    bindTimeline(tl);

    // مهام عاجلة
    const urg = root.querySelector('#dash-urgent');
    urg.innerHTML = d.sections.urgentTasks.length
      ? d.sections.urgentTasks.map((t) => `<div class="list-row" data-route="#/tasks">
          <div class="tl-dot ${t.priority === 'urgent' ? 'kind-followup' : 'kind-task'}" style="${t.priority !== 'urgent' ? 'background:var(--warn-soft);color:var(--warn)' : ''}">${icon('zap')}</div>
          <div class="list-main"><div class="list-t">${esc(t.title)}</div>
          <div class="list-s"><span class="badge b-${t.priority}">${{ low: 'منخفضة', medium: 'متوسطة', high: 'عالية', urgent: 'عاجلة' }[t.priority]}</span>
          ${t.due_date ? `<span>حتى ${fmtDate(t.due_date)}</span>` : ''}${t.project_name ? `<span>${esc(t.project_name)}</span>` : ''}</div></div>
        </div>`).join('')
      : emptyState('checkCircle', 'لا مهام عاجلة', 'كل شيء تحت السيطرة');
    urg.querySelectorAll('[data-route]').forEach((r) => (r.onclick = () => (location.hash = r.dataset.route)));

    // متابعات مستحقة
    const fu = root.querySelector('#dash-fu');
    fu.innerHTML = d.sections.dueFollowups.length
      ? d.sections.dueFollowups.map((f) => `<div class="list-row" data-route="#/followups">
          <div class="tl-dot kind-followup">${icon('target')}</div>
          <div class="list-main"><div class="list-t">${esc(f.subject)}</div>
          <div class="list-s"><span>${esc([f.first_name, f.last_name].filter(Boolean).join(' ') || 'غير مرتبط')}</span>
          <span class="badge b-${f.status}">${FOLLOWUP_STATUS[f.status]}</span></div></div>
        </div>`).join('')
      : emptyState('checkCircle', 'لا متابعات مستحقة', 'رائع!');
    fu.querySelectorAll('[data-route]').forEach((r) => (r.onclick = () => (location.hash = r.dataset.route)));

    // مواعيد قادمة
    const ev = root.querySelector('#dash-events');
    ev.innerHTML = d.sections.upcomingEvents.length
      ? d.sections.upcomingEvents.map((e) => `<div class="list-row" data-route="#/calendar">
          <div class="tl-dot ${e.kind === 'meeting' ? 'kind-meeting' : 'kind-event'}">${icon(e.kind === 'meeting' ? 'video' : 'calendar')}</div>
          <div class="list-main"><div class="list-t">${esc(e.title)}</div>
          <div class="list-s"><span>${fmtDate(e.start_at)} · ${fmtTime(e.start_at)}</span>${e.location ? `<span>${esc(e.location)}</span>` : ''}</div></div>
        </div>`).join('')
      : emptyState('calendar', 'لا مواعيد قادمة');
    ev.querySelectorAll('[data-route]').forEach((r) => (r.onclick = () => (location.hash = r.dataset.route)));

    // آخر الاتصالات
    const calls = root.querySelector('#dash-calls');
    calls.innerHTML = d.sections.recentCalls.length
      ? d.sections.recentCalls.map((c) => `<div class="list-row" data-route="#/calls">
          <div class="call-dir cd-${c.direction}">${icon(c.direction === 'in' ? 'phoneIn' : c.direction === 'out' ? 'phoneOut' : 'phoneMissed')}</div>
          <div class="list-main"><div class="list-t">${esc(c.subject || 'اتصال')}</div>
          <div class="list-s"><span>${esc([c.first_name, c.last_name].filter(Boolean).join(' ') || c.phone || '')}</span><span>${relTime(c.called_at)}</span></div></div>
        </div>`).join('')
      : emptyState('phone', 'لا اتصالات مسجلة');
    calls.querySelectorAll('[data-route]').forEach((r) => (r.onclick = () => (location.hash = r.dataset.route)));

    // آخر الأنشطة
    const act = root.querySelector('#dash-act');
    act.innerHTML = d.sections.recentActivity.length
      ? d.sections.recentActivity.map((a) => `<div style="display:flex;gap:10px;padding:8px 0;border-bottom:1px solid var(--border);font-size:.83rem" class="small">
          <span class="badge soft" style="flex:none">${esc(a.action)}</span>
          <div style="min-width:0"><div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(a.details || a.entity || '')}</div>
          <div class="faint xs">${a.user_name ? esc(a.user_name) : ''} · ${relTime(a.created_at)}</div></div>
        </div>`).join('')
      : emptyState('activity', 'لا نشاط بعد');

    // ملخص سريع
    const sum = root.querySelector('#dash-summary');
    const doneCount = d.sections.todayTimeline.filter((i) => i.status === 'completed' || i.status === 'done').length;
    sum.innerHTML = `<div class="flex aic gap-10 mb-8">${icon('zap')}<span class="xtr">ملخص اليوم</span></div>
      <div class="small" style="line-height:2">
        • لديك <b>${s.todayTasks}</b> مهمة اليوم و<b>${s.overdueTasks}</b> متأخرة<br>
        • <b>${s.dueFollowups}</b> متابعة تحتاج ردك — <a href="#/followups" style="font-weight:700">ابدأ الآن</a><br>
        • مصروفات اليوم: <b>${fmtMoney(s.expensesToday)}</b><br>
        • أنجزت <b>${s.completedToday}</b> مهمة حتى الآن
      </div>`;
  } catch (e) {
    root.querySelector('#dash-stats').innerHTML = emptyState('alert', 'تعذر تحميل البيانات', 'تحقق من الاتصال ثم أعد المحاولة');
  }
  await loadFormOptions();
}

function tlItemHtml(i) {
  const ic = { event: 'calendar', meeting: 'video', task: 'checkSquare', reminder: 'bell', call: 'phone' }[i.kind] || 'calendar';
  return `<div class="tl-item ${i.status === 'completed' || i.status === 'done' ? 'done' : ''}">
    <div class="tl-time">${fmtTime(i.time) || '—'}</div>
    <div class="tl-dot kind-${i.kind}">${icon(ic)}</div>
    <div class="tl-body">
      <div class="tl-title">${esc(i.title)} ${i.status === 'completed' || i.status === 'done' ? '' : i.kind === 'task' ? `<span class="badge b-${i.status}">${TASK_STATUS[i.status]}</span>` : ''}</div>
      ${i.sub ? `<div class="tl-sub">${esc(i.sub)}</div>` : ''}
    </div>
  </div>`;
}
function bindTimeline(box) {
  box.querySelectorAll('.list-row').forEach((r) => (r.onclick = () => (location.hash = r.dataset.route)));
}
