// صفحة تسجيل الدخول
import { api, setToken } from '../api.js';
import { state, applyTheme } from '../state.js';
import { icon, esc } from '../core.js';
import { renderShell, refreshBadges } from '../shell.js';
import { renderRoute } from '../app.js';

export function renderLogin() {
  const app = document.getElementById('app');
  app.innerHTML = `
  <div class="login-wrap">
    <div class="login-card">
      <div class="login-logo">${icon('checkSquare')}</div>
      <h1 style="text-align:center;font-size:1.5rem;font-weight:800">السكرتير الذكي</h1>
      <p style="text-align:center;color:var(--muted);font-size:.9rem;margin:6px 0 24px">مركز التحكم اليومي في أعمالك</p>
      <form id="lf" novalidate>
        <div class="field"><label>البريد الإلكتروني</label>
          <input class="input" name="email" type="email" autocomplete="username" placeholder="name@company.com" value="admin@company.sa"/></div>
        <div class="field"><label>كلمة المرور</label>
          <input class="input" name="password" type="password" autocomplete="current-password" placeholder="••••••••" value="admin123"/></div>
        <div id="lf-err" style="color:var(--danger);font-size:.85rem;font-weight:600;margin-bottom:10px;display:none"></div>
        <button type="submit" class="btn btn-primary" style="width:100%;padding:12px;font-size:1rem" id="lf-btn">تسجيل الدخول ${icon('chevL')}</button>
      </form>
      <div class="divider"></div>
      <div style="font-size:.78rem;color:var(--muted);line-height:2">
        <div class="xtr" style="color:var(--text)">حسابات التجربة:</div>
        <div>المدير: admin@company.sa / admin123</div>
        <div>السكرتيرة: sara@company.sa / sara123</div>
        <div>الموظف: khalid@company.sa / khalid123</div>
      </div>
    </div>
  </div>`;

  const form = document.getElementById('lf');
  form.onsubmit = async (e) => {
    e.preventDefault();
    const btn = document.getElementById('lf-btn');
    const err = document.getElementById('lf-err');
    err.style.display = 'none';
    btn.disabled = true; btn.style.opacity = '.7';
    try {
      const { token, user } = await api.post('/api/auth/login', Object.fromEntries(new FormData(form).entries()));
      setToken(token);
      state.user = user;
      try { const m = await api.get('/api/auth/me'); state.company = m.company; state.settings = user.settings || {}; } catch { state.settings = {}; }
      applyTheme();
      renderShell();
      import('../state.js').then((s) => s.startNotificationsPoll());
      import('../state.js').then((s) => s.onHashChange(renderRoute));
      window.addEventListener('ss:refresh', async () => { await renderRoute(); });
      location.hash = '#/';
      await renderRoute();
      refreshBadges();
    } catch (e2) {
      err.textContent = e2.message || 'حدث خطأ';
      err.style.display = 'block';
    } finally {
      btn.disabled = false; btn.style.opacity = '1';
    }
  };
}
