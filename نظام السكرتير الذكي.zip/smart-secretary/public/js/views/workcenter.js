// مركز العمل — "صندوق عمل السكرتير"
import { api } from '../api.js';
import { state } from '../state.js';
import { icon, esc, fmtDate, fmtTime, todayISO, relDay, PRIORITIES, TASK_STATUS, FOLLOWUP_STATUS } from '../core.js';
import { emptyState } from '../ui.js';

export async function render(root, ctx) {
  const u = state.user;
  root.innerHTML = `
    <div class="page-head">
      <div><div class="page-title">مركز العمل</div>
      <div class="page-sub">أهم ما يحتاج انتباهك الآن — مرتب حسب الأولوية</div></div>
      <div class="date-chip">${icon('calendar')}<span id="wc-date"></span></div>
    </div>
    <div id="wc-body"><div class="skel" style="height:400px"></div></div>`;
  root.querySelector('#wc-date').textContent = new Intl.DateTimeFormat('ar', { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date());

  try {
    const d = await api.get('/api/dashboard/workcenter');
    const today = todayISO();
    const box = root.querySelector('#wc-body');
    box.innerHTML = `
      <div class="grid-2-eq">
        ${section('عاجل — تتطلب إجراء فوريًا', 'alert', 'var(--danger)',
          d.urgent.map((t) => `<div class="list-row" data-go="#/tasks">
            <div class="tl-dot kind-followup">${icon('zap')}</div>
            <div class="list-main"><div class="list-t">${esc(t.title)}</div>
            <div class="list-s"><span class="badge b-${t.priority}">${PRIORITIES[t.priority]}</span>
            ${t.due_date ? `<span class="${t.due_date < today ? 'xtr' : ''}" style="${t.due_date < today ? 'color:var(--danger)' : ''}">حتى ${fmtDate(t.due_date)}</span>` : ''}
            ${t.project_name ? `<span>${esc(t.project_name)}</span>` : ''}${t.first_name ? `<span>👤 ${esc(t.first_name)}</span>` : ''}</div></div>
          </div>`).join('') || emptyRow('لا أعمال عاجلة', 'checkCircle'))}
        ${section('اليوم — ما يجب إنجازه', 'checkSquare', 'var(--primary)',
          d.today.map((t) => `<div class="list-row" data-go="#/tasks">
            <div class="tl-dot kind-task">${icon('checkSquare')}</div>
            <div class="list-main"><div class="list-t">${esc(t.title)}</div>
            <div class="list-s">${t.due_time ? `<span>${fmtTime(t.due_time)}</span>` : ''}<span class="badge b-${t.status}">${TASK_STATUS[t.status]}</span>${t.project_name ? `<span>${esc(t.project_name)}</span>` : ''}</div></div>
          </div>`).join('') || emptyRow('لا مهام اليوم', 'sun'))}
      </div>
      <div class="grid-2-eq mt-14">
        ${section('بانتظار الرد — أشخاص ينتظرون منك', 'users', 'var(--warn)',
          [...d.waiting.followups.map((f) => fuRow(f, '#/followups')),
           ...d.waiting.tasks.map((t) => `<div class="list-row" data-go="#/tasks">
             <div class="tl-dot kind-task" style="background:var(--warn-soft);color:var(--warn)">${icon('checkSquare')}</div>
             <div class="list-main"><div class="list-t">${esc(t.title)}</div>
             <div class="list-s"><span>مهمة بانتظار الرد</span>${t.first_name ? `<span>👤 ${esc(t.first_name)}</span>` : ''}</div></div>
           </div>`)].join('') || emptyRow('لا أحد ينتظر ردك', 'checkCircle'))}
        ${section('المتابعات المستحقة', 'target', 'var(--danger)',
          d.followups.map((f) => fuRow(f, '#/followups')).join('') || emptyRow('لا متابعات مستحقة', 'checkCircle'))}
      </div>
      <div class="grid-2-eq mt-14">
        ${section('القادم — اجتماعات ومواعيد (7 أيام)', 'calendar', 'var(--info)',
          d.upcoming.map((e) => `<div class="list-row" data-go="${e.kind === 'meeting' ? '#/meetings' : '#/calendar'}">
            <div class="tl-dot kind-${e.kind}">${icon(e.kind === 'meeting' ? 'video' : 'calendar')}</div>
            <div class="list-main"><div class="list-t">${esc(e.title)}</div>
            <div class="list-s"><span>${relDay(e.start_at)} · ${fmtTime(e.start_at)}</span>${e.location ? `<span>${esc(e.location)}</span>` : ''}</div></div>
          </div>`).join('') || emptyRow('لا مواعيد قادمة', 'calendar'))}
        ${section('مؤجل — أعمال مؤجلة', 'archive', 'var(--violet)',
          d.postponed.map((f) => fuRow(f, '#/followups')).join('') || emptyRow('لا أعمال مؤجلة', 'checkCircle'))}
      </div>`;
    box.querySelectorAll('[data-go]').forEach((r) => (r.onclick = () => (location.hash = r.dataset.go)));
  } catch {
    root.querySelector('#wc-body').innerHTML = emptyState('alert', 'تعذر التحميل');
  }
}
function section(title, ic, color, inner) {
  const count = (inner.match(/list-row/g) || []).length;
  return `<div class="card" style="overflow:hidden"><div class="card-head" style="border-bottom:1px solid var(--border)">
    <h3 style="gap:8px"><span style="color:${color}">${icon(ic)}</span> ${title} ${count ? `<span class="count">${count}</span>` : ''}</h3></div>
    <div class="card-pad" style="padding-top:8px;padding-bottom:8px">${inner}</div></div>`;
}
function emptyRow(t, ic) {
  return `<div class="empty" style="padding:18px"><div class="ic" style="width:44px;height:44px;margin-bottom:8px">${icon(ic)}</div><p style="margin:0">${t}</p></div>`;
}
function fuRow(f, go) {
  const name = [f.first_name, f.last_name].filter(Boolean).join(' ');
  return `<div class="list-row" data-go="${go}">
    <div class="tl-dot kind-followup">${icon('target')}</div>
    <div class="list-main"><div class="list-t">${esc(f.subject)}</div>
    <div class="list-s"><span>${name || 'غير مرتبط'}</span><span class="badge b-${f.status}">${FOLLOWUP_STATUS[f.status]}</span>
    ${f.next_date ? `<span>${relDay(f.next_date)}</span>` : ''}</div></div>
  </div>`;
}
