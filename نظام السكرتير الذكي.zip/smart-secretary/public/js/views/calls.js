// سجل الاتصالات
import { api } from '../api.js';
import { state } from '../state.js';
import { icon, esc, fmtDateTime, fmtDur, todayISO } from '../core.js';
import { emptyState, confirmDialog, toast, openModal } from '../ui.js';
import { callForm, loadFormOptions, reminderForm } from '../forms.js';

const DIR = { in: ['وارد', 'phoneIn', 'cd-in'], out: ['صادر', 'phoneOut', 'cd-out'], missed: ['فائت', 'phoneMissed', 'cd-missed'] };

export async function render(root, ctx) {
  const q = ctx.query;
  root.innerHTML = `
    <div class="page-head">
      <div><div class="page-title">الاتصالات</div><div class="page-sub" id="cl-sub">سجل مكالماتك مع العملاء والشركاء</div></div>
      <div class="page-actions">${state.perm('calls.create') ? `<button class="btn btn-primary" id="cl-add">${icon('plus')} تسجيل اتصال</button>` : ''}</div>
    </div>
    <div class="toolbar">
      <input class="input" id="cl-q" placeholder="بحث بالموضوع، النتيجة، الرقم…" value="${esc(q.get('q') || '')}"/>
      <select class="select" id="cl-dir"><option value="">كل الأنواع</option>
        <option value="in" ${q.get('direction') === 'in' ? 'selected' : ''}>وارد</option>
        <option value="out" ${q.get('direction') === 'out' ? 'selected' : ''}>صادر</option>
        <option value="missed" ${q.get('direction') === 'missed' ? 'selected' : ''}>فائت</option></select>
      <input type="date" class="input" id="cl-from" value="${q.get('from') || ''}"/>
      <input type="date" class="input" id="cl-to" value="${q.get('to') || ''}"/>
    </div>
    <div id="cl-body"><div class="skel" style="height:300px"></div></div>`;

  ['cl-q', 'cl-dir', 'cl-from', 'cl-to'].forEach((id) => {
    const inp = root.querySelector('#' + id);
    inp.addEventListener(inp.tagName === 'SELECT' ? 'change' : 'input', () => {
      const p = new URLSearchParams(location.hash.split('?')[1] || '');
      const k = { 'cl-q': 'q', 'cl-dir': 'direction', 'cl-from': 'from', 'cl-to': 'to' }[id];
      if (inp.value) p.set(k, inp.value); else p.delete(k);
      location.hash = '#/calls' + (p.toString() ? '?' + p.toString() : '');
    });
  });
  const addBtn = root.querySelector('#cl-add');
  if (addBtn) addBtn.onclick = async () => { await loadFormOptions(); const r = await callForm(); if (r) render(root, ctx); };

  let offset = 0;
  const PAGE = 30;
  const load = async (off = 0) => {
    offset = off;
    const p = new URLSearchParams(Object.fromEntries(q.entries()));
    p.set('limit', String(PAGE)); p.set('offset', String(off));
    const data = await api.get(`/api/calls?${p.toString()}`);
    root.querySelector('#cl-sub').textContent = `${data.total} اتصال`;
    const box = root.querySelector('#cl-body');
    if (!data.items.length) { box.innerHTML = emptyState('phone', 'لا اتصالات مسجلة', 'سجّل مكالماتك لتبني ذاكرة عملك', state.perm('calls.create') ? '<button class="btn btn-primary" id="cl-add2">تسجيل اتصال</button>' : '');
      const b = box.querySelector('#cl-add2'); if (b) b.onclick = addBtn.onclick; return; }
    const html = `<div class="card table-wrap"><table class="table"><thead><tr>
      <th></th><th>الشخص</th><th>الموضوع</th><th>الوقت</th><th>المدة</th><th>النتيجة</th><th style="width:150px"></th>
    </tr></thead><tbody>${data.items.map((c) => {
      const [lbl, ic, cls] = DIR[c.direction] || DIR.out;
      return `<tr data-id="${c.id}">
        <td><div class="call-dir ${cls}">${icon(ic)}</div></td>
        <td><a href="#/contacts/${c.contact_id}" style="font-weight:700">${esc([c.first_name, c.last_name].filter(Boolean).join(' ') || c.phone || '—')}</a>${c.company ? `<div class="xs faint">${esc(c.company)}</div>` : ''}</td>
        <td>${esc(c.subject || '<span class="faint">—</span>')}</td>
        <td class="small" style="white-space:nowrap">${fmtDateTime(c.called_at)}</td>
        <td class="small">${fmtDur(c.duration_seconds)}</td>
        <td class="small" style="max-width:220px">${esc(c.outcome || '—')}${c.needs_follow_up ? ' <span class="badge b-needs">متابعة</span>' : ''}</td>
        <td><div class="row-actions" style="opacity:1">
          ${state.perm('tasks.create') ? `<button class="icon-btn" data-act="task" title="تحويل لمهمة" style="color:var(--primary)">${icon('checkSquare')}</button>` : ''}
          ${state.perm('reminders.create') ? `<button class="icon-btn" data-act="rem" title="تحويل لتذكير" style="color:var(--warn)">${icon('bell')}</button>` : ''}
          ${state.perm('calls.edit') ? `<button class="icon-btn" data-act="edit" title="تعديل">${icon('edit')}</button>` : ''}
          ${state.perm('calls.delete') ? `<button class="icon-btn danger" data-act="del" title="حذف">${icon('trash')}</button>` : ''}
        </div></td>
      </tr>`;
    }).join('')}</tbody></table></div>
    ${data.offset + data.limit < data.total ? `<button class="load-more" id="cl-more">تحميل المزيد</button>` : ''}`;
    if (off === 0) box.innerHTML = html; else {
      box.querySelector('.card').insertAdjacentHTML('beforeend', ''); // no-op
      box.innerHTML = html;
    }
    box.querySelectorAll('tr[data-id]').forEach((tr) => {
      tr.querySelectorAll('[data-act]').forEach((btn) => {
        btn.onclick = async () => {
          const id = tr.dataset.id;
          const item = data.items.find((x) => x.id === Number(id));
          if (btn.dataset.act === 'edit') { const r = await callForm(item); if (r) render(root, ctx); }
          if (btn.dataset.act === 'del') { if (await confirmDialog('حذف هذا الاتصال؟')) { await api.del('/api/calls/' + id); render(root, ctx); } }
          if (btn.dataset.act === 'task') {
            const ov = openModal({ title: 'تحويل إلى مهمة', body: `<div class="field"><label>عنوان المهمة</label><input class="input" id="ct-title" value="متابعة اتصال: ${esc(item.subject || '')}"/></div>
              <div class="field"><label>الموعد النهائي</label><input type="date" class="input" id="ct-due" value="${todayISO()}"/></div>`,
              footer: `<button class="btn" id="ct-no">إلغاء</button><button class="btn btn-primary" id="ct-yes">${icon('checkSquare')} إنشاء المهمة</button>` });
            ov.querySelector('#ct-no').onclick = () => ov.__close();
            ov.querySelector('#ct-yes').onclick = async () => {
              await api.post(`/api/calls/${id}/to-task`, { title: ov.querySelector('#ct-title').value, due_date: ov.querySelector('#ct-due').value });
              ov.__close(); toast('تم إنشاء المهمة'); render(root, ctx);
            };
          }
          if (btn.dataset.act === 'rem') {
            const { reminderForm: rf } = await import('../forms.js');
            const r = await rf({ title: `متابعة اتصال: ${item.subject || ''}`, contact_id: item.contact_id });
            if (r) render(root, ctx);
          }
        };
      });
    });
    const more = box.querySelector('#cl-more');
    if (more) more.onclick = () => load(off + PAGE);
  };
  try { await load(0); } catch { root.querySelector('#cl-body').innerHTML = emptyState('alert', 'تعذر التحميل'); }
}
