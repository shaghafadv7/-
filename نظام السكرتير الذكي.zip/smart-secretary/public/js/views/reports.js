// التقارير — مؤشرات + رسوم بيانية + تصدير CSV/PDF
import { api } from '../api.js';
import { state } from '../state.js';
import { icon, esc, fmtDate, fmtMoney, TASK_STATUS, PROJECT_STATUS } from '../core.js';
import { emptyState, barChart, lineChart, donut, toast } from '../ui.js';

const RANGES = { week: 'هذا الأسبوع', month: 'هذا الشهر', quarter: 'هذا الربع', year: 'هذه السنة' };
const STATUS_COLORS = { new: 'var(--info)', in_progress: 'var(--primary)', waiting: 'var(--warn)', completed: 'var(--ok)', cancelled: 'var(--faint)' };

export async function render(root, ctx) {
  const q = ctx.query;
  const range = RANGES[q.get('range')] ? q.get('range') : 'month';
  root.innerHTML = `
    <div class="page-head">
      <div><div class="page-title">التقارير</div><div class="page-sub">نظرة تحليلية على أداء عملك</div></div>
      <div class="page-actions no-print">
        <div class="seg">
          ${Object.entries(RANGES).map(([k, v]) => `<button data-r="${k}" class="${k === range ? 'active' : ''}">${v}</button>`).join('')}
        </div>
        <button class="btn" id="rp-csv">${icon('download')} CSV</button>
        <button class="btn" id="rp-excel">${icon('download')} Excel</button>
        <button class="btn" id="rp-pdf">${icon('printer')} PDF</button>
      </div>
    </div>
    <div class="print-head no-print hidden" style="text-align:center;margin-bottom:16px">
      <h2>تقرير الأداء — السكرتير الذكي</h2>
      <div class="muted small" id="rp-print-sub"></div>
    </div>
    <div id="rp-body"><div class="skel" style="height:300px"></div></div>`;

  root.querySelectorAll('[data-r]').forEach((b) => {
    b.onclick = () => {
      const p = new URLSearchParams(location.hash.split('?')[1] || '');
      p.set('range', b.dataset.r);
      location.hash = '#/reports?' + p.toString();
    };
  });
  root.querySelector('#rp-pdf').onclick = () => window.print();
  root.querySelector('#rp-csv').onclick = () => downloadCsv('tasks');
  root.querySelector('#rp-excel').onclick = () => {
    const t = ['tasks', 'calls', 'expenses'].find(() => true);
    api.download(`/api/reports/export.csv?type=expenses&range=${range}`, `expenses-${range}.csv`).then(() => toast('تم تنزيل ملف Excel (CSV)'));
  };

  async function downloadCsv(type) {
    try {
      await api.download(`/api/reports/export.csv?type=${type}&range=${range}`, `${type}-${range}.csv`);
      toast('تم تنزيل الملف');
    } catch { /* handled */ }
  }

  try {
    const [s, prod, expCat, projs, act] = await Promise.all([
      api.get(`/api/reports/summary?range=${range}`),
      api.get('/api/reports/productivity?days=30'),
      api.get(`/api/reports/expenses?range=${range}&group=category`),
      api.get('/api/reports/projects'),
      api.get('/api/reports/activity?days=14'),
    ]);
    root.querySelector('#rp-print-sub').textContent = `${RANGES[range]} — من ${fmtDate(s.from)} إلى ${fmtDate(s.to)}`;
    const box = root.querySelector('#rp-body');
    box.innerHTML = `
      <div class="stat-grid">
        ${mini('checkCircle', s.tasks.completed, 'مهام مكتملة', 'si-ok')}
        ${mini('alert', s.tasks.overdue, 'مهام متأخرة', 'si-danger')}
        ${mini('video', s.meetings, 'اجتماعات', 'si-violet')}
        ${mini('phone', s.calls.total, 'اتصالات', 'si-info')}
        ${mini('target', s.followups.open, 'متابعات مفتوحة', 'si-warn')}
        ${mini('dollar', fmtMoney(s.expenses.total.t), 'مصروفات', 'si-primary')}
        ${mini('user', s.newContacts, 'أشخاص جدد', 'si-violet')}
        ${mini('checkSquare', s.tasks.open, 'مهام مفتوحة', 'si-info')}
      </div>
      <div class="grid-2 mt-14">
        <div class="card"><div class="card-head"><h3>${icon('trending')} الإنتاجية (آخر 30 يوم)</h3></div>
          <div class="card-pad">${lineChart({ labels: prod.rows.map((r) => r.date), series: [
            { name: 'مكتملة', values: prod.rows.map((r) => r.done) },
            { name: 'جديدة', values: prod.rows.map((r) => r.created) },
          ]})}
          <div class="legend"><span><i style="background:var(--primary)"></i>مكتملة</span><span><i style="background:var(--gold)"></i>جديدة</span></div></div></div>
        <div class="card"><div class="card-head"><h3>${icon('pie')} المهام حسب الحالة</h3></div>
          <div class="card-pad" style="text-align:center">${donut({
            segments: s.tasks.byStatus.map((x) => ({ value: x.c, color: STATUS_COLORS[x.status] || 'var(--muted)' })),
            centerLabel: s.tasks.byStatus.reduce((a, x) => a + x.c, 0), centerSub: 'إجمالي', size: 180 })}
          <div class="legend" style="justify-content:center">${s.tasks.byStatus.map((x) => `<span><i style="background:${STATUS_COLORS[x.status]}"></i>${TASK_STATUS[x.status] || x.status} (${x.c})</span>`).join('')}</div></div></div>
      </div>
      <div class="grid-2 mt-14">
        <div class="card"><div class="card-head"><h3>${icon('chart')} المصروفات حسب التصنيف</h3></div>
          <div class="card-pad">${expCat.rows.length ? barChart({ labels: expCat.rows.map((r) => EXPC_LABELS[r.category] || r.category), values: expCat.rows.map((r) => Math.round(r.total)), color: 'var(--warn)', height: 180 }) : emptyState('chart', 'لا بيانات')}</div></div>
        <div class="card"><div class="card-head"><h3>${icon('activity')} نشاط المستخدمين (14 يوم)</h3></div>
          <div class="card-pad" style="padding:12px">${act.rows.map((r, i) => `<div class="flex aic gap-10" style="padding:7px 8px">
            <span class="small muted" style="width:20px">${i + 1}</span>
            <div style="flex:1"><div class="small bold">${esc(r.name)}</div>
            <div class="progress thin mt-8"><div class="bar" style="width:${Math.min(100, (r.actions / Math.max(...act.rows.map((x) => x.actions), 1)) * 100)}%"></div></div></div>
            <span class="small muted">${r.actions} عملية</span>
          </div>`).join('') || emptyState('activity', 'لا بيانات')}</div></div>
      </div>
      <div class="section-title mt-20">${icon('briefcase')} الأعمال حسب المشروع</div>
      <div class="card table-wrap"><table class="table"><thead><tr>
        <th>المشروع</th><th>الحالة</th><th>الإنجاز</th><th>المهام</th><th>المكتملة</th><th>المصروفات</th><th>الموعد النهائي</th>
      </tr></thead><tbody>${projs.rows.map((p) => `<tr>
        <td class="bold" style="border-inline-start:4px solid ${p.color || 'var(--primary)'}">${esc(p.name)}</td>
        <td><span class="badge soft">${PROJECT_STATUS[p.status] || p.status}</span></td>
        <td style="min-width:140px"><div class="flex aic gap-10"><div class="progress thin" style="flex:1"><div class="bar" style="width:${p.progress}%"></div></div><span class="xs bold">${p.progress}%</span></div></td>
        <td>${p.total_tasks}</td><td>${p.done_tasks}</td>
        <td class="money">${fmtMoney(p.expenses)}</td>
        <td class="small">${p.due_date ? fmtDate(p.due_date) : '—'}</td>
      </tr>`).join('') || '<tr><td colspan="7" class="muted" style="text-align:center;padding:20px">لا مشاريع</td></tr>'}</tbody></table></div>`;
  } catch {
    root.querySelector('#rp-body').innerHTML = emptyState('alert', 'تعذر تحميل التقارير');
  }
}
const EXPC_LABELS = { meals: 'ضيافة', transport: 'مواصلات', marketing: 'تسويق', software: 'برامج', supplies: 'قرطاسية', travel: 'سفر', utilities: 'مرافق', other: 'أخرى' };
function mini(ic, val, label, bg) {
  return `<div class="stat-card" style="cursor:default"><div class="stat-icon ${bg}">${icon(ic)}</div>
    <div><div class="stat-value" style="font-size:1.2rem">${val}</div><div class="stat-label">${label}</div></div></div>`;
}
