// المصروفات
import { api } from '../api.js';
import { state } from '../state.js';
import { icon, esc, fmtDate, fmtMoney, EXPENSE_CATS, PAY_METHODS } from '../core.js';
import { emptyState, confirmDialog, donut } from '../ui.js';
import { expenseForm, loadFormOptions } from '../forms.js';

const CAT_COLORS = ['#0e8074', '#3565d9', '#d97706', '#6d5bd0', '#be185d', '#1f9d61', '#c8a24a', '#66788c'];

export async function render(root, ctx) {
  const q = ctx.query;
  root.innerHTML = `
    <div class="page-head">
      <div><div class="page-title">المصروفات</div><div class="page-sub">تتبع مصاريف عملك بدقة</div></div>
      <div class="page-actions">${state.perm('expenses.create') ? `<button class="btn btn-primary" id="ex-add">${icon('plus')} مصروف جديد</button>` : ''}</div>
    </div>
    <div class="stat-grid" id="ex-stats"><div class="skel" style="height:84px"></div></div>
    <div class="grid-2 mt-14">
      <div class="card"><div class="card-head"><h3>${icon('pie')} حسب التصنيف (هذا الشهر)</h3></div>
        <div class="card-pad" id="ex-chart"></div></div>
      <div class="card"><div class="card-head"><h3>${icon('clock')} أحدث المصروفات</h3></div>
        <div id="ex-recent"></div></div>
    </div>
    <div class="toolbar mt-14">
      <input class="input" id="ex-q" placeholder="بحث…" value="${esc(q.get('q') || '')}"/>
      <select class="select" id="ex-cat"><option value="">كل التصنيفات</option>${Object.entries(EXPENSE_CATS).map(([k, v]) => `<option value="${k}" ${q.get('category') === k ? 'selected' : ''}>${v}</option>`).join('')}</select>
      <input type="date" class="input" id="ex-from" value="${q.get('from') || ''}"/>
      <input type="date" class="input" id="ex-to" value="${q.get('to') || ''}"/>
    </div>
    <div id="ex-body"><div class="skel" style="height:200px"></div></div>`;

  ['ex-q', 'ex-cat', 'ex-from', 'ex-to'].forEach((id) => {
    const inp = root.querySelector('#' + id);
    inp.addEventListener(inp.tagName === 'SELECT' ? 'change' : 'input', () => {
      const p = new URLSearchParams(location.hash.split('?')[1] || '');
      const k = { 'ex-q': 'q', 'ex-cat': 'category', 'ex-from': 'from', 'ex-to': 'to' }[id];
      if (inp.value) p.set(k, inp.value); else p.delete(k);
      location.hash = '#/expenses' + (p.toString() ? '?' + p.toString() : '');
    });
  });
  const addBtn = root.querySelector('#ex-add');
  if (addBtn) addBtn.onclick = async () => { await loadFormOptions(); const r = await expenseForm(); if (r) render(root, ctx); };

  try {
    const sum = await api.get('/api/expenses/summary');
    root.querySelector('#ex-stats').className = 'stat-grid';
    root.querySelector('#ex-stats').innerHTML =
      statBox('dollar', fmtMoney(sum.today.total), 'مصروفات اليوم', `si-primary`, `${sum.today.n} عملية`) +
      statBox('calendar', fmtMoney(sum.week.total), 'هذا الأسبوع', 'si-info', `${sum.week.n} عملية`) +
      statBox('pie', fmtMoney(sum.month.total), 'هذا الشهر', 'si-violet', `${sum.month.n} عملية`) +
      statBox('trending', fmtMoney(sum.recent[0]?.amount || 0), 'آخر مصروف', 'si-warn', sum.recent[0] ? fmtDate(sum.recent[0].expense_date) : '');
    const total = sum.byCategory.reduce((s, x) => s + x.total, 0) || 1;
    root.querySelector('#ex-chart').innerHTML = sum.byCategory.length
      ? `<div class="flex gap-14 aic wrap" style="align-items:center">
          <div style="flex:none">${donut({ segments: sum.byCategory.map((c, i) => ({ value: c.total, color: CAT_COLORS[i % CAT_COLORS.length] })), centerLabel: fmtMoney(sum.month.total).replace(' ر.س', ''), centerSub: 'هذا الشهر', size: 170 })}</div>
          <div style="flex:1;min-width:160px">${sum.byCategory.map((c, i) => `<div class="flex aic jcb small" style="padding:5px 0;border-bottom:1px solid var(--border)">
            <span class="flex aic gap-6"><i style="width:10px;height:10px;border-radius:3px;background:${CAT_COLORS[i % CAT_COLORS.length]};display:inline-block"></i>${EXPENSE_CATS[c.category] || c.category}</span>
            <b>${fmtMoney(c.total)}</b></div>`).join('')}</div>
        </div>`
      : emptyState('pie', 'لا مصروفات هذا الشهر');
    root.querySelector('#ex-recent').innerHTML = sum.recent.length
      ? sum.recent.map((e) => `<div class="row-card" style="cursor:default">
        <div class="tl-dot ${['meals', 'travel'].includes(e.category) ? 'kind-reminder' : 'kind-event'}">${icon('dollar')}</div>
        <div class="list-main"><div class="list-t">${esc(e.description || EXPENSE_CATS[e.category] || 'مصروف')}</div>
        <div class="list-s"><span>${fmtDate(e.expense_date)}</span><span>${PAY_METHODS[e.payment_method] || ''}</span>${e.project_name ? `<span>${esc(e.project_name)}</span>` : ''}</div></div>
        <b>${fmtMoney(e.amount)}</b>
      </div>`).join('')
      : emptyState('dollar', 'لا مصروفات بعد');

    // الجدول
    const p = new URLSearchParams(Object.fromEntries(q.entries()));
    p.set('limit', '50');
    const data = await api.get(`/api/expenses?${p.toString()}`);
    const box = root.querySelector('#ex-body');
    box.innerHTML = data.items.length ? `<div class="card table-wrap"><table class="table"><thead><tr>
      <th>الوصف</th><th>التصنيف</th><th>التاريخ</th><th>طريقة الدفع</th><th>المرتبطة به</th><th style="text-align:end">المبلغ</th><th style="width:90px"></th>
    </tr></thead><tbody>${data.items.map((e) => `<tr data-id="${e.id}">
      <td class="bold">${esc(e.description || '—')}</td>
      <td><span class="badge soft">${EXPENSE_CATS[e.category] || e.category}</span></td>
      <td class="small">${fmtDate(e.expense_date)}</td>
      <td class="small">${PAY_METHODS[e.payment_method] || ''}</td>
      <td class="small">${[e.first_name, e.project_name].filter(Boolean).map(esc).join(' • ') || '<span class="faint">—</span>'}</td>
      <td class="money" style="text-align:end">${fmtMoney(e.amount)}</td>
      <td><div class="row-actions" style="opacity:1">
        ${state.perm('expenses.edit') ? `<button class="icon-btn" data-act="edit">${icon('edit')}</button>` : ''}
        ${state.perm('expenses.delete') ? `<button class="icon-btn danger" data-act="del">${icon('trash')}</button>` : ''}
      </div></td>
    </tr>`).join('')}</tbody></table></div>`
      : emptyState('dollar', 'لا مصروفات مسجلة');
    box.querySelectorAll('tr[data-id]').forEach((tr) => {
      tr.querySelectorAll('[data-act]').forEach((btn) => {
        btn.onclick = async () => {
          const e2 = data.items.find((x) => x.id === Number(tr.dataset.id));
          if (btn.dataset.act === 'edit') { const r = await expenseForm(e2); if (r) render(root, ctx); }
          if (btn.dataset.act === 'del') { if (await confirmDialog('حذف هذا المصروف؟')) { await api.del('/api/expenses/' + e2.id); render(root, ctx); } }
        };
      });
    });
  } catch {
    root.querySelector('#ex-body').innerHTML = emptyState('alert', 'تعذر التحميل');
  }
}
function statBox(ic, val, label, bg, sub) {
  return `<div class="stat-card" style="cursor:default"><div class="stat-icon ${bg}">${icon(ic)}</div>
    <div><div class="stat-value" style="font-size:1.15rem">${val}</div><div class="stat-label">${label}</div>${sub ? `<div class="xs faint">${sub}</div>` : ''}</div></div>`;
}
