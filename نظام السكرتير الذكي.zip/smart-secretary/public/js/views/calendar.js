// التقويم — شهر / أسبوع / يوم / Agenda
import { api } from '../api.js';
import { state } from '../state.js';
import { icon, esc, fmtDate, fmtTime, todayISO } from '../core.js';
import { emptyState, openDrawer, confirmDialog } from '../ui.js';
import { eventForm, loadFormOptions } from '../forms.js';

const MONTH_NAMES = new Intl.DateTimeFormat('ar', { month: 'long', year: 'numeric' });
const DAYS = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

export async function render(root, ctx) {
  const q = ctx.query;
  const view = q.get('view') || 'month';
  let cursor = q.get('date') || todayISO();
  root.innerHTML = `
    <div class="page-head">
      <div><div class="page-title">التقويم</div><div class="page-sub" id="cal-sub"></div></div>
      <div class="page-actions">
        <div class="tabs">
          <button class="tab" data-v="month">${icon('calendar')} شهر</button>
          <button class="tab" data-v="week">أسبوع</button>
          <button class="tab" data-v="day">يوم</button>
          <button class="tab" data-v="agenda">Agenda</button>
        </div>
        <button class="btn" id="cal-prev">${icon('chevR')}</button>
        <button class="btn" id="cal-today">اليوم</button>
        <button class="btn" id="cal-next">${icon('chevL')}</button>
        ${state.perm('calendar.create') ? `<button class="btn btn-primary" id="cal-add">${icon('plus')} موعد</button>` : ''}
      </div>
    </div>
    <div id="cal-body"><div class="skel" style="height:320px"></div></div>`;

  const params = new URLSearchParams(location.hash.split('?')[1] || '');
  const go = () => { params.set('view', view); if (cursor) params.set('date', cursor); location.hash = '#/calendar?' + params.toString(); };
  root.querySelectorAll('.tab').forEach((b) => {
    b.classList.toggle('active', b.dataset.v === view);
    b.onclick = () => { view = b.dataset.v; params.set('view', view); location.hash = '#/calendar?' + params.toString(); };
  });
  const shift = (n, unit) => {
    const d = new Date(cursor + 'T12:00:00');
    if (unit === 'month') d.setMonth(d.getMonth() + n);
    else d.setDate(d.getDate() + n * (view === 'week' ? 7 : 1));
    const p = (x) => String(x).padStart(2, '0');
    cursor = `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
    go();
  };
  root.querySelector('#cal-prev').onclick = () => shift(-1, view);
  root.querySelector('#cal-next').onclick = () => shift(1, view);
  root.querySelector('#cal-today').onclick = () => { cursor = todayISO(); go(); };
  const addBtn = root.querySelector('#cal-add');
  if (addBtn) addBtn.onclick = async () => {
    await loadFormOptions();
    const r = await eventForm({ start_at: cursor + 'T' + '10:00' });
    if (r) render(root, ctx);
  };

  try {
    if (view === 'month') await renderMonth(root, cursor);
    else if (view === 'week') await renderWeek(root, cursor);
    else if (view === 'day') await renderDay(root, cursor);
    else await renderAgenda(root, cursor);
  } catch {
    root.querySelector('#cal-body').innerHTML = emptyState('alert', 'تعذر تحميل التقويم');
  }
}

function rangeItems(r) {
  return {
    events: r.events.map((e) => ({ ...e, kind: 'event' })),
    meetings: r.meetings.map((m) => ({ ...m, kind: 'meeting' })),
    tasks: r.tasks.map((t) => ({ ...t, kind: 'task', start_at: t.due_date, title: t.title })),
    reminders: r.reminders.map((x) => ({ ...x, kind: 'reminder' })),
  };
}
function chipFor(it) {
  if (it.kind === 'meeting') return `<div class="cal-chip cc-meeting" data-id="${it.id}" data-kind="meeting">${fmtTime(it.start_at)} ${esc(it.title.slice(0, 20))}</div>`;
  if (it.kind === 'task') return `<div class="cal-chip cc-task" data-id="${it.id}" data-kind="task">${esc(it.title.slice(0, 24))}</div>`;
  if (it.kind === 'reminder') return `<div class="cal-chip cc-reminder" data-id="${it.id}" data-kind="reminder">${esc(it.title.slice(0, 20))}</div>`;
  return `<div class="cal-chip cc-event" data-id="${it.id}" data-kind="event">${fmtTime(it.start_at)} ${esc(it.title.slice(0, 20))}</div>`;
}

async function renderMonth(root, cursor) {
  const [y, m] = cursor.split('-').map(Number);
  const first = new Date(y, m - 1, 1);
  const startDow = (first.getDay() + 6) % 7;
  const daysIn = new Date(y, m, 0).getDate();
  const from = addDaysStr(cursor.slice(0, 8) + '01', -startDow);
  const to = addDaysStr(cursor.slice(0, 8) + '01', daysIn - 1 + (7 - ((daysIn + startDow - 1) % 7)));
  const r = await api.get(`/api/events/range?from=${from}&to=${to}`);
  const all = [...r.events, ...r.meetings, ...r.tasks.map((t) => ({ ...t, kind: 'task' })), ...r.reminders.map((x) => ({ ...x, kind: 'reminder' }))];
  const byDate = {};
  for (const it of all) {
    const d = String(it.start_at || '').slice(0, 10);
    (byDate[d] ||= []).push(it);
  }
  root.querySelector('#cal-sub').textContent = MONTH_NAMES.format(new Date(y, m - 1, 15));
  const cells = [];
  for (let i = 0; i < startDow; i++) cells.push(null);
  for (let d = 1; d <= daysIn; d++) cells.push(d);
  while (cells.length % 7) cells.push(null);
  const body = root.querySelector('#cal-body');
  body.innerHTML = `
    <div class="card card-pad">
      <div class="cal-head">${DAYS.map((d) => `<div>${d}</div>`).join('')}</div>
      <div class="cal-grid">${cells.map((d) => {
        if (!d) return '<div class="cal-cell other"></div>';
        const ds = `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
        const dayItems = (byDate[ds] || []).sort((a, b) => String(a.start_at).localeCompare(String(b.start_at)));
        return `<div class="cal-cell ${ds === todayISO() ? 'today' : ''}" data-date="${ds}">
          <div class="cal-day">${d}</div>
          ${dayItems.slice(0, 3).map(chipFor).join('')}
          ${dayItems.length > 3 ? `<div class="cal-more">+${dayItems.length - 3} أخرى</div>` : ''}
        </div>`;
      }).join('')}</div>
    </div>`;
  body.querySelectorAll('.cal-cell[data-date]').forEach((cell) => {
    cell.onclick = (e) => {
      const chip = e.target.closest('[data-kind]');
      if (chip) { openItem(chip.dataset.kind, chip.dataset.id); return; }
      openDayDrawer(cell.dataset.date, body);
    };
  });
}

async function renderWeek(root, cursor) {
  const d = new Date(cursor + 'T12:00:00');
  const startDow = (d.getDay() + 6) % 7;
  const start = addDaysStr(cursor, -startDow);
  const end = addDaysStr(start, 6);
  const r = await api.get(`/api/events/range?from=${start}&to=${end}`);
  const all = [...r.events, ...r.meetings, ...r.tasks.map((t) => ({ ...t, kind: 'task' })), ...r.reminders.map((x) => ({ ...x, kind: 'reminder' }))];
  root.querySelector('#cal-sub').textContent = `${fmtDate(start)} — ${fmtDate(end)}`;
  const body = root.querySelector('#cal-body');
  body.innerHTML = `<div class="week-grid">${Array.from({ length: 7 }).map((_, i) => {
    const ds = addDaysStr(start, i);
    const dayItems = all.filter((x) => String(x.start_at).slice(0, 10) === ds).sort((a, b) => String(a.start_at).localeCompare(String(b.start_at)));
    const dt = new Date(ds + 'T12:00:00');
    return `<div class="week-col ${ds === todayISO() ? 'today' : ''}">
      <div class="head">${DAYS[(dt.getDay() + 6) % 7]}<span>${dt.getDate()}</span></div>
      <div style="padding:8px;display:flex;flex-direction:column;gap:6px">
        ${dayItems.map((it) => `<div class="cal-chip ${it.kind === 'meeting' ? 'cc-meeting' : it.kind === 'task' ? 'cc-task' : it.kind === 'reminder' ? 'cc-reminder' : 'cc-event'}" data-kind="${it.kind}" data-id="${it.id}" style="padding:6px 9px;cursor:pointer">${fmtTime(it.start_at)} ${esc(it.title)}</div>`).join('') || '<div class="xs faint" style="text-align:center;padding:12px">لا أحداث</div>'}
      </div>
    </div>`;
  }).join('')}</div>`;
  body.querySelectorAll('[data-kind]').forEach((chip) => (chip.onclick = () => openItem(chip.dataset.kind, chip.dataset.id)));
}

async function renderDay(root, cursor) {
  const r = await api.get(`/api/dashboard/today?date=${cursor}`);
  root.querySelector('#cal-sub').textContent = fmtDate(cursor) + ' — ' + DAYS[(new Date(cursor + 'T12:00:00').getDay() + 6) % 7];
  const body = root.querySelector('#cal-body');
  body.innerHTML = r.items.length
    ? `<div class="card card-pad"><div class="timeline">${r.items.map((i) => `
      <div class="tl-item ${i.status === 'completed' || i.status === 'done' ? 'done' : ''}">
        <div class="tl-time">${fmtTime(i.time) || '—'}</div>
        <div class="tl-dot kind-${i.kind}">${icon({ event: 'calendar', meeting: 'video', task: 'checkSquare', reminder: 'bell', call: 'phone' }[i.kind] || 'calendar')}</div>
        <div class="tl-body"><div class="tl-title">${esc(i.title)}</div>${i.sub ? `<div class="tl-sub">${esc(i.sub)}</div>` : ''}</div>
      </div>`).join('')}</div></div>`
    : emptyState('calendar', 'لا أحداث في هذا اليوم', 'أضف موعدًا جديدًا');
}

async function renderAgenda(root, cursor) {
  const from = cursor;
  const to = addDaysStr(cursor, 13);
  const r = await api.get(`/api/events/range?from=${from}&to=${to}`);
  const all = [...r.events, ...r.meetings, ...r.tasks.map((t) => ({ ...t, kind: 'task' })), ...r.reminders.map((x) => ({ ...x, kind: 'reminder' }))]
    .sort((a, b) => String(a.start_at).localeCompare(String(b.start_at)));
  root.querySelector('#cal-sub').textContent = `أجندة ${fmtDate(from)} — ${fmtDate(to)}`;
  const byDate = {};
  for (const it of all) (byDate[String(it.start_at).slice(0, 10)] ||= []).push(it);
  const body = root.querySelector('#cal-body');
  body.innerHTML = `<div class="card">
    ${Object.keys(byDate).length ? Object.entries(byDate).map(([ds, items]) => `
      <div style="padding:10px 18px;background:var(--surface2);border-bottom:1px solid var(--border);font-weight:800;font-size:.88rem">${fmtDate(ds)} ${ds === todayISO() ? '<span class="badge b-in_progress">اليوم</span>' : ''}</div>
      ${items.map((it) => `<div class="row-card" data-kind="${it.kind}" data-id="${it.id}">
        <div class="tl-dot kind-${it.kind}">${icon({ event: 'calendar', meeting: 'video', task: 'checkSquare', reminder: 'bell' }[it.kind] || 'calendar')}</div>
        <div class="list-main"><div class="list-t">${esc(it.title)}</div>
        <div class="list-s"><span>${fmtTime(it.start_at)}</span>${it.location ? `<span>${esc(it.location)}</span>` : ''}${it.project_name ? `<span>${esc(it.project_name)}</span>` : ''}</div></div>
      </div>`).join('')}`).join('')
    : emptyState('calendar', 'لا مواعيد في هذا النطاق')}`;
  body.querySelectorAll('[data-kind]').forEach((row) => (row.onclick = () => openItem(row.dataset.kind, row.dataset.id)));
}

// درج اليوم
async function openDayDrawer(date, body) {
  const d = await api.get(`/api/dashboard/today?date=${date}`);
  openDrawer({
    title: fmtDate(date),
    body: d.items.length
      ? `<div class="timeline">${d.items.map((i) => `<div class="tl-item"><div class="tl-time">${fmtTime(i.time) || '—'}</div>
          <div class="tl-dot kind-${i.kind}">${icon({ event: 'calendar', meeting: 'video', task: 'checkSquare', reminder: 'bell', call: 'phone' }[i.kind] || 'calendar')}</div>
          <div class="tl-body"><div class="tl-title">${esc(i.title)}</div>${i.sub ? `<div class="tl-sub">${esc(i.sub)}</div>` : ''}</div></div>`).join('')}</div>`
      : emptyState('calendar', 'لا أحداث'),
  });
}

async function openItem(kind, id) {
  try {
    if (kind === 'meeting') { location.hash = '#/meetings'; return; }
    if (kind === 'task') { (await import('./tasks.js')).openTask(id, () => {}); return; }
    if (kind === 'reminder') {
      const { items } = await api.get('/api/reminders?limit=200', { silent: true });
      const r = items.find((x) => x.id === Number(id));
      if (r) (await import('./today.js')) && 0;
      const { reminderForm } = await import('../forms.js');
      await reminderForm(r);
      return;
    }
    const { items } = await api.get('/api/events?limit=300', { silent: true });
    const ev = items.find((x) => x.id === Number(id));
    if (ev) {
      const { openDrawer } = await import('../ui.js');
      await eventForm(ev);
    }
  } catch { /* handled */ }
}

function addDaysStr(dateStr, n) {
  const d = new Date(dateStr + 'T12:00:00Z');
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}
