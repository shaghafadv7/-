// الأشخاص — CRM خفيف + Timeline للشخص
import { api } from '../api.js';
import { state } from '../state.js';
import { icon, esc, fmtDate, fmtDateTime, relTime, fmtMoney, RELATIONS, avatarHtml, KIND_ICONS } from '../core.js';
import { emptyState, confirmDialog, openDrawer, toast } from '../ui.js';
import { contactForm, taskForm, followupForm, noteForm, loadFormOptions } from '../forms.js';

export async function render(root, ctx, sub) {
  if (sub === 'detail') return renderDetail(root, ctx, ctx.segments[1]);
  const q = ctx.query;
  root.innerHTML = `
    <div class="page-head">
      <div><div class="page-title">الأشخاص</div><div class="page-sub" id="ct-sub"></div></div>
      <div class="page-actions">${state.perm('contacts.create') ? `<button class="btn btn-primary" id="ct-add">${icon('plus')} شخص جديد</button>` : ''}</div>
    </div>
    <div class="toolbar">
      <input class="input" id="ct-q" placeholder="بحث بالاسم، الشركة، الجوال…" value="${esc(q.get('q') || '')}"/>
      <select class="select" id="ct-rel"><option value="">كل العلاقات</option>${Object.entries(RELATIONS).map(([k, v]) => `<option value="${k}" ${q.get('relation') === k ? 'selected' : ''}>${v}</option>`).join('')}</select>
    </div>
    <div id="ct-body"><div class="skel" style="height:300px"></div></div>`;
  ['ct-q', 'ct-rel'].forEach((id) => {
    const inp = root.querySelector('#' + id);
    inp.addEventListener(inp.tagName === 'SELECT' ? 'change' : 'input', () => {
      const p = new URLSearchParams(location.hash.split('?')[1] || '');
      const k = id === 'ct-q' ? 'q' : 'relation';
      if (inp.value) p.set(k, inp.value); else p.delete(k);
      location.hash = '#/contacts' + (p.toString() ? '?' + p.toString() : '');
    });
  });
  const addBtn = root.querySelector('#ct-add');
  if (addBtn) addBtn.onclick = async () => { await loadFormOptions(); const r = await contactForm(); if (r && r.id) location.hash = `#/contacts/${r.id}`; };
  await loadMore(root, ctx, 0);
}

async function loadMore(root, ctx, offset) {
  const p = new URLSearchParams(location.hash.split('?')[1] || '');
  p.set('limit', '40'); p.set('offset', String(offset));
  const data = await api.get(`/api/contacts?${p.toString()}`);
  root.querySelector('#ct-sub').textContent = `${data.total} شخص`;
  const box = root.querySelector('#ct-body');
  if (!data.items.length) { box.innerHTML = emptyState('users', 'لا أشخاص', 'أضف أول عميل أو شريك لتبدأ ببناء شبكتك'); return; }
  const isAppend = offset > 0;
  const html = `<div class="grid-3" ${isAppend ? '' : ''}>${data.items.map(contactCard).join('')}</div>
    ${data.offset + data.limit < data.total ? `<button class="load-more" id="ct-more">تحميل المزيد (${data.total - data.offset - data.limit} متبقي)</button>` : ''}`;
  if (isAppend) {
    const grid = box.querySelector('.grid-3');
    if (grid) { grid.insertAdjacentHTML('beforeend', data.items.map(contactCard).join('')); bindCards(grid); }
    const more = box.querySelector('#ct-more');
    if (more) more.remove();
    if (data.offset + data.limit < data.total) {
      box.insertAdjacentHTML('beforeend', `<button class="load-more" id="ct-more">تحميل المزيد</button>`);
      box.querySelector('#ct-more').onclick = () => loadMore(root, ctx, offset + data.limit);
    }
    return;
  }
  box.innerHTML = html;
  bindCards(box);
  const more = box.querySelector('#ct-more');
  if (more) more.onclick = () => loadMore(root, ctx, offset + data.limit);
}

function contactCard(c) {
  return `<div class="card card-pad" data-id="${c.id}" style="cursor:pointer">
    <div class="flex aic gap-10">
      ${avatarHtml(c.first_name + ' ' + (c.last_name || ''))}
      <div style="min-width:0;flex:1">
        <div class="xtr" style="font-size:.98rem">${esc(c.first_name)} ${esc(c.last_name || '')}</div>
        <div class="xs muted">${esc([c.job_title, c.company].filter(Boolean).join(' — ') || '—')}</div>
      </div>
      <span class="badge soft">${RELATIONS[c.relation_type] || c.relation_type}</span>
    </div>
    <div class="flex gap-10 wrap mt-14 small" style="color:var(--muted)">
      ${c.phone ? `<span class="flex aic gap-6">${icon('phone')} ${esc(c.phone)}</span>` : ''}
      ${c.next_follow_up_at ? `<span class="flex aic gap-6" style="color:var(--warn)">${icon('target')} متابعة ${fmtDate(c.next_follow_up_at)}</span>` : ''}
    </div>
  </div>`;
}
function bindCards(box) {
  box.querySelectorAll('.card[data-id]').forEach((card) => {
    card.onclick = () => (location.hash = `#/contacts/${card.dataset.id}`);
  });
}

// ---------- صفحة الشخص + Timeline ----------
async function renderDetail(root, ctx, id) {
  root.innerHTML = `<div class="skel" style="height:400px"></div>`;
  let d;
  try { d = await api.get(`/api/contacts/${id}`); } catch {
    root.innerHTML = emptyState('user', 'الشخص غير موجود', '', '<button class="btn btn-primary" onclick="location.hash=\'#/contacts\'">عودة للأشخاص</button>');
    return;
  }
  const c = d.contact;
  const name = c.first_name + ' ' + (c.last_name || '');
  root.innerHTML = `
    <a href="#/contacts" class="btn btn-ghost btn-sm mb-8">${icon('chevR')} عودة للأشخاص</a>
    <div class="card card-pad mb-14">
      <div class="flex aic gap-14 wrap">
        ${avatarHtml(name, '', 'lg')}
        <div style="flex:1;min-width:200px">
          <div class="flex aic gap-10 wrap"><h2 style="font-size:1.4rem;font-weight:800">${esc(name)}</h2><span class="badge soft">${RELATIONS[c.relation_type] || c.relation_type}</span></div>
          <div class="small muted mt-8">${esc([c.job_title, c.company].filter(Boolean).join(' — ') || '—')}</div>
          <div class="flex gap-14 wrap mt-8 small" style="color:var(--muted)">
            ${c.phone ? `<a class="flex aic gap-6" href="tel:${esc(c.phone)}" style="color:var(--ok);font-weight:700">${icon('phone')} ${esc(c.phone)}</a>` : ''}
            ${c.whatsapp ? `<a class="flex aic gap-6" target="_blank" href="https://wa.me/${esc(c.whatsapp)}" style="color:var(--ok);font-weight:700">${icon('message')} واتساب</a>` : ''}
            ${c.email ? `<a class="flex aic gap-6" href="mailto:${esc(c.email)}" style="color:var(--info);font-weight:700">${icon('mail')} ${esc(c.email)}</a>` : ''}
          </div>
        </div>
        <div class="page-actions">
          ${state.perm('contacts.edit') ? `<button class="btn" id="cd-edit">${icon('edit')} تعديل</button>` : ''}
          ${state.perm('contacts.delete') ? `<button class="btn btn-danger" id="cd-del">${icon('trash')} حذف</button>` : ''}
        </div>
      </div>
      <div class="stat-grid mt-20" style="grid-template-columns:repeat(4,1fr)">
        ${statBox('checkSquare', d.stats.openTasks, 'مهام مفتوحة', '#/tasks')}
        ${statBox('target', d.stats.followups, 'متابعات مستحقة', '#/followups')}
        ${statBox('phone', d.stats.calls, 'اتصالات مسجلة', '#/calls')}
        ${statBox('dollar', fmtMoney(d.stats.expenses), 'مصروفات مرتبطة', '#/expenses')}
      </div>
    </div>
    <div class="flex gap-8 wrap no-print mb-14">
      ${state.perm('tasks.create') ? `<button class="btn btn-soft" id="cd-task">${icon('plus')} مهمة</button>` : ''}
      ${state.perm('followups.create') ? `<button class="btn btn-soft" id="cd-fu">${icon('target')} متابعة</button>` : ''}
      ${state.perm('notes.create') ? `<button class="btn btn-soft" id="cd-note">${icon('edit')} ملاحظة</button>` : ''}
      ${state.perm('calls.create') ? `<button class="btn btn-soft" id="cd-call">${icon('phone')} اتصال</button>` : ''}
    </div>
    <div class="card"><div class="card-head"><h3>${icon('activity')} خط الزمن الكامل</h3></div>
      <div class="card-pad">${d.timeline.length ? `<div class="timeline">${d.timeline.map((i) => `
        <div class="tl-item" data-route="${i.route}">
          <div class="tl-dot kind-${i.kind}">${icon(KIND_ICONS[i.kind] || 'circle')}</div>
          <div class="tl-body"><div class="tl-title">${esc(i.title)}</div>
          <div class="tl-sub"><span>${esc(i.sub || '')}</span><span class="faint">${relTime(i.date)}</span></div></div>
        </div>`).join('')}</div>` : emptyState('activity', 'لا سجل بعد')}</div>
    </div>`;

  root.querySelectorAll('.tl-item[data-route]').forEach((i) => (i.onclick = () => (location.hash = i.dataset.route)));
  const quick = {
    'cd-task': () => taskForm({ contact_id: c.id }),
    'cd-fu': () => followupForm({ contact_id: c.id }),
    'cd-note': () => noteForm({ contact_id: c.id, type: 'contact' }),
    'cd-call': () => import('../forms.js').then((m) => m.callForm({ contact_id: c.id })),
  };
  for (const [btnId, fn] of Object.entries(quick)) {
    const b = root.querySelector('#' + btnId);
    if (b) b.onclick = async () => { await loadFormOptions(); const r = await fn(); if (r) renderDetail(root, ctx, id); };
  }
  const edit = root.querySelector('#cd-edit');
  if (edit) edit.onclick = async () => { const r = await contactForm(c); if (r) renderDetail(root, ctx, id); };
  const del = root.querySelector('#cd-del');
  if (del) del.onclick = async () => {
    if (await confirmDialog(`حذف «${name}»؟ سيتم تفكيك ارتباطاته من المهام والمتابعات وستبقى سجلاتها.`)) {
      await api.del('/api/contacts/' + id);
      location.hash = '#/contacts';
    }
  };
}
function statBox(ic, val, label, route) {
  return `<div class="stat-card" data-route="${route}" style="flex-direction:column;align-items:flex-start;gap:8px">
    <div class="stat-icon si-primary" style="width:40px;height:40px">${icon(ic)}</div>
    <div><div class="stat-value" style="font-size:1.3rem">${val}</div><div class="stat-label">${label}</div></div></div>`;
}
