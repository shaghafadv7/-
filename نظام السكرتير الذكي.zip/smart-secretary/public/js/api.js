// عميل API — JWT + معالجة موحدة للأخطاء
import { toast } from './ui.js';

let TOKEN = localStorage.getItem('ss_token') || null;

export function setToken(t) {
  TOKEN = t;
  if (t) localStorage.setItem('ss_token', t);
  else localStorage.removeItem('ss_token');
}
export function getToken() { return TOKEN; }

export class ApiError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

async function request(path, { method = 'GET', body, headers = {}, raw = false, silent = false } = {}) {
  const opts = { method, headers: { ...headers } };
  if (TOKEN) opts.headers.Authorization = 'Bearer ' + TOKEN;
  if (body !== undefined) {
    if (body instanceof FormData) { opts.body = body; }
    else { opts.body = JSON.stringify(body); opts.headers['Content-Type'] = 'application/json'; }
  }
  let res;
  try {
    res = await fetch(path, opts);
  } catch {
    if (!silent) toast('تعذر الاتصال بالخادم — تحقق من الشبكة', 'err');
    throw new ApiError(0, 'network');
  }
  if (res.status === 401 && !path.startsWith('/api/auth/login')) {
    setToken(null);
    if (location.hash !== '#/login') location.hash = '#/login';
    throw new ApiError(401, 'انتهت الجلسة');
  }
  let data = null;
  if (!raw) {
    try { data = await res.json(); } catch { data = null; }
  } else {
    data = await res.arrayBuffer();
  }
  if (!res.ok) {
    const msg = (data && data.error) || 'حدث خطأ غير متوقع';
    if (!silent) toast(msg, 'err');
    throw new ApiError(res.status, msg);
  }
  return data;
}

export const api = {
  get: (p, opts) => request(p, { ...opts, method: 'GET' }),
  post: (p, body, opts) => request(p, { ...opts, method: 'POST', body }),
  put: (p, body, opts) => request(p, { ...opts, method: 'PUT', body }),
  patch: (p, body, opts) => request(p, { ...opts, method: 'PATCH', body }),
  del: (p, opts) => request(p, { ...opts, method: 'DELETE' }),
  download: (p, filename) => request(p, { raw: true }).then(async (buf) => {
    const url = URL.createObjectURL(new Blob([buf]));
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }),
};
