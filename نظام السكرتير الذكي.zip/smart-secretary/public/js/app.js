// نقطة البداية: المصادقة → الهيكل → الراوتر
import { state, bootstrap, onHashChange, startNotificationsPoll } from './state.js';
import { renderShell, refreshBadges, openPalette, closePalette } from './shell.js';
import { skeleton, emptyState } from './ui.js';
import { icon, esc } from './core.js';
import { renderLogin } from './views/login.js';

const VIEWS = {
  '': { load: () => import('./views/dashboard.js'), perm: 'dashboard.view' },
  'today': { load: () => import('./views/today.js'), perm: 'calendar.view' },
  'tasks': { load: () => import('./views/tasks.js'), perm: 'tasks.view' },
  'calendar': { load: () => import('./views/calendar.js'), perm: 'calendar.view' },
  'workcenter': { load: () => import('./views/workcenter.js'), perm: 'workcenter.view' },
  'followups': { load: () => import('./views/followups.js'), perm: 'followups.view' },
  'contacts': { load: () => import('./views/contacts.js'), perm: 'contacts.view' },
  'contacts/:id': { load: () => import('./views/contacts.js'), perm: 'contacts.view', sub: 'detail' },
  'calls': { load: () => import('./views/calls.js'), perm: 'calls.view' },
  'meetings': { load: () => import('./views/meetings.js'), perm: 'meetings.view' },
  'notes': { load: () => import('./views/notes.js'), perm: 'notes.view' },
  'projects': { load: () => import('./views/projects.js'), perm: 'projects.view' },
  'projects/:id': { load: () => import('./views/projects.js'), perm: 'projects.view', sub: 'detail' },
  'files': { load: () => import('./views/files.js'), perm: 'files.view' },
  'expenses': { load: () => import('./views/expenses.js'), perm: 'expenses.view' },
  'reports': { load: () => import('./views/reports.js'), perm: 'reports.view' },
  'notifications': { load: () => import('./views/notifications.js'), perm: 'dashboard.view' },
  'settings': { load: () => import('./views/settings.js'), perm: 'settings.view' },
  'users': { load: () => import('./views/users.js'), perm: 'users.view' },
  'audit': { load: () => import('./views/audit.js'), perm: 'audit.view' },
  'ai': { load: () => import('./views/ai.js'), perm: 'ai.use' },
};

let currentViewEl = null;

export async function renderRoute() {
  const raw = (location.hash || '#/').replace(/^#\/?/, '');
  const [pathPart, queryPart] = raw.split('?');
  const segments = pathPart.split('/').filter(Boolean);
  const viewEl = document.getElementById('view');
  if (!viewEl) return;

  if (!state.user) {
    if (pathPart === 'login' || !pathPart) renderLogin();
    else location.hash = '#/login';
    return;
  }
  if (pathPart === 'login') { location.hash = '#/'; return; }

  // مطابقة المسار (يدعم /contacts/5)
  const exact = VIEWS[segments.join('/')];
  const pattern = VIEWS[segments[0] + '/:id'];
  const view = exact || (segments.length === 2 ? pattern : null);
  if (!view) {
    viewEl.innerHTML = emptyState('search', 'الصفحة غير موجودة', 'ربما تم نقلها أو أنك لا تملك صلاحية الوصول إليها',
      `<button class="btn btn-primary" onclick="location.hash='#/'">${icon('home')} العودة للرئيسية</button>`);
    return;
  }
  if (view.perm && !state.perm(view.perm)) {
    viewEl.innerHTML = emptyState('shield', 'صلاحيات غير كافية', 'لا تملك صلاحية للوصول إلى هذا القسم. تواصل مع مدير النظام.',
      `<button class="btn btn-primary" onclick="location.hash='#/'">العودة للرئيسية</button>`);
    return;
  }

  // تحديث عناصر التنقل النشطة
  document.querySelectorAll('.nav-item, .bn-item').forEach((a) => {
    const r = a.dataset.route;
    const base = r.split('/')[0] || '';
    const seg0 = segments[0] || '';
    a.classList.toggle('active', r === '#/' ? seg0 === '' : seg0 === base);
  });

  currentViewEl = viewEl;
  viewEl.innerHTML = `<div style="padding:8px 0">${skeleton(5, 90)}</div>`;
  try {
    const mod = await view.load();
    if (currentViewEl !== viewEl) return; // تم تنقّل المستخدم أثناء التحميل
    viewEl.innerHTML = '';
    await mod.render(viewEl, { segments, query: new URLSearchParams(queryPart || ''), sub: view.sub || null });
  } catch (e) {
    console.error(e);
    viewEl.innerHTML = emptyState('alert', 'تعذر تحميل الصفحة', 'حدث خطأ غير متوقع — أعد المحاولة',
      `<button class="btn btn-primary" onclick="location.reload()">إعادة التحميل</button>`);
  }
  refreshBadges();
}

// ---------- اختصارات لوحة المفاتيح ----------
document.addEventListener('keydown', (e) => {
  const tag = (e.target.tagName || '').toLowerCase();
  const typing = tag === 'input' || tag === 'textarea' || tag === 'select' || e.target.isContentEditable;
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
    e.preventDefault();
    if (state.user) (document.getElementById('palette').classList.contains('hidden') ? openPalette : closePalette)();
  }
  if (e.key === 'Escape') closePalette();
  if (!typing && state.user && e.key === '/') { e.preventDefault(); openPalette(); }
});

// ---------- بدء التشغيل ----------
(async function main() {
  const authed = await bootstrap();
  if (authed) {
    renderShell();
    onHashChange(renderRoute);
    startNotificationsPoll();
    await renderRoute();
    window.addEventListener('ss:refresh', async () => { await renderRoute(); });
  } else {
    if (location.hash !== '#/login') location.hash = '#/login';
    renderLogin();
  }
})();

export { VIEWS, currentViewEl };
