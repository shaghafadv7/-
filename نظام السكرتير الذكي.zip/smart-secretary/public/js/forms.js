// منشئ النماذج + نماذج الكيانات (سريعة عبر Modals)
import { openModal, toast } from './ui.js';
import { api } from './api.js';
import { esc, PRIORITIES, TASK_STATUS, FOLLOWUP_STATUS, RELATIONS, FILE_CATS, EXPENSE_CATS, PAY_METHODS, PROJECT_STATUS, EVENT_TYPES, NOTE_TYPES, todayISO, nowLocal, icon } from './core.js';

// ---------- حقول ----------
export const F = {
  text: (name, label, { value = '', req = false, ph = '' } = {}) =>
    `<div class="field" data-f="${name}"><label>${label} ${req ? '<span style="color:var(--danger)">*</span>' : ''}</label>
     <input class="input" name="${name}" value="${esc(value)}" placeholder="${esc(ph)}" ${req ? 'data-req' : ''}/></div>`,
  textarea: (name, label, { value = '', rows = 4, ph = '' } = {}) =>
    `<div class="field" data-f="${name}"><label>${label}</label>
     <textarea class="textarea" name="${name}" rows="${rows}" placeholder="${esc(ph)}">${esc(value)}</textarea></div>`,
  select: (name, label, opts, { value = '', req = false } = {}) =>
    `<div class="field" data-f="${name}"><label>${label} ${req ? '<span style="color:var(--danger)">*</span>' : ''}</label>
     <select class="select" name="${name}" ${req ? 'data-req' : ''}>
       ${opts.map(([v, l]) => `<option value="${esc(v)}" ${String(v) === String(value) ? 'selected' : ''}>${esc(l)}</option>`).join('')}
     </select></div>`,
  date: (name, label, { value = '', req = false } = {}) =>
    `<div class="field" data-f="${name}"><label>${label} ${req ? '<span style="color:var(--danger)">*</span>' : ''}</label>
     <input type="date" class="input" name="${name}" value="${esc(value)}" ${req ? 'data-req' : ''}/></div>`,
  time: (name, label, { value = '', req = false } = {}) =>
    `<div class="field" data-f="${name}"><label>${label}</label>
     <input type="time" class="input" name="${name}" value="${esc(value)}"/></div>`,
  dt: (name, label, { value = '', req = false } = {}) =>
    `<div class="field" data-f="${name}"><label>${label} ${req ? '<span style="color:var(--danger)">*</span>' : ''}</label>
     <input type="datetime-local" class="input" name="${name}" value="${esc(value)}" ${req ? 'data-req' : ''}/></div>`,
  num: (name, label, { value = '', step = '0.01', req = false, min = '0' } = {}) =>
    `<div class="field" data-f="${name}"><label>${label} ${req ? '<span style="color:var(--danger)">*</span>' : ''}</label>
     <input type="number" class="input" name="${name}" value="${esc(value)}" step="${step}" min="${min}" ${req ? 'data-req' : ''}/></div>`,
  file: (name, label, { accept = '', value = '' } = {}) =>
    `<div class="field" data-f="${name}"><label>${label}</label>
     <input type="file" class="input" name="${name}" accept="${accept}" ${value ? `data-file="${esc(value)}"` : ''} style="padding:7px"/></div>`,
  full: (inner) => `<div class="full">${inner}</div>`,
};

// تحميل قوائم الشخص والمشاريع للنماذج (مرة واحدة)
export async function loadFormOptions(force = false) {
  if (window.__formOptsLoaded && !force) return;
  try {
    const [c, p] = await Promise.all([api.get('/api/contacts?limit=200', { silent: true }), api.get('/api/projects', { silent: true })]);
    setContactOpts(c.items || []);
    setProjectOpts(p.items || []);
    window.__formOptsLoaded = true;
  } catch { /* offline */ }
}

// قوائم مشتركة تُبنى من البيانات المحملة
let CONTACT_OPTS = [];
let PROJECT_OPTS = [];
export function setContactOpts(list) {
  CONTACT_OPTS = list.map((c) => [c.id, `${c.first_name}${c.last_name ? ' ' + c.last_name : ''}${c.company ? ' — ' + c.company : ''}`]);
}
export function setProjectOpts(list) {
  PROJECT_OPTS = list.map((p) => [p.id, p.name]);
}
export const contactOpts = (extra = []) => [['', '— بدون —'], ...extra, ...CONTACT_OPTS];
export const projectOpts = (extra = []) => [['', '— بدون —'], ...extra, ...PROJECT_OPTS];

// ---------- محرك المودال النموذجي ----------
export function formModal({ title, fields, submit, wide = false, submitLabel = 'حفظ' }) {
  return new Promise((resolve) => {
    const ov = openModal({
      title,
      wide,
      body: `<form id="fm" class="form-grid" novalidate>${fields}</form>`,
      footer: `<button type="button" class="btn" id="fm-cancel">إلغاء</button><button type="submit" class="btn btn-primary" form="fm">${icon('check')} ${submitLabel}</button>`,
      onClose: () => resolve(null),
    });
    const form = ov.querySelector('#fm');
    ov.querySelector('#fm-cancel').onclick = () => { ov.__close(); resolve(null); };
    form.onsubmit = async (e) => {
      e.preventDefault();
      // تحقق الحقول المطلوبة
      let ok = true;
      form.querySelectorAll('[data-req]').forEach((inp) => {
        const fld = inp.closest('.field');
        if (!inp.value.trim()) { fld.classList.add('invalid'); ok = false; }
        else fld.classList.remove('invalid');
      });
      if (!ok) return;
      const data = Object.fromEntries(new FormData(form).entries());
      const fileInput = form.querySelector('input[type="file"]');
      if (fileInput && fileInput.files.length) data.file = fileInput.files[0];
      const btn = form.querySelector('[type="submit"]');
      btn.disabled = true;
      try {
        const res = await submit(data, form);
        ov.__close();
        resolve(res ?? true);
      } catch (err) {
        if (err && err.status === 0) { /* network: leave open */ }
        btn.disabled = false;
      }
    };
    form.querySelector('input,select,textarea')?.focus();
    onMount && onMount(form);
  });
}

// ---------- نماذج الكيانات ----------
const priOpts = Object.entries(PRIORITIES);
const taskStatusOpts = Object.entries(TASK_STATUS);
const fuStatusOpts = Object.entries(FOLLOWUP_STATUS);
const relOpts = Object.entries(RELATIONS);
const fileCatOpts = Object.entries(FILE_CATS);
const expCatOpts = Object.entries(EXPENSE_CATS);
const payOpts = Object.entries(PAY_METHODS);
const projStatusOpts = Object.entries(PROJECT_STATUS);
const evTypeOpts = Object.entries(EVENT_TYPES);
const noteTypeOpts = Object.entries(NOTE_TYPES);

export async function taskForm(prefill = {}) {
  return formModal({
    title: prefill.id ? 'تعديل المهمة' : 'مهمة جديدة',
    fields:
      F.full(F.text('title', 'عنوان المهمة', { value: prefill.title, req: true, ph: 'ماذا يجب أن يتم؟' })) +
      F.full(F.textarea('description', 'الوصف', { value: prefill.description, rows: 3 })) +
      F.select('priority', 'الأولوية', priOpts, { value: prefill.priority || 'medium' }) +
      F.select('status', 'الحالة', taskStatusOpts, { value: prefill.status || 'new' }) +
      F.date('due_date', 'الموعد النهائي', { value: prefill.due_date, req: false }) +
      F.time('due_time', 'وقت التسليم', { value: prefill.due_time }) +
      F.full(F.dt('reminder_at', 'تذكير قبل الموعد', { value: prefill.reminder_at })) +
      F.select('contact_id', 'الشخص المرتبط', contactOpts(), { value: prefill.contact_id || '' }) +
      F.select('project_id', 'المشروع', projectOpts(), { value: prefill.project_id || '' }) +
      F.full(F.textarea('notes', 'ملاحظات', { value: prefill.notes, rows: 2 })),
    submit: async (d) => {
      if (d.contact_id === '') d.contact_id = null;
      if (d.project_id === '') d.project_id = null;
      if (prefill.id) { await api.patch(`/api/tasks/${prefill.id}`, d); toast('تم تحديث المهمة'); }
      else { await api.post('/api/tasks', d); toast('تم إنشاء المهمة'); }
    },
  });
}

export async function eventForm(prefill = {}) {
  const today = todayISO();
  return formModal({
    title: prefill.id ? 'تعديل الموعد' : 'موعد جديد',
    fields:
      F.full(F.text('title', 'العنوان', { value: prefill.title, req: true })) +
      F.select('type', 'النوع', evTypeOpts, { value: prefill.type || 'appointment' }) +
      F.dt('start_at', 'التاريخ والوقت', { value: prefill.start_at || `${today}T09:00`, req: true }) +
      F.time('end_at', 'نهاية (اختياري)', { value: prefill.end_at ? String(prefill.end_at).slice(11, 16) : '' }) +
      F.text('location', 'المكان', { value: prefill.location }) +
      F.text('link', 'رابط (Zoom / Meet)', { value: prefill.link }) +
      F.full(F.select('contact_id', 'شخص مرتبط', contactOpts(), { value: prefill.contact_id || '' })) +
      F.full(F.select('project_id', 'مشروع مرتبط', projectOpts(), { value: prefill.project_id || '' })) +
      F.full(F.textarea('description', 'التفاصيل', { value: prefill.description, rows: 2 })),
    submit: async (d) => {
      if (d.contact_id === '') d.contact_id = null;
      if (d.project_id === '') d.project_id = null;
      let start = d.start_at;
      if (start && start.includes('T')) start = start.replace('T', ' ') + ':00';
      let end = d.end_at;
      if (end && d.start_at) end = d.start_at.slice(0, 10) + ' ' + end + ':00';
      const payload = { ...d, start_at: start, end_at: end || null };
      if (prefill.id) { await api.patch(`/api/events/${prefill.id}`, payload); toast('تم تحديث الموعد'); }
      else { await api.post('/api/events', payload); toast('تم إضافة الموعد'); }
    },
  });
}

export async function reminderForm(prefill = {}) {
  return formModal({
    title: prefill.id ? 'تعديل التذكير' : 'تذكير جديد',
    fields:
      F.full(F.text('title', 'عنوان التذكير', { value: prefill.title, req: true, ph: 'مثال: الاتصال بأحمد' })) +
      F.dt('remind_at', 'تاريخ ووقت التذكير', { value: prefill.remind_at || nowLocal().slice(0, 16), req: true }) +
      F.full(F.select('contact_id', 'شخص مرتبط', contactOpts(), { value: prefill.contact_id || '' })) +
      F.full(F.textarea('description', 'تفاصيل', { value: prefill.description, rows: 2 })),
    submit: async (d) => {
      if (d.contact_id === '') d.contact_id = null;
      if (d.remind_at && d.remind_at.includes('T')) d.remind_at = d.remind_at.replace('T', ' ') + ':00';
      if (prefill.id) { await api.patch(`/api/reminders/${prefill.id}`, d); toast('تم تحديث التذكير'); }
      else { await api.post('/api/reminders', d); toast('تم إضافة التذكير'); }
    },
  });
}

export async function contactForm(prefill = {}) {
  return formModal({
    title: prefill.id ? 'تعديل الشخص' : 'شخص جديد',
    wide: true,
    fields:
      F.text('first_name', 'الاسم الأول', { value: prefill.first_name, req: true }) +
      F.text('last_name', 'اسم العائلة', { value: prefill.last_name }) +
      F.text('job_title', 'المسمى الوظيفي', { value: prefill.job_title }) +
      F.text('company', 'الشركة', { value: prefill.company }) +
      F.text('phone', 'رقم الجوال', { value: prefill.phone, ph: '05xxxxxxxx' }) +
      F.text('whatsapp', 'واتساب (دولي)', { value: prefill.whatsapp, ph: '9665xxxxxxxx' }) +
      F.full(F.text('email', 'البريد الإلكتروني', { value: prefill.email, ph: 'name@company.com' })) +
      F.select('relation_type', 'نوع العلاقة', relOpts, { value: prefill.relation_type || 'client' }) +
      F.select('project_id', 'مشروع مرتبط', projectOpts(), { value: prefill.project_id || '' }) +
      F.full(F.textarea('notes', 'ملاحظات', { value: prefill.notes, rows: 2 })),
    submit: async (d) => {
      if (d.project_id === '') d.project_id = null;
      if (prefill.id) { await api.patch(`/api/contacts/${prefill.id}`, d); toast('تم تحديث الشخص'); }
      else { const r = await api.post('/api/contacts', d); toast('تمت إضافة الشخص'); return r; }
    },
  });
}

export async function callForm(prefill = {}) {
  return formModal({
    title: prefill.id ? 'تعديل الاتصال' : 'تسجيل اتصال',
    fields:
      F.full(F.select('contact_id', 'الشخص', contactOpts(), { value: prefill.contact_id || '' })) +
      F.text('phone', 'الرقم', { value: prefill.phone }) +
      F.select('direction', 'النوع', [['out', 'صادر'], ['in', 'وارد'], ['missed', 'فائت']], { value: prefill.direction || 'out' }) +
      F.dt('called_at', 'التاريخ والوقت', { value: prefill.called_at ? String(prefill.called_at).slice(0, 16) : nowLocal().slice(0, 16), req: true }) +
      F.num('duration_seconds', 'المدة (بالثواني)', { value: prefill.duration_seconds, step: '1', min: '0' }) +
      F.full(F.text('subject', 'موضوع الاتصال', { value: prefill.subject })) +
      F.full(F.text('outcome', 'النتيجة', { value: prefill.outcome })) +
      F.full(`<div class="field" data-f="needs_follow_up"><label style="display:flex;gap:8px;align-items:center;cursor:pointer">
        <input type="checkbox" name="needs_follow_up" ${prefill.needs_follow_up ? 'checked' : ''} style="width:17px;height:17px;accent-color:var(--primary)"/>
        يحتاج متابعة</label></div>`) +
      F.date('follow_up_date', 'تاريخ المتابعة', { value: prefill.follow_up_date }) +
      F.full(F.text('follow_up_notes', 'ملاحظات المتابعة', { value: prefill.follow_up_notes })),
    submit: async (d) => {
      if (d.contact_id === '') d.contact_id = null;
      if (d.called_at && d.called_at.includes('T')) d.called_at = d.called_at.replace('T', ' ') + ':00';
      d.needs_follow_up = d.needs_follow_up ? 1 : 0;
      d.duration_seconds = Number(d.duration_seconds) || 0;
      if (prefill.id) { await api.patch(`/api/calls/${prefill.id}`, d); toast('تم تحديث الاتصال'); }
      else { await api.post('/api/calls', d); toast('تم تسجيل الاتصال'); }
    },
  });
}

export async function followupForm(prefill = {}) {
  return formModal({
    title: prefill.id ? 'تعديل المتابعة' : 'متابعة جديدة',
    fields:
      F.full(F.text('subject', 'موضوع المتابعة', { value: prefill.subject, req: true, ph: 'مثال: متابعة عرض السعر' })) +
      F.select('contact_id', 'الشخص', contactOpts(), { value: prefill.contact_id || '' }) +
      F.select('project_id', 'المشروع', projectOpts(), { value: prefill.project_id || '' }) +
      F.date('next_date', 'موعد المتابعة القادمة', { value: prefill.next_date || todayISO(), req: true }) +
      F.select('status', 'الحالة', fuStatusOpts, { value: prefill.status || 'waiting' }) +
      F.select('priority', 'الأولوية', priOpts, { value: prefill.priority || 'medium' }) +
      F.full(F.textarea('notes', 'ملاحظات', { value: prefill.notes, rows: 2 })),
    submit: async (d) => {
      if (d.contact_id === '') d.contact_id = null;
      if (d.project_id === '') d.project_id = null;
      if (prefill.id) { await api.patch(`/api/followups/${prefill.id}`, d); toast('تم تحديث المتابعة'); }
      else { await api.post('/api/followups', d); toast('تم إنشاء المتابعة'); }
    },
  });
}

export async function noteForm(prefill = {}) {
  return formModal({
    title: prefill.id ? 'تعديل الملاحظة' : 'ملاحظة جديدة',
    fields:
      F.full(F.text('title', 'العنوان', { value: prefill.title, req: true })) +
      F.full(F.textarea('content', 'المحتوى', { value: prefill.content, rows: 6, ph: 'اكتب ملاحظتك هنا…' })) +
      F.select('type', 'النوع', noteTypeOpts, { value: prefill.type || 'quick' }) +
      F.select('contact_id', 'شخص مرتبط', contactOpts(), { value: prefill.contact_id || '' }) +
      F.select('project_id', 'مشروع مرتبط', projectOpts(), { value: prefill.project_id || '' }) +
      F.full(F.text('tags', 'الوسوم (افصل بفاصلة)', { value: (prefill.tags || []).join('، '), ph: 'مثال: عقود، هام' })),
    submit: async (d) => {
      if (d.contact_id === '') d.contact_id = null;
      if (d.project_id === '') d.project_id = null;
      d.tags = (d.tags || '').split(/[,،]/).map((s) => s.trim()).filter(Boolean);
      if (prefill.id) { await api.patch(`/api/notes/${prefill.id}`, d); toast('تم تحديث الملاحظة'); }
      else { await api.post('/api/notes', d); toast('تمت إضافة الملاحظة'); }
    },
  });
}

export async function projectForm(prefill = {}) {
  return formModal({
    title: prefill.id ? 'تعديل المشروع' : 'مشروع جديد',
    wide: true,
    fields:
      F.text('name', 'اسم المشروع', { value: prefill.name, req: true }) +
      F.text('client_name', 'العميل', { value: prefill.client_name }) +
      F.select('contact_id', 'جهة الاتصال', contactOpts(), { value: prefill.contact_id || '' }) +
      F.select('status', 'الحالة', projStatusOpts, { value: prefill.status || 'active' }) +
      F.date('start_date', 'تاريخ البداية', { value: prefill.start_date }) +
      F.date('due_date', 'الموعد النهائي', { value: prefill.due_date }) +
      F.num('progress', 'نسبة الإنجاز %', { value: prefill.progress ?? 0, step: '5', min: '0' }) +
      F.full(F.textarea('description', 'الوصف', { value: prefill.description, rows: 3 })) +
      F.full(`<div class="field" data-f="color"><label>لون المشروع</label>
        <div style="display:flex;gap:8px">${['#0e8074', '#1e3a5f', '#6d5bd0', '#d97706', '#be185d', '#1f9d61'].map((c) =>
          `<span class="color-dot ${prefill.color === c ? 'active' : ''}" data-color="${c}" style="background:${c}"></span>`).join('')}</div></div>`),
    submit: async (d, form) => {
      const dot = form.querySelector('.color-dot.active');
      if (dot) d.color = dot.dataset.color;
      if (d.contact_id === '') d.contact_id = null;
      d.progress = Number(d.progress) || 0;
      if (prefill.id) { await api.patch(`/api/projects/${prefill.id}`, d); toast('تم تحديث المشروع'); }
      else { await api.post('/api/projects', d); toast('تم إنشاء المشروع'); }
    },
  });
}

export async function expenseForm(prefill = {}) {
  return formModal({
    title: prefill.id ? 'تعديل المصروف' : 'مصروف جديد',
    fields:
      F.num('amount', 'المبلغ (ر.س)', { value: prefill.amount, req: true }) +
      F.select('category', 'التصنيف', expCatOpts, { value: prefill.category || 'other' }) +
      F.date('expense_date', 'التاريخ', { value: prefill.expense_date || todayISO(), req: true }) +
      F.select('payment_method', 'طريقة الدفع', payOpts, { value: prefill.payment_method || 'cash' }) +
      F.full(F.text('description', 'الوصف', { value: prefill.description })) +
      F.select('contact_id', 'شخص مرتبط', contactOpts(), { value: prefill.contact_id || '' }) +
      F.select('project_id', 'مشروع مرتبط', projectOpts(), { value: prefill.project_id || '' }) +
      F.full(F.text('notes', 'ملاحظات', { value: prefill.notes })),
    submit: async (d) => {
      if (d.contact_id === '') d.contact_id = null;
      if (d.project_id === '') d.project_id = null;
      d.amount = Number(d.amount);
      if (prefill.id) { await api.patch(`/api/expenses/${prefill.id}`, d); toast('تم تحديث المصروف'); }
      else { await api.post('/api/expenses', d); toast('تم تسجيل المصروف'); }
    },
  });
}

export async function fileForm(extra = {}) {
  return formModal({
    title: 'رفع ملف',
    fields:
      F.full(F.file('file', 'الملف', { req: true })) +
      F.full(F.select('category', 'التصنيف', fileCatOpts, { value: 'document' })) +
      F.select('contact_id', 'ربط بشخص', contactOpts(), { value: '' }) +
      F.select('project_id', 'ربط بمشروع', projectOpts(), { value: '' }) +
      F.full(F.text('notes', 'ملاحظات', { value: '' })),
    submit: async (d) => {
      const fd = new FormData();
      fd.append('file', d.file);
      for (const k of ['category', 'contact_id', 'project_id', 'task_id', 'meeting_id', 'notes']) {
        if (d[k] !== undefined && d[k] !== '') fd.append(k, d[k]);
      }
      await api.post('/api/files', fd);
      toast('تم رفع الملف');
    },
  });
}

export async function meetingForm(prefill = {}, contactsList = []) {
  const attendeeOpts = [['', '— بدون —'], ...contactsList.map((c) => [c.id, `${c.first_name}${c.last_name ? ' ' + c.last_name : ''}`])];
  return formModal({
    title: prefill.id ? 'تعديل الاجتماع' : 'اجتماع جديد',
    wide: true,
    fields:
      F.full(F.text('title', 'عنوان الاجتماع', { value: prefill.title, req: true })) +
      F.dt('start_at', 'التاريخ والوقت', { value: prefill.start_at ? String(prefill.start_at).slice(0, 16) : `${todayISO()}T10:00`, req: true }) +
      F.time('end_at', 'النهاية', { value: prefill.end_at ? String(prefill.end_at).slice(11, 16) : '' }) +
      F.text('location', 'المكان', { value: prefill.location }) +
      F.text('link', 'رابط الاجتماع', { value: prefill.link }) +
      F.full(F.text('subject', 'الموضوع', { value: prefill.subject })) +
      F.select('project_id', 'المشروع', projectOpts(), { value: prefill.project_id || '' }) +
      F.full(F.textarea('agenda', 'جدول الأعمال', { value: prefill.agenda, rows: 3, ph: 'سطر لكل بند' })),
    submit: async (d, form) => {
      if (d.project_id === '') d.project_id = null;
      if (d.start_at && d.start_at.includes('T')) d.start_at = d.start_at.replace('T', ' ') + ':00';
      let end = d.end_at;
      if (end && d.start_at) end = d.start_at.slice(0, 10) + ' ' + end + ':00';
      const payload = { ...d, end_at: end || null };
      // الحضور
      const sel = form.querySelector('#attendees');
      if (sel) payload.attendees = sel.value === '' ? [] : JSON.parse(sel.value);
      if (prefill.id) { await api.patch(`/api/meetings/${prefill.id}`, payload); toast('تم تحديث الاجتماع'); }
      else { await api.post('/api/meetings', payload); toast('تم إنشاء الاجتماع'); }
    },
    onMount: (form) => {
      // اختيار متعدد للحضور
      const div = document.createElement('div');
      div.className = 'field full';
      div.innerHTML = `<label>الحضور</label>
        <div class="attend-chips" style="display:flex;gap:6px;flex-wrap:wrap;max-height:110px;overflow-y:auto;padding:8px;border:1px solid var(--border);border-radius:9px;background:var(--surface2)"></div>`;
      const box = div.querySelector('.attend-chips');
      contactsList.forEach((c) => {
        const name = `${c.first_name}${c.last_name ? ' ' + c.last_name : ''}`;
        const on = (prefill.attendees || []).some((a) => a.id === c.id);
        const chip = document.createElement('span');
        chip.className = 'chip' + (on ? ' active' : '');
        chip.textContent = name;
        chip.onclick = () => chip.classList.toggle('active');
        box.appendChild(chip);
      });
      const hidden = document.createElement('input');
      hidden.type = 'hidden'; hidden.id = 'attendees';
      hidden.value = JSON.stringify((prefill.attendees || []).map((a) => a.id));
      div.appendChild(hidden);
      form.appendChild(div);
      // تحديث الحقل المخفي عند النقر
      box.onclick = () => {
        hidden.value = JSON.stringify([...box.querySelectorAll('.chip.active')].map((chip) => {
          const idx = [...box.children].indexOf(chip);
          return contactsList[idx]?.id;
        }).filter(Boolean));
      };
    },
  });
}
