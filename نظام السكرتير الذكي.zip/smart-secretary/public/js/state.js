// حالة التطبيق + الراوتر + الثيم + الإشعارات
import { api } from './api.js';
import { toast, openModal } from './ui.js';

export const state = {
  user: null,
  company: null,
  settings: {},      // user settings: theme, primary, language, notify
  lang: 'ar',
  perm: (code) => !!state.user && (state.user.role === 'admin' || (state.user.permissions || []).includes(code)),
  unread: 0,
  route: null,
};

// ---------- i18n (عربي كامل، إنجليزي للواجهات العامة — قابل للتوسع) ----------
const I18N = {
  ar: {
    'nav.main': 'الرئيسية', 'nav.today': 'يومي', 'nav.tasks': 'المهام', 'nav.calendar': 'التقويم',
    'nav.workcenter': 'مركز العمل', 'nav.followups': 'المتابعات', 'nav.contacts': 'الأشخاص',
    'nav.calls': 'الاتصالات', 'nav.meetings': 'الاجتماعات', 'nav.notes': 'الملاحظات',
    'nav.projects': 'المشاريع', 'nav.files': 'الملفات', 'nav.expenses': 'المصروفات',
    'nav.reports': 'التقارير', 'nav.ai': 'المساعد الذكي',
    'nav.work': 'الإدارة', 'nav.settings': 'الإعدادات', 'nav.users': 'المستخدمون', 'nav.audit': 'سجل العمليات',
    'common.add': 'إضافة', 'common.edit': 'تعديل', 'common.delete': 'حذف', 'common.save': 'حفظ',
    'common.cancel': 'إلغاء', 'common.search': 'بحث', 'common.close': 'إغلاق', 'common.confirm': 'تأكيد',
    'common.today': 'اليوم', 'common.tomorrow': 'غدًا', 'common.all': 'الكل', 'common.loading': 'جارٍ التحميل…',
    'common.more': 'المزيد', 'common.none': 'لا يوجد', 'common.actions': 'إجراءات', 'common.view': 'عرض',
    'common.logout': 'تسجيل الخروج', 'common.settings': 'الإعدادات', 'common.profile': 'الملف الشخصي',
    'common.theme': 'الوضع الليلي', 'common.notifications': 'الإشعارات', 'common.markAll': 'تحديد الكل كمقروء',
    'common.empty': 'لا توجد بيانات', 'common.new': 'جديد', 'common.open': 'فتح', 'common.download': 'تنزيل',
  },
  en: {
    'nav.main': 'Dashboard', 'nav.today': 'My Day', 'nav.tasks': 'Tasks', 'nav.calendar': 'Calendar',
    'nav.workcenter': 'Work Center', 'nav.followups': 'Follow-ups', 'nav.contacts': 'Contacts',
    'nav.calls': 'Calls', 'nav.meetings': 'Meetings', 'nav.notes': 'Notes',
    'nav.projects': 'Projects', 'nav.files': 'Files', 'nav.expenses': 'Expenses',
    'nav.reports': 'Reports', 'nav.ai': 'AI Secretary',
    'nav.work': 'Administration', 'nav.settings': 'Settings', 'nav.users': 'Users', 'nav.audit': 'Audit Log',
    'common.add': 'Add', 'common.edit': 'Edit', 'common.delete': 'Delete', 'common.save': 'Save',
    'common.cancel': 'Cancel', 'common.search': 'Search', 'common.close': 'Close', 'common.confirm': 'Confirm',
    'common.today': 'Today', 'common.tomorrow': 'Tomorrow', 'common.all': 'All', 'common.loading': 'Loading…',
    'common.more': 'More', 'common.none': 'None', 'common.actions': 'Actions', 'common.view': 'View',
    'common.logout': 'Log out', 'common.settings': 'Settings', 'common.profile': 'Profile',
    'common.theme': 'Dark mode', 'common.notifications': 'Notifications', 'common.markAll': 'Mark all read',
    'common.empty': 'No data', 'common.new': 'New', 'common.open': 'Open', 'common.download': 'Download',
  },
};
export const t = (key) => (I18N[state.lang] || I18N.ar)[key] || I18N.ar[key] || key;

// ---------- الثيم ----------
export function applyTheme() {
  const s = state.settings || {};
  const theme = s.theme || 'light';
  const primary = s.primary || 'emerald';
  const lang = s.language || 'ar';
  state.lang = lang;
  document.documentElement.setAttribute('data-theme', theme);
  document.documentElement.setAttribute('data-primary', primary);
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  document.title = lang === 'ar' ? 'السكرتير الذكي — مركز التحكم اليومي' : 'Smart Secretary — Daily Control Center';
}

export async function saveUserSettings(patch) {
  const next = { ...state.settings, ...patch };
  state.settings = next;
  applyTheme();
  try { await api.put('/api/settings/user', next); } catch { /* silent */ }
}

// ---------- التنقل ----------
export function navigate(route) {
  if (location.hash === `#${route}`) return;
  location.hash = `#${route}`;
}

export function onHashChange(cb) {
  window.addEventListener('hashchange', cb);
}

// ---------- تحميل الجلسة ----------
export async function bootstrap() {
  const token = localStorage.getItem('ss_token');
  if (!token) return false;
  try {
    const { user, company } = await api.get('/api/auth/me', { silent: true });
    state.user = user;
    state.company = company;
    state.settings = user.settings || {};
    applyTheme();
    return true;
  } catch {
    localStorage.removeItem('ss_token');
    return false;
  }
}

export function logout() {
  api.post('/api/auth/logout', {}, { silent: true }).catch(() => {});
  localStorage.removeItem('ss_token');
  state.user = null;
  location.hash = '#/login';
}

// ---------- إشعارات المتصفح + الاستطلاع الدوري ----------
let pollTimer = null;
export function startNotificationsPoll() {
  stopNotificationsPoll();
  pollTimer = setInterval(async () => {
    try {
      const { count } = await api.get('/api/notifications/unread-count', { silent: true });
      if (count !== state.unread) {
        const grew = count > state.unread;
        state.unread = count;
        renderNotifBadge();
        if (grew && state.settings?.notify?.browser && 'Notification' in window && Notification.permission === 'granted') {
          try {
            const { items } = await api.get('/api/notifications?unreadOnly=1&limit=3', { silent: true });
            const n = items[0];
            if (n) new Notification(n.title, { body: n.body || '' });
          } catch { /* ignore */ }
        }
      }
    } catch { /* offline */ }
  }, 30000);
}
export function stopNotificationsPoll() { pollTimer && clearInterval(pollTimer); pollTimer = null; }

export function renderNotifBadge() {
  const b = document.getElementById('notif-badge');
  if (!b) return;
  b.textContent = state.unread > 0 ? (state.unread > 99 ? '99+' : state.unread) : '';
  b.style.display = state.unread > 0 ? 'flex' : 'none';
}

// مساعدة: فتح روابط #/...
export function goRoute(route) {
  if (route && route.startsWith('#/')) location.hash = route.slice(1);
  else if (route) location.hash = route;
}

export { toast };
export { openModal };
