// هيكل التطبيق: الشريط الجانبي + الشريط العلوي + لوحة الأمر + الإشعارات + الإضافة السريعة
import { state, t, applyTheme, saveUserSettings, logout, renderNotifBadge, goRoute } from './state.js';
import { api, setToken } from './api.js';
import { el, esc, icon, avatarHtml, fmtDateFull, todayISO, KIND_ICONS, relTime } from './core.js';
import { toast, openDrawer } from './ui.js';
import {
  taskForm, eventForm, reminderForm, contactForm, callForm, followupForm, noteForm, projectForm, expenseForm, fileForm,
  setContactOpts, setProjectOpts,
} from './forms.js';

// ---------- عناصر التنقل (وفق الصلاحيات) ----------
const NAV = [
  { group: 'اليوم', items: [
    { route: '#/', perm: 'dashboard.view', icon: 'home', label: 'nav.main' },
    { route: '#/today', perm: 'calendar.view', icon: 'sun', label: 'nav.today' },
    { route: '#/workcenter', perm: 'workcenter.view', icon: 'inbox', label: 'nav.workcenter' },
  ]},
  { group: 'الإدارة', items: [
    { route: '#/tasks', perm: 'tasks.view', icon: 'checkSquare', label: 'nav.tasks' },
    { route: '#/calendar', perm: 'calendar.view', icon: 'calendar', label: 'nav.calendar' },
    { route: '#/followups', perm: 'followups.view', icon: 'target', label: 'nav.followups' },
    { route: '#/meetings', perm: 'meetings.view', icon: 'video', label: 'nav.meetings' },
    { route: '#/contacts', perm: 'contacts.view', icon: 'users', label: 'nav.contacts' },
    { route: '#/calls', perm: 'calls.view', icon: 'phone', label: 'nav.calls' },
    { route: '#/notes', perm: 'notes.view', icon: 'edit', label: 'nav.notes' },
    { route: '#/projects', perm: 'projects.view', icon: 'briefcase', label: 'nav.projects' },
    { route: '#/files', perm: 'files.view', icon: 'folder', label: 'nav.files' },
    { route: '#/expenses', perm: 'expenses.view', icon: 'dollar', label: 'nav.expenses' },
  ]},
  { group: 'التحليل', items: [
    { route: '#/reports', perm: 'reports.view', icon: 'chart', label: 'nav.reports' },
    { route: '#/ai', perm: 'ai.use', icon: 'sparkles', label: 'nav.ai' },
  ]},
  { group: 'النظام', items: [
    { route: '#/users', perm: 'users.view', icon: 'shield', label: 'nav.users' },
    { route: '#/audit', perm: 'audit.view', icon: 'activity', label: 'nav.audit' },
    { route: '#/settings', perm: 'settings.view', icon: 'settings', label: 'nav.settings' },
  ]},
];
const MOBILE_NAV = [
  { route: '#/', icon: 'home', label: 'الرئيسية' },
  { route: '#/today', icon: 'sun', label: 'اليوم' },
  { route: '#/tasks', icon: 'checkSquare', label: 'المهام' },
  { route: '#/calendar', icon: 'calendar', label: 'التقويم' },
  { route: '#/more', icon: 'more', label: 'المزيد' },
];

export function renderShell() {
  const app = document.getElementById('app');
  const u = state.user;
  const groups = NAV
    .map((g) => ({ ...g, items: g.items.filter((i) => state.perm(i.perm)) }))
    .filter((g) => g.items.length);
  const moreItems = NAV.flatMap((g) => g.items).filter((i) => !['#/', '#/today', '#/tasks', '#/calendar'].includes(i.route));

  app.innerHTML = `
  <div class="app">
    <aside class="sidebar">
      <div class="brand">
        <div class="brand-logo">${icon('checkSquare')}</div>
        <div><div class="brand-name">السكرتير الذكي</div><div class="brand-sub">${esc(state.company?.name || 'مركز التحكم اليومي')}</div></div>
      </div>
      <nav class="nav" id="side-nav">
        ${groups.map((g) => `<div class="nav-group">${g.group}</div>${g.items.map((i) =>
          `<a class="nav-item" data-route="${i.route}">${icon(i.icon)}<span>${t(i.label)}</span><span class="pill hidden" data-badge-for="${i.route}"></span></a>`).join('')}`).join('')}
      </nav>
      <div class="side-foot">
        <div class="side-user" id="side-user">
          ${avatarHtml(u.name, u.avatar)}
          <div style="min-width:0"><div style="font-weight:700;font-size:.88rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(u.name)}</div>
          <div style="font-size:.72rem;color:var(--muted)">${u.role === 'admin' ? 'مدير النظام' : u.role === 'secretary' ? 'سكرتير' : 'موظف'}</div></div>
        </div>
      </div>
    </aside>
    <div class="main">
      <header class="topbar">
        <div class="searchbox" id="search-open">
          ${icon('search')}<span class="txt">ابحث في كل شيء…</span><span class="kbd">Ctrl K</span>
        </div>
        <div style="flex:1"></div>
        <button class="icon-btn" id="theme-toggle" title="تبديل الوضع">${icon('moon')}</button>
        <div class="dropdown bell-wrap">
          <button class="icon-btn" id="notif-open" title="الإشعارات">${icon('bell')}<span class="bell-badge" id="notif-badge" style="display:none"></span></button>
        </div>
        <div class="dropdown">
          <button class="avatar" id="user-menu-btn" title="الحساب">${avatarHtml(u.name, u.avatar).replace('class="avatar"', 'style="padding:0"')}</button>
        </div>
      </header>
      <main class="content" id="view"></main>
    </div>
    <nav class="bottomnav" id="bottomnav">
      ${MOBILE_NAV.map((i) => `<div class="bn-item" data-route="${i.route}">${icon(i.icon)}<span>${i.label}</span></div>`).join('')}
    </nav>
    <button class="fab" id="fab" title="إضافة سريعة">${icon('plus')}</button>
  </div>`;

  // ربط التنقل
  const bindNav = (selector) => app.querySelectorAll(selector).forEach((a) => {
    a.onclick = () => {
      if (a.dataset.route === '#/more') openMoreSheet();
      else location.hash = a.dataset.route;
    };
  });
  bindNav('.nav-item'); bindNav('.bn-item');

  document.getElementById('theme-toggle').onclick = () => {
    saveUserSettings({ theme: state.settings.theme === 'dark' ? 'light' : 'dark' });
  };
  document.getElementById('user-menu-btn').onclick = (e) => {
    e.stopPropagation();
    showUserMenu(e.currentTarget);
  };
  document.getElementById('side-user').onclick = () => { location.hash = '#/settings'; };
  document.getElementById('search-open').onclick = () => openPalette();
  document.getElementById('notif-open').onclick = (e) => { e.stopPropagation(); openNotifPanel(); };
  document.getElementById('fab').onclick = () => openQuickAdd();

  renderNotifBadge();
}

function showUserMenu(btn) {
  const u = state.user;
  const old = document.querySelector('.dd-menu');
  old && old.remove();
  const menu = el(`<div class="dd-menu">
    <div style="padding:10px 12px;border-bottom:1px solid var(--border);margin-bottom:5px">
      <div style="font-weight:800">${esc(u.name)}</div>
      <div style="font-size:.78rem;color:var(--muted)">${esc(u.email)}</div>
    </div>
    <button class="dd-item" data-act="profile">${icon('user')} الملف الشخصي</button>
    <button class="dd-item" data-act="theme">${icon('moon')} تبديل الوضع الليلي</button>
    <button class="dd-item danger" data-act="logout">${icon('logout')} تسجيل الخروج</button>
  </div>`);
  btn.parentElement.appendChild(menu);
  menu.addEventListener('click', (e) => {
    const act = e.target.closest('[data-act]')?.dataset.act;
    menu.remove();
    if (act === 'logout') logout();
    if (act === 'theme') saveUserSettings({ theme: state.settings.theme === 'dark' ? 'light' : 'dark' });
    if (act === 'profile') location.hash = '#/settings';
  });
  setTimeout(() => document.addEventListener('click', () => menu.remove(), { once: true }), 0);
}

function openMoreSheet() {
  const moreItems = NAV.flatMap((g) => g.items)
    .filter((i) => !['#/', '#/today', '#/tasks', '#/calendar'].includes(i.route) && state.perm(i.perm));
  openDrawer({
    title: 'المزيد',
    body: moreItems.map((i) =>
      `<div class="list-row" data-route="${i.route}"><div class="tl-dot kind-${i.icon === 'sparkles' ? 'reminder' : 'event'}" style="background:var(--surface2)">${icon(i.icon)}</div>
        <div class="list-main"><div class="list-t">${t(i.label)}</div></div></div>`).join(''),
  });
  document.querySelectorAll('#drawer-root [data-route]').forEach((r) => (r.onclick = () => { location.hash = r.dataset.route; }));
}

// ---------- الإضافة السريعة ----------
export const QUICK_ADD = [
  { icon: 'checkSquare', label: 'مهمة جديدة', color: 'si-primary', fn: () => taskForm() },
  { icon: 'calendar', label: 'موعد جديد', color: 'si-info', fn: () => eventForm() },
  { icon: 'user', label: 'شخص جديد', color: 'si-violet', fn: () => contactForm() },
  { icon: 'target', label: 'متابعة جديدة', color: 'si-danger', fn: () => followupForm() },
  { icon: 'edit', label: 'ملاحظة', color: 'si-warn', fn: () => noteForm() },
  { icon: 'phone', label: 'تسجيل اتصال', color: 'si-ok', fn: () => callForm() },
  { icon: 'video', label: 'اجتماع', color: 'si-info', fn: async () => { const { items } = await api.get('/api/contacts?limit=100', { silent: true }); await import('./views/meetings.js').then(m => m.meetingDialog(items)); } },
  { icon: 'briefcase', label: 'مشروع', color: 'si-gold', fn: () => projectForm() },
  { icon: 'dollar', label: 'مصروف', color: 'si-warn', fn: () => expenseForm() },
  { icon: 'file', label: 'رفع ملف', color: 'si-info', fn: () => fileForm() },
  { icon: 'bell', label: 'تذكير', color: 'si-warn', fn: () => reminderForm() },
];
export function openQuickAdd() {
  const isMobile = window.innerWidth <= 900;
  const itemsHtml = QUICK_ADD.map((q, i) =>
    `<div class="list-row qa-item" data-i="${i}" style="border-radius:10px;margin:2px 0">
      <div class="tl-dot ${q.color}">${icon(q.icon)}</div>
      <div class="list-main"><div class="list-t">${q.label}</div></div>
    </div>`).join('');
  const body = el(`<div style="display:grid;grid-template-columns:1fr 1fr;gap:2px">${itemsHtml}</div>`);
  if (!isMobile) body.style.maxWidth = '420px';
  const ov = openDrawer({ title: 'إضافة سريعة', body });
  body.querySelectorAll('.qa-item').forEach((row) => {
    row.onclick = async () => {
      const item = QUICK_ADD[Number(row.dataset.i)];
      ov.querySelector('.drawer').remove();
      await item.fn();
      onQuickAddDone();
    };
  });
}
let quickAddCb = null;
export function onQuickAddDone() { if (quickAddCb) { quickAddCb(); quickAddCb = null; } window.dispatchEvent(new CustomEvent('ss:refresh')); }
export function setQuickAddCb(fn) { quickAddCb = fn; }

// ---------- لوحة الأمر (Ctrl+K) ----------
let palState = { items: [], sel: 0, open: false };
let palTimer = null;
export function openPalette() {
  const pal = document.getElementById('palette');
  if (pal.classList.contains('hidden')) {
    pal.classList.remove('hidden');
    palState = { items: [], sel: 0, open: true };
    const input = document.getElementById('pal-input');
    input.value = '';
    renderPaletteActions();
    setTimeout(() => input.focus(), 30);
    // البحث مع التأخير (debounce)
    input.oninput = () => {
      const qv = input.value.trim();
      clearTimeout(palTimer);
      if (!qv) { renderPaletteActions(); return; }
      palTimer = setTimeout(() => searchPalette(qv), 160);
    };
    input.onkeydown = (e) => {
      if (e.key === 'ArrowDown') { e.preventDefault(); selectPal(Math.min(palState.sel + 1, palState.items.length - 1)); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); selectPal(Math.max(palState.sel - 1, 0)); }
      else if (e.key === 'Enter') { e.preventDefault(); pickPal(palState.sel); }
    };
  } else {
    document.getElementById('pal-input').focus();
  }
}
export function closePalette() {
  const pal = document.getElementById('palette');
  pal.classList.add('hidden');
  palState.open = false;
}
function renderPaletteActions(q = '') {
  const box = document.getElementById('pal-results');
  const acts = [
    ...QUICK_ADD.map((x) => ({ group: 'إجراءات سريعة', icon: x.icon, title: x.label, fn: () => x.fn() })),
    { group: 'تنقّل', icon: 'home', title: 'العودة للوحة الرئيسية', fn: () => (location.hash = '#/') },
    { group: 'تنقّل', icon: 'chart', title: 'فتح التقارير', fn: () => (location.hash = '#/reports') },
    { group: 'تنقّل', icon: 'sparkles', title: 'سؤال المساعد الذكي', fn: () => (location.hash = '#/ai') },
  ].filter((a) => !q || a.title.includes(q));
  palState.items = acts.map((a) => ({ ...a, type: 'action' }));
  palState.sel = 0;
  box.innerHTML = acts.length
    ? acts.map((a, i) => `<div class="palette-item ${i === 0 ? 'sel' : ''}" data-i="${i}"><div class="ic">${icon(a.icon)}</div><div><div class="t">${esc(a.title)}</div></div></div>`).join('')
    : `<div class="empty" style="padding:24px"><h4>لا نتائج</h4></div>`;
  box.querySelectorAll('.palette-item').forEach((it) => {
    it.onmouseenter = () => selectPal(Number(it.dataset.i));
    it.onclick = () => pickPal(Number(it.dataset.i));
  });
}
async function searchPalette(q) {
  const box = document.getElementById('pal-results');
  const acts = QUICK_ADD.map((x) => ({ group: 'إجراءات سريعة', icon: x.icon, title: x.label, fn: () => x.fn() }))
    .filter((a) => !q || a.title.includes(q));
  let items = acts.map((a) => ({ ...a, type: 'action' }));
  if (q.length >= 1) {
    try {
      const { groups } = await api.get('/api/search?q=' + encodeURIComponent(q), { silent: true });
      const typeIcons = { contacts: 'user', tasks: 'checkSquare', projects: 'briefcase', meetings: 'video', followups: 'target', notes: 'edit', calls: 'phone', files: 'file', expenses: 'dollar', events: 'calendar' };
      for (const g of groups) {
        for (const it of g.items) {
          items.push({ group: g.label, icon: typeIcons[g.type] || 'search', title: it.title, sub: it.sub, route: it.route, type: 'entity' });
        }
      }
    } catch { /* offline */ }
  }
  palState.items = items;
  palState.sel = 0;
  let html = ''; let lastGroup = '';
  items.forEach((a, i) => {
    if (a.group !== lastGroup) { html += `<div class="palette-group">${esc(a.group)}</div>`; lastGroup = a.group; }
    html += `<div class="palette-item ${i === 0 ? 'sel' : ''}" data-i="${i}"><div class="ic">${icon(a.icon)}</div><div style="min-width:0"><div class="t">${esc(a.title)}</div>${a.sub ? `<div class="s">${esc(a.sub)}</div>` : ''}</div></div>`;
  });
  box.innerHTML = html || `<div class="empty" style="padding:24px"><h4>لا نتائج</h4></div>`;
  box.querySelectorAll('.palette-item').forEach((it) => {
    it.onmouseenter = () => selectPal(Number(it.dataset.i));
    it.onclick = () => pickPal(Number(it.dataset.i));
  });
  box.scrollTop = 0;
}
function selectPal(i) {
  palState.sel = i;
  document.querySelectorAll('#pal-results .palette-item').forEach((el2) => el2.classList.toggle('sel', Number(el2.dataset.i) === i));
  document.querySelector(`#pal-results .palette-item[data-i="${i}"]`)?.scrollIntoView({ block: 'nearest' });
}
function pickPal(i) {
  const item = palState.items[i];
  closePalette();
  if (!item) return;
  if (item.type === 'action') item.fn();
  else { goRoute(item.route); }
}

// ---------- لوحة الإشعارات ----------
const NOTIF_ICONS = { task: ['checkSquare', 'si-primary'], reminder: ['bell', 'si-warn'], meeting: ['video', 'si-violet'], followup: ['target', 'si-danger'], file: ['file', 'si-info'], contact: ['user', 'si-violet'], expense: ['dollar', 'si-warn'], system: ['settings', 'si-primary'] };
export async function openNotifPanel() {
  const panel = document.getElementById('notif-panel');
  if (!panel.classList.contains('hidden')) { panel.classList.add('hidden'); return; }
  panel.innerHTML = `<div class="notif-head">الإشعارات <button class="btn btn-sm" id="np-all">${icon('check')} تحديد الكل كمقروء</button></div>
    <div class="notif-list" id="np-list"><div class="skeleton-card" style="height:60px"></div></div>`;
  panel.classList.remove('hidden');
  try {
    const { items } = await api.get('/api/notifications?limit=30');
    const list = panel.querySelector('#np-list');
    list.innerHTML = items.length ? items.map((n) => {
      const [ic, bg] = NOTIF_ICONS[n.type] || ['bell', 'si-primary'];
      return `<div class="notif-item ${n.is_read ? '' : 'unread'}" data-id="${n.id}" data-route="${n.entity ? `#/${n.entity}` : ''}">
        <div class="notif-ic ${bg}">${icon(ic)}</div>
        <div style="flex:1;min-width:0"><div class="notif-t">${esc(n.title)}</div>${n.body ? `<div class="notif-b">${esc(n.body)}</div>` : ''}
        <div class="notif-time">${relTime(n.created_at)}</div></div>
        ${n.is_read ? '' : '<div class="notif-dot"></div>'}
      </div>`;
    }).join('') : `<div class="empty" style="padding:30px"><div class="ic">${icon('bell')}</div><h4>لا إشعارات</h4><p>ستظهر هنا تنبيهات المهام والمواعيد والمتابعات</p></div>`;
    list.querySelectorAll('.notif-item').forEach((it) => {
      it.onclick = async () => {
        await api.post(`/api/notifications/${it.dataset.id}/read`, {}, { silent: true });
        it.classList.remove('unread');
        const dot = it.querySelector('.notif-dot'); dot && dot.remove();
        const { count } = await api.get('/api/notifications/unread-count', { silent: true });
        state.unread = count; renderNotifBadge();
        if (it.dataset.route && it.dataset.route !== '#/') {
          panel.classList.add('hidden');
          goRoute(it.dataset.route);
        }
      };
    });
  } catch { list.innerHTML = '<div class="empty">تعذر التحميل</div>'; }
  panel.querySelector('#np-all').onclick = async () => {
    await api.post('/api/notifications/read-all', {});
    state.unread = 0; renderNotifBadge();
    openNotifPanel(); setTimeout(openNotifPanel, 50);
  };
  setTimeout(() => document.addEventListener('click', (e) => {
    if (!panel.contains(e.target) && !document.getElementById('notif-open').contains(e.target)) panel.classList.add('hidden');
  }, { once: true }), 0);
}

// ---------- تحميل اختياري لبيانات القوائم (للنماذج) ----------
export async function loadFormOptions(force = false) {
  if (window.__formOptsLoaded && !force) return;
  try {
    const [c, p] = await Promise.all([api.get('/api/contacts?limit=200', { silent: true }), api.get('/api/projects', { silent: true })]);
    setContactOpts(c.items || []);
    setProjectOpts(p.items || []);
    window.__formOptsLoaded = true;
  } catch { /* ignore */ }
}

export function refreshBadges() {
  // شارة عدد المتابعات المستحقة في الشريط الجانبي
  api.get('/api/dashboard/summary', { silent: true }).then((d) => {
    const b = document.querySelector('[data-badge-for="#/followups"]');
    if (b) {
      const n = d.stats.dueFollowups;
      b.textContent = n > 0 ? n : '';
      b.classList.toggle('hidden', !n);
    }
  }).catch(() => {});
}

export { el, esc, icon, avatarHtml, fmtDateFull, todayISO, KIND_ICONS };
