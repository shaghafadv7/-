'use strict';
// اختبارات API شاملة — تعمل على قاعدة معزولة منفصلة (DATA_DIR مؤقتة)
// التشغيل: node --test tests/api.test.js
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');

const PORT = 4599;
const BASE = `http://127.0.0.1:${PORT}`;
const DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'ss-test-'));

let proc = null;
const tokens = {};
let admin = null;
let staff = null;

function auth(tok) { return { Authorization: 'Bearer ' + tok }; }
async function j(method, url, body, tok, headers = {}) {
  const res = await fetch(BASE + url, {
    method,
    headers: { ...(body && !(body instanceof FormData) ? { 'Content-Type': 'application/json' } : {}), ...(tok ? auth(tok) : {}), ...headers },
    body: body instanceof FormData ? body : body ? JSON.stringify(body) : undefined,
  });
  let data = null;
  const ct = res.headers.get('content-type') || '';
  if (ct.includes('json')) data = await res.json();
  else data = Buffer.from(await res.arrayBuffer());
  return { status: res.status, data, headers: res.headers };
}
const get = (u, tok) => j('GET', u, undefined, tok);
const post = (u, b, tok) => j('POST', u, b, tok);
const put = (u, b, tok) => j('PUT', u, b, tok);
const patch = (u, b, tok) => j('PATCH', u, b, tok);
const del = (u, tok) => j('DELETE', u, undefined, tok);

before(async () => {
  proc = spawn(process.execPath, ['server/index.js'], {
    cwd: path.join(__dirname, '..'),
    env: { ...process.env, PORT: String(PORT), DATA_DIR, DB_PATH: path.join(DATA_DIR, 'app.db') },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let out = '';
  proc.stdout.on('data', (d) => (out += d));
  proc.stderr.on('data', (d) => (out += d));
  // انتظار الاستماع
  for (let i = 0; i < 60; i++) {
    try {
      const r = await fetch(BASE + '/api/auth/login', { method: 'POST', body: '{}' });
      if (r.status < 500) break;
    } catch { /* not up yet */ }
    await new Promise((r) => setTimeout(r, 500));
  }
  // تسجيل دخول الجميع
  const a = await post('/api/auth/login', { email: 'admin@company.sa', password: 'admin123' });
  assert.equal(a.status, 200, 'admin login');
  tokens.admin = a.data.token; admin = a.data.user;
  const s = await post('/api/auth/login', { email: 'khalid@company.sa', password: 'khalid123' });
  assert.equal(s.status, 200, 'staff login');
  tokens.staff = s.data.token; staff = s.data.user;
}, 30000);

after(() => {
  proc && proc.kill('SIGTERM');
  try { fs.rmSync(DATA_DIR, { recursive: true, force: true }); } catch { /* */ }
});

// ============ المصادقة والصلاحيات ============
test('رفض كلمة مرور خاطئة', async () => {
  const r = await post('/api/auth/login', { email: 'admin@company.sa', password: 'wrong' });
  assert.equal(r.status, 401);
});
test('رفض طلب بدون توكن', async () => {
  const r = await get('/api/tasks');
  assert.equal(r.status, 401);
});
test('/me لا يسرب password_hash', async () => {
  const r = await get('/api/auth/me', tokens.admin);
  assert.equal(r.status, 200);
  assert.equal(r.data.user.password_hash, undefined);
});
test('staff يرفض الوصول إلى /api/users (RBAC)', async () => {
  const r = await get('/api/users', tokens.staff);
  assert.equal(r.status, 403);
});
test('staff يرفض تعديل صلاحيات الأدوار', async () => {
  const r = await put('/api/users/roles/2/permissions', { codes: [] }, tokens.staff);
  assert.equal(r.status, 403);
});

// ============ تحقق المدخلات ============
test('إنشاء مهمة بدون عنوان → 400', async () => {
  const r = await post('/api/tasks', { priority: 'high' }, tokens.admin);
  assert.equal(r.status, 400);
});
test('بريد غير صالح في شخص جديد → 400', async () => {
  const r = await post('/api/contacts', { first_name: 'فحص', email: 'not-an-email' }, tokens.admin);
  assert.equal(r.status, 400);
});

// ============ المهام: CRUD + الحالات ============
test('CRUD كامل للمهام + تغيير الحالة + حذف ناعم', async () => {
  const c = await post('/api/tasks', { title: 'مهمة اختبارية شاملة', priority: 'high', status: 'new', due_date: '2026-10-01', project_id: null }, tokens.admin);
  assert.equal(c.status, 201);
  const id = c.data.id;

  const g = await get(`/api/tasks/${id}`, tokens.admin);
  assert.equal(g.status, 200);
  assert.equal(g.data.row.title, 'مهمة اختبارية شاملة');

  const p = await patch(`/api/tasks/${id}`, { priority: 'urgent', description: 'وصف جديد' }, tokens.admin);
  assert.equal(p.status, 200);
  assert.equal(p.data.task.priority, 'urgent');

  const st = await post(`/api/tasks/${id}/status`, { status: 'completed' }, tokens.admin);
  assert.equal(st.status, 200);

  const d = await del(`/api/tasks/${id}`, tokens.admin);
  assert.equal(d.status, 200);
  // الحذف الناعم: لا تظهر في القائمة
  const list = await get('/api/tasks?q=' + encodeURIComponent('مهمة اختبارية شاملة'), tokens.admin);
  assert.equal(list.data.total, 0);
  // ولا تُفتح من URL
  const gone = await get(`/api/tasks/${id}`, tokens.admin);
  assert.equal(gone.status, 404);
});

// ============ الأشخاص + العلاقات ============
test('CRUD للأشخاص وحذف الشخص يمسح رابط المهام (SET NULL)', async () => {
  const c = await post('/api/contacts', { first_name: 'عميل', last_name: 'الاختبار', relation_type: 'client', phone: '0501234567', email: 'test@x.com' }, tokens.admin);
  assert.equal(c.status, 201);
  const cid = c.data.id;
  const t = await post('/api/tasks', { title: 'مهمة مرتبطة بشخص', contact_id: cid }, tokens.admin);
  assert.equal(t.status, 201);

  const d = await del(`/api/contacts/${cid}`, tokens.admin);
  assert.equal(d.status, 200);
  // المهمة تبقى بلا شخص
  const tg = await get(`/api/tasks/${t.data.id}`, tokens.admin);
  assert.equal(tg.status, 200);
  assert.equal(tg.data.row.contact_id, null);
  await del(`/api/tasks/${t.data.id}`, tokens.admin);
});

// ============ المواعيد والتقويم ============
test('إنشاء موعد + استرجاع النطاق', async () => {
  const today = new Date().toISOString().slice(0, 10);
  const c = await post('/api/events', { title: 'موعد اختبار', type: 'meeting', start_at: today + ' 14:00:00' }, tokens.admin);
  assert.equal(c.status, 201);
  const r = await get(`/api/events/range?from=${today}&to=${today}`, tokens.admin);
  assert.ok(r.data.events.some((e) => e.id === c.data.id), 'الظهور في نطاق اليوم');
  const d = await del(`/api/events/${c.data.id}`, tokens.admin);
  assert.equal(d.status, 200);
});

// ============ التذكيرات ============
test('إنشاء تذكير وتغيير حالته', async () => {
  const c = await post('/api/reminders', { title: 'تذكير اختبار', remind_at: '2026-10-01 09:00:00' }, tokens.admin);
  assert.equal(c.status, 201);
  const s = await post(`/api/reminders/${c.data.id}/status`, { status: 'done' }, tokens.admin);
  assert.equal(s.status, 200);
  await del(`/api/reminders/${c.data.id}`, tokens.admin);
});

// ============ الاجتماعات + محاضر + AI ============
test('اجتماع: إنشاء، محضر، استخراج مهام، إنشاء مهام', async () => {
  const c = await post('/api/meetings', { title: 'اجتماع اختبار', start_at: '2026-09-17 10:00:00', agenda: 'بند 1\nبند 2' }, tokens.admin);
  assert.equal(c.status, 201);
  const mid = c.data.id;
  const m = await patch(`/api/meetings/${mid}`, { minutes: 'قرر خالد إعداد التقرير قبل نهاية الأسبوع. على سارة إرسال العرض غدًا.', status: 'done' }, tokens.admin);
  assert.equal(m.status, 200);

  const ex = await post('/api/ai/extract-tasks', { text: 'على سارة إرسال العرض غدًا، وخالد إعداد التقرير قبل نهاية الأسبوع' }, tokens.admin);
  assert.ok(Array.isArray(ex.data.candidates));

  const mk = await post(`/api/meetings/${mid}/tasks`, { tasks: [{ title: 'إرسال العرض (اختبار)', due_date: '2026-09-18' }] }, tokens.admin);
  assert.equal(mk.status, 201);
  const g = await get(`/api/meetings/${mid}`, tokens.admin);
  assert.ok(g.data.tasks.length >= 1);
  for (const t of g.data.tasks) await del(`/api/tasks/${t.id}`, tokens.admin);
  await del(`/api/meetings/${mid}`, tokens.admin);
});

// ============ المتابعات ============
test('متابعة: إنشاء، إتمام مع جدولة تالية، حذف', async () => {
  const c = await post('/api/followups', { subject: 'متابعة اختبار', next_date: '2026-09-16', status: 'waiting' }, tokens.admin);
  assert.equal(c.status, 201);
  const f = c.data.id;
  const done = await post(`/api/followups/${f}/done`, { next_in_days: 7 }, tokens.admin);
  assert.equal(done.status, 200);
  const g = await get('/api/followups?limit=100', tokens.admin);
  const mine = g.data.items.find((x) => x.id === f);
  assert.ok(mine.next_date > '2026-09-16', 'تجددت المتابعة');
  await del(`/api/followups/${f}`, tokens.admin);
});

// ============ الاتصالات ============
test('اتصال: تسجيل + تحويل إلى مهمة', async () => {
  const c = await post('/api/calls', { direction: 'out', called_at: '2026-09-16 10:00:00', duration_seconds: 300, subject: 'اتصال اختبار', phone: '0559999999' }, tokens.admin);
  assert.equal(c.status, 201);
  const tk = await post(`/api/calls/${c.data.id}/to-task`, { title: 'متابعة اتصال الاختبار' }, tokens.admin);
  assert.equal(tk.status, 201);
  const g = await get(`/api/tasks/${tk.data.task.id}`, tokens.admin);
  assert.equal(g.status, 200);
  await del(`/api/tasks/${tk.data.task.id}`, tokens.admin);
  await del(`/api/calls/${c.data.id}`, tokens.admin);
});

// ============ الملاحظات ============
test('ملاحظات: وسوم، مفضلة، تثبيت', async () => {
  const c = await post('/api/notes', { title: 'ملاحظة اختبار', content: 'محتوى', tags: ['اختبار', 'هام'] }, tokens.admin);
  assert.equal(c.status, 201);
  const nid = c.data.id;
  assert.equal((await patch(`/api/notes/${nid}`, { is_favorite: 1 }, tokens.admin)).status, 200);
  assert.equal((await patch(`/api/notes/${nid}`, { is_pinned: 1 }, tokens.admin)).status, 200);
  const tags = await get('/api/notes/tags', tokens.admin);
  assert.ok(tags.data.items.some((t) => t.name === 'اختبار'));
  await del(`/api/notes/${nid}`, tokens.admin);
});

// ============ المشاريع ============
test('مشروع: إنشاء + عرض dashboard', async () => {
  const c = await post('/api/projects', { name: 'مشروع الاختبار', status: 'active', progress: 40 }, tokens.admin);
  assert.equal(c.status, 201);
  const g = await get(`/api/projects/${c.data.id}`, tokens.admin);
  assert.equal(g.status, 200);
  assert.equal(g.data.project.name, 'مشروع الاختبار');
  await del(`/api/projects/${c.data.id}`, tokens.admin);
});

// ============ الملفات (Multer) ============
test('ملفات: رفع (multer) + تنزيل + إعادة تسمية + حذف', async () => {
  const buf = Buffer.from('اختبار رفع الملف 12345');
  const fd = new FormData();
  fd.append('file', new Blob([buf]), 'test-upload.txt');
  fd.append('category', 'document');
  const res = await fetch(BASE + '/api/files', { method: 'POST', headers: auth(tokens.admin), body: fd });
  assert.equal(res.status, 201);
  const { id } = await res.json();

  const dl = await fetch(BASE + `/api/files/${id}/download`, { headers: auth(tokens.admin) });
  assert.equal(dl.status, 200);
  const text = await dl.text();
  assert.ok(text.includes('اختبار رفع الملف'));

  const rn = await patch(`/api/files/${id}`, { original_name: 'مجدد.txt' }, tokens.admin);
  assert.equal(rn.status, 200);

  // الملف محمي بدون توكن
  const noAuth = await fetch(BASE + `/api/files/${id}/download`);
  assert.equal(noAuth.status, 401);

  const d = await del(`/api/files/${id}`, tokens.admin);
  assert.equal(d.status, 200);
});

// ============ المصروفات ============
test('مصروفات: إنشاء + ملخص + تصفية', async () => {
  const c = await post('/api/expenses', { amount: 123.45, category: 'meals', expense_date: new Date().toISOString().slice(0, 10), description: 'مصروف اختبار' }, tokens.admin);
  assert.equal(c.status, 201);
  const s = await get('/api/expenses/summary', tokens.admin);
  assert.equal(s.status, 200);
  assert.ok(typeof s.data.month.total === 'number');
  const list = await get('/api/expenses?q=' + encodeURIComponent('مصروف اختبار'), tokens.admin);
  assert.ok(list.data.total >= 1);
  await del(`/api/expenses/${c.data.id}`, tokens.admin);
});

// ============ الإشعارات ============
test('إشعارات: قراءة فردية وجماعية + عدّاد غير المقروء', async () => {
  const n = await get('/api/notifications/unread-count', tokens.admin);
  assert.equal(n.status, 200);
  const all = await get('/api/notifications?limit=50', tokens.admin);
  if (all.data.items.length) {
    const first = all.data.items[0];
    const r = await post(`/api/notifications/${first.id}/read`, {}, tokens.admin);
    assert.equal(r.status, 200);
  }
  const ra = await post('/api/notifications/read-all', {}, tokens.admin);
  assert.equal(ra.status, 200);
  const after = await get('/api/notifications/unread-count', tokens.admin);
  assert.equal(after.data.count, 0);
});

// ============ البحث الشامل ============
test('البحث الشامل يعود مجمّعًا عبر الكيانات', async () => {
  const c = await post('/api/contacts', { first_name: 'زكريا', last_name: 'فحص', relation_type: 'client' }, tokens.admin);
  const cid = c.data.id;
  await post('/api/tasks', { title: 'مهمة لزكريا الفحص' }, tokens.admin);
  const r = await get('/api/search?q=' + encodeURIComponent('زكريا'), tokens.admin);
  assert.equal(r.status, 200);
  const types = r.data.groups.map((g) => g.type);
  assert.ok(types.includes('contacts'), 'أشخاص في النتائج');
  assert.ok(types.includes('tasks'), 'مهام في النتائج');
  await del(`/api/contacts/${cid}`, tokens.admin);
});

// ============ اللوحة والتقارير ============
test('اللوحة: summary + today + workcenter', async () => {
  const s = await get('/api/dashboard/summary', tokens.admin);
  assert.equal(s.status, 200);
  assert.ok(s.data.stats && typeof s.data.stats.overdueTasks === 'number');
  const t = await get('/api/dashboard/today', tokens.admin);
  assert.ok(Array.isArray(t.data.items));
  const w = await get('/api/dashboard/workcenter', tokens.admin);
  assert.ok(w.data.urgent && w.data.followups && w.data.upcoming);
});

test('التقارير: summary + productivity + expenses + CSV بمقدمة BOM', async () => {
  const s = await get('/api/reports/summary?range=month', tokens.admin);
  assert.equal(s.status, 200);
  const p = await get('/api/reports/productivity?days=30', tokens.admin);
  assert.ok(p.data.rows.length === 30);
  const e = await get('/api/reports/expenses?range=month&group=category', tokens.admin);
  assert.ok(Array.isArray(e.data.rows));
  const csv = await fetch(BASE + '/api/reports/export.csv?type=tasks&range=month', { headers: auth(tokens.admin) });
  assert.equal(csv.status, 200);
  const buf = Buffer.from(await csv.arrayBuffer());
  assert.ok(buf.slice(0, 3).toString('hex') === 'efbbbf', 'BOM موجود');
});

// ============ الإعدادات والنسخ الاحتياطي ============
test('إعدادات: قراءة/كتابة + نسخة احتياطية كاملة', async () => {
  const g = await get('/api/settings', tokens.admin);
  assert.equal(g.status, 200);
  const u = await put('/api/settings/user', { theme: 'dark', primary: 'navy' }, tokens.admin);
  assert.equal(u.status, 200);
  const me = await get('/api/auth/me', tokens.admin);
  assert.equal(me.data.user.settings.theme, 'dark');
  await put('/api/settings/user', { theme: 'light', primary: 'emerald' }, tokens.admin);

  const bk = await fetch(BASE + '/api/settings/backup', { headers: auth(tokens.admin) });
  assert.equal(bk.status, 200);
  const payload = await bk.json();
  assert.ok(payload.data && payload.data.tasks && payload.data.users && payload.data.contacts, 'النسخة تشمل الجداول');
  // الاستعادة بنفس المحتوى
  const rs = await post('/api/settings/restore', payload, tokens.admin);
  assert.equal(rs.status, 200);
});

// ============ المستخدمون (admin) ============
test('المستخدمون: قائمة + إنشاء + صلاحيات الأدوار', async () => {
  const l = await get('/api/users', tokens.admin);
  assert.equal(l.status, 200);
  assert.ok(l.data.roles.length >= 3);
  const u = await post('/api/users', { name: 'مستخدم تجريبي', email: 'tmp-test@x.com', password: '123456', role_id: 3 }, tokens.admin);
  assert.equal(u.status, 201);
  const id = u.data.id;
  const rp = await put('/api/users/roles/3/permissions', { codes: ['tasks.view', 'tasks.create'] }, tokens.admin);
  assert.equal(rp.status, 200);
  const perms = await get('/api/users/permissions', tokens.admin);
  assert.ok(perms.data.items.length >= 20);
  await del(`/api/users/${id}`, tokens.admin);
});

// ============ سجل العمليات ============
test('سجل العمليات: تسجيل العمليات + تصفية', async () => {
  const l = await get('/api/audit?limit=20', tokens.admin);
  assert.equal(l.status, 200);
  assert.ok(l.data.total > 0);
  const t = await get('/api/audit?entity=tasks&limit=10', tokens.admin);
  assert.ok(t.data.items.every((a) => a.entity === 'tasks' || a.entity === null));
});

// ============ التصفح: SPA fallback ============
test('SPA: أي مسار غير API يرجع index.html', async () => {
  const r = await fetch(BASE + '/some/deep/route');
  assert.equal(r.status, 200);
  const html = await r.text();
  assert.ok(html.includes('<!DOCTYPE html>'));
});
test('API غير موجود يرجع 404 JSON', async () => {
  const r = await fetch(BASE + '/api/nope');
  assert.equal(r.status, 404);
});

// ============ الأداء: حجم بيانات كبير ============
test('أداء: إنشاء 120 مهمة ثم استرجاعها مع ترقيم الصفحات في < 2 ثانية', async () => {
  const base = 'مهمة حجم ';
  for (let i = 1; i <= 120; i++) await post('/api/tasks', { title: base + i, priority: 'medium' }, tokens.admin);
  const t0 = Date.now();
  const page1 = await get('/api/tasks?q=' + encodeURIComponent(base) + '&limit=30&offset=0', tokens.admin);
  const page2 = await get('/api/tasks?q=' + encodeURIComponent(base) + '&limit=30&offset=30', tokens.admin);
  const ms = Date.now() - t0;
  assert.ok(ms < 2000, 'أقل من ثانيتين (فعليًا ' + ms + 'ms)');
  assert.equal(page1.data.items.length, 30);
  assert.ok(page1.data.total >= 120);
  // تنظيف
  for (const t of [...page1.data.items, ...page2.data.items]) await del(`/api/tasks/${t.id}`, tokens.admin);
});

test('أداء: استعلام بحث على قاعدة ممتلئة سريع', async () => {
  const t0 = Date.now();
  const r = await get('/api/search?q=' + encodeURIComponent('أحمد'), tokens.admin);
  assert.ok(Date.now() - t0 < 1500);
  assert.equal(r.status, 200);
});
