# السكرتير الذكي — وثيقة المعمارية

> مركز التحكم اليومي في العمل: مهام، مواعيد، أشخاص، متابعة، اتصالات، اجتماعات،
> ملاحظات، مشاريع، ملفات، مصروفات، تقارير، إشعارات، صلاحيات، وسجل عمليات.

## 1) نظرة عامة على المعمارية

```
┌──────────────────────────────  المتصفح (SPA عربية RTL) ──────────────────────────────┐
│  Shell (Sidebar + Topbar + BottomNav للجوال)                                         │
│  Router (hash) → 20+ عرضًا (Dashboard, اليوم, المهام, التقويم, الأشخاص, المتابعات,  │
│  الاتصالات, الاجتماعات, الملاحظات, المشاريع, الملفات, المصروفات, مركز العمل,        │
│  التقارير, الإشعارات, الإعدادات, المستخدمون, سجل العمليات, AI Secretary)             │
│  API Client (fetch + JWT) • Command Palette (Ctrl+K) • Quick Add • Toasts • Charts   │
└───────────────────────────────────────▲───────────────────────────────────────────────┘
                                        │ JSON over HTTP (Bearer JWT)
┌───────────────────────────────────────┴───────────────────────────────────────────────┐
│  Node.js + Express                                                                    │
│  • Middleware: Auth (JWT) → Permissions (RBAC) → RateLimit (login) → Errors           │
│  • Routes:  REST لكل الكيانات + /dashboard + /today + /workcenter + /search          │
│            + /reports (+CSV) + /ai + /settings (+backup/restore) + /users + /audit    │
│  • Services: audit (سجل عمليات) • notify (إشعارات + جدولة) • ai (مساعد محلي)        │
│  • Scheduler: فحص دوري (دقيقة) للتذكيرات/المهام/المتابعات المستحقة                  │
└───────────────────────────────────────▲───────────────────────────────────────────────┘
                                        │
┌───────────────────────────────────────┴───────────────────────────────────────────────┐
│  SQLite (better-sqlite3, WAL) — data/app.db                                           │
│  20 جدولًا، Foreign Keys، Indexes، Soft Delete، Timestamps                             │
│  الملفات المرفوعة: public/uploads (تخزين فقط) — الوصول حصريًا عبر /api/files/:id/download │
│  بـ JWT (يدعم ?tk= للمعاينات المباشرة) — لا خدمة ثابتة عامة                        │
└───────────────────────────────────────────────────────────────────────────────────────┘
```

### قرارات تقنية
| القرار | الخيار | السبب |
|---|---|---|
| الخادم | Node.js + Express | ناضج، خفيف، مألوف، قابل للتوسع عبر Modules |
| قاعدة البيانات | SQLite (WAL) | قاعدة بيانات حقيقية بالعلاقات والفهارس، صفر تشغيل إضافي، قابلة للنقل إلى PostgreSQL لاحقًا (نفس الـ SQL) |
| المصادقة | JWT (Bearer) + bcryptjs | stateless، سهل التوسع، مناسب لإضافة تطبيق جوال لاحقًا |
| الصلاحيات | RBAC: Roles × Permissions على مستوى كل قسم | يُخفي الأقسام الممنوعة من القائمة والواجهة ويحجبها من الـ API |
| الواجهة | SPA بدون Build (ES Modules) | سرعة تحميل، صيانة مباشرة، لا سلسلة اعتمادات ثقيلة |
| الإيميلات/الذكاء | AI محلي Rule-based + واجهة قابلة للتبديل | يعمل دون مفاتيح خارجية؛ يمكن ربط LLM لاحقًا من `services/ai.js` |

## 2) قاعدة البيانات (Schema)

الجداول (PK = INTEGER AUTOINCREMENT، كل الجداول تحمل `created_at / updated_at`):

| الجدول | الحقول الأساسية | ملاحظات |
|---|---|---|
| `users` | name, email UNIQUE, phone, password_hash, role_id→roles, avatar, is_active, last_login_at, deleted_at | Soft delete |
| `roles` | name UNIQUE, description, is_system | admin / secretary / staff |
| `permissions` | code UNIQUE, label | 30+ صلاحية |
| `role_permissions` | role_id, permission_id | PK مركب |
| `projects` | name, description, client_name, contact_id→contacts, owner_user_id→users, start_date, due_date, status, progress, color | |
| `contacts` | first_name, last_name, job_title, company, phone, whatsapp, email, relation_type, project_id, last_contact_at, next_follow_up_at, notes | CRM خفيف |
| `tasks` | title, description, priority(low/medium/high/urgent), status(new/in_progress/waiting/completed/cancelled), start_date, due_date, due_time, reminder_at, contact_id, project_id, meeting_id, notes, sort_order, completed_at, created_by | Kanban + List + Calendar |
| `reminders` | title, description, remind_at, status(pending/done/dismissed), contact_id, task_id | يظهر في Dashboard + Notification Center |
| `events` | title, type(meeting/appointment/call/followup/other), start_at, end_at, location, link, description, status, contact_id, project_id | مواعيد عامة |
| `meetings` | title, start_at, end_at, location, link, subject, agenda, minutes, decisions, status, project_id | + `meeting_attendees`(meeting_id, contact_id) |
| `calls` | contact_id, phone, direction(in/out/missed), called_at, duration_seconds, subject, outcome, needs_follow_up, follow_up_date, follow_up_notes | قابل للتحويل إلى Task/Reminder |
| `follow_ups` | contact_id, project_id, subject, last_contact_at, next_date, status(waiting/needs/done/completed/postponed), priority, notes | محرك المتابعة |
| `notes` | title, content, type, contact_id, project_id, is_pinned, is_favorite | + `tags`, `note_tags` |
| `files` | original_name, stored_name, mime, size, category(contract/quote/invoice/image/document/report/other), contact_id, project_id, task_id, meeting_id, uploaded_by | |
| `expenses` | amount, category, expense_date, payment_method, description, contact_id, project_id, file_id, notes | |
| `notifications` | user_id, type, title, body, entity, entity_id, is_read | مركز الإشعارات |
| `activity_logs` | user_id, action(create/update/delete/login/...), entity, entity_id, details | Audit |
| `settings` | key PK, value(JSON) | الشركة + النظام |
| `user_settings` | user_id PK, value(JSON) | الثيم، اللغة، تفضيلات الإشعارات |
| `notify_flags` | flag_key PK, at | منع تكرار إشعارات الجدولة |

**العلاقات (FK + ON DELETE):**
- كل الأوصاف `contact_id / project_id / task_id / meeting_id` → `SET NULL` (حذف شخص لا يُمحى تاريخه).
- `meeting_attendees` → `CASCADE` (حذف الاجتماع يزيل الحضور).
- فهارس: `tasks(status, due_date)`, `contacts(first_name)`, `follow_ups(status, next_date)`, `notifications(user_id, is_read)`, `activity_logs(entity, created_at)`, `expenses(expense_date)`, `events(start_at)`, `calls(called_at)`, `reminders(remind_at)`.

## 3) هيكلية API

جميع الطلبات: `Authorization: Bearer <jwt>` — والـ API يفحص الصلاحية لكل نقطة.

```
POST   /api/auth/login | /api/auth/logout
GET    /api/auth/me                 → المستخدم + الصلاحيات + الإعدادات
PUT    /api/auth/password

GET    /api/dashboard/summary       → كل بطاقات Dashboard + الأقسام
GET    /api/today?date=YYYY-MM-DD   → Timeline اليوم (مواعيد+اجتماعات+مهام+تذكيرات+اتصالات)
GET    /api/workcenter              → عاجل/اليوم/بانتظار الرد/متابعات/القادم/مؤجل

GET/POST      /api/tasks   (filters: status, priority, project_id, contact_id, q, due, view=kanban)
PATCH/DELETE  /api/tasks/:id
POST          /api/tasks/:id/status            (سحب & إفلات)
...نفس النمط: reminders, events, contacts, calls, meetings, followups, notes, projects, files, expenses

GET    /api/contacts/:id/timeline → سجل الشخص الكامل (اتصال/اجتماع/مهمة/متابعة/ملاحظة/ملف)
POST   /api/calls/:id/to-task | to-reminder
POST   /api/meetings/:id/tasks    → إنشاء مهام من محضر الاجتماع
POST   /api/meetings/:id/attend   → إضافة حضور

GET    /api/search?q=&type=       → بحث عام مجمّع (أشخاص/مهام/مشاريع/اجتماعات/ملاحظات/اتصالات/ملفات/متابعات/مصروفات)
GET    /api/notifications         (GET ?unread=1, POST /:id/read, POST /read-all)

GET    /api/reports/summary?range=week|month|quarter|year
GET    /api/reports/productivity?days=30
GET    /api/reports/expenses?range=&group=category|month
GET    /api/reports/projects
GET    /api/reports/export.csv?type=tasks|calls|expenses|followups|contacts&range=

POST   /api/ai/chat {message}     → مساعد (سؤال طبيعي بالعربية)
POST   /api/ai/extract-tasks {text}
POST   /api/ai/summarize {scope, id?}

GET/PUT /api/settings              (company + system)
GET   /api/settings/backup         (JSON كامل)
POST  /api/settings/restore
GET/PUT /api/settings/user         (ثيم/لغة/إشعارات)

GET/POST /api/users  (users.manage) | PATCH /api/users/:id | POST /api/users/:id/reset-password
GET/PUT  /api/roles  | PUT /api/roles/:id/permissions
GET    /api/audit?entity=&user=&q=&page=  (audit.view)
```

## 4) المصادقة والصلاحيات

- تسجيل دخول → `login` يتحقق (bcrypt) → JWT بصلاحية 7 أيام يحمل `{id, name, role}`.
- `req.user.permissions` تُحسب لكل طلب من `role_permissions`.
- **المدير (admin):** كل الصلاحيات تلقائيًا.
- **السكرتير (secretary):** كل الأقسام عدا إدارة المستخدمين وتعديل الإعدادات النظامية وسجل العمليات.
- **الموظف (staff):** عرض + إنشاء/تعديل على: المهام، التقويم، الملاحظات، المفضلة — بدون حذف، بدون إعدادات/مستخدمين/تقارير متقدمة.
- الواجهة تُخفي أي عنصر (قائمة جانبية، أزرار، صفحات) غير مصرّح به، والـ API يرد `403` عند أي محاولة تجاوز.

## 5) الإشعارات والجدولة

- كل عملية مهمة تولّد إشعارًا مناسبًا (مهمة متأخرة، متابعة مستحقة، اجتماع قادم…).
- Scheduler يعمل كل 60 ثانية:
  - تذكير `pending` أصبح مستحقًا → إشعار + وضع `done_notified`.
  - مهام بها `reminder_at` مستحقة → إشعار (مرة واحدة عبر `notify_flags`).
  - متابعات مستحقة اليوم → إشعار يومي مجمّع.
- المتصفح: Polling كل 30 ثانية + Browser Notifications عند تفعيلها من الإعدادات.

## 6) سجل العمليات (Audit)

`activity_logs` يسجّل: المستخدم، الإجراء، الكيان، المعرّف، التفاصيل (قبل/بعد بالحقل المهم)، الوقت.
مثال: «تم تعديل المهمة "إرسال العرض" من (قيد التنفيذ) إلى (مكتملة) بواسطة أحمد الشمري في 10:32».

## 7) صفحات النظام (Router)

`#/login` · `#/` Dashboard · `#/today` يومي · `#/tasks` (List|Kanban|Calendar) · `#/calendar` (شهر|أسبوع|يوم|Agenda) · `#/contacts` (+ `#/contacts/:id` Timeline) · `#/followups` · `#/calls` · `#/meetings` (+ تفاصيل + محضر + مهام ناتجة) · `#/notes` · `#/projects` (+ `#/projects/:id`) · `#/files` · `#/expenses` · `#/workcenter` · `#/reports` · `#/notifications` · `#/settings` · `#/users` · `#/audit` · `#/ai`

الجوال: Bottom Navigation (الرئيسية / اليوم / المهام / التقويم / المزيد) + FAB للإضافة السريعة.

## 8) مكونات الواجهة (Components)

`Toast` · `Modal/Drawer` · `Confirm` · `CommandPalette (Ctrl+K)` · `QuickAdd` · `StatCard` · `Timeline` · `KanbanBoard (DnD)` · `CalendarGrid` · `DataTable (بحث/فلترة/ترتيب/تحميل المزيد)` · `Charts SVG` (Bar/Donut/Line) · `EmptyState` · `Skeleton` · `FormBuilder` · `Avatar` · `Badge/Chip` · `ProgressBar`.

## 9) مسارات التوسع المستقبلية

- **تطبيق جوال:** الـ API جاهز (REST+JWT) — نضيف Expo/React Native.
- **تكاملات:** WhatsApp/Email/Google Calendar عبر `services/` الجديدة.
- **ذكاء حقيقي:** استبدال/تدعيم `services/ai.js` بـ LLM API (نفس التواقيع).
- **PostgreSQL:** الاستعلامات SQL قياسية؛ تغيير `server/db.js` فقط.

## 10) الأمان

- كلمات مرور bcrypt (cost 10) · JWT موقّع · Rate limit على تسجيل الدخول ·
  فحص صلاحية لكل endpoint · Validations على المدخلات · ملفات الرفع خارج نطاق التنفيذ
  (نسخ مخزنة + serve مع `Content-Type` من DB) · Audit logs · HTTPS عبر.Reverse proxy.
