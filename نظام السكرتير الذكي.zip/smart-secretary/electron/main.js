'use strict';
// السكرتير الذكي — تطبيق سطح المكتب (Electron)
// يفتح نافذة مستقلة وتبدأ الخادم تلقائيًا خلفها.
//  • في وضع التطوير: يشغّل الخادم كعملية node منفصلة (نفس سلوك npm start).
//  • في التطبيق المُجمّع: يشغّل الخادم داخل العملية الرئيسية (بدون الحاجة لـ Node على الجهاز).

const { app, BrowserWindow, Menu, shell, nativeTheme } = require('electron');
const { spawn } = require('child_process');
const path = require('path');
const net = require('net');
const fs = require('fs');

const APP_NAME = 'السكرتير الذكي';
let win = null;
let serverProc = null;
let inProcServer = null;
let chosenPort = null;

// ---------- منع فتح أكثر من نسخة ----------
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (win) { if (win.isMinimized()) win.restore(); win.focus(); }
  });
}

// ---------- اختيار منفذ حر (4000 ← 4010) ----------
function portFree(port) {
  return new Promise((resolve) => {
    const s = net.createServer();
    s.once('error', () => resolve(false));
    s.once('listening', () => { s.close(); resolve(true); });
    s.listen(port, '127.0.0.1');
  });
}
async function pickPort() {
  const base = parseInt(process.env.SS_PORT || '4000', 10);
  for (let p = base; p < base + 11; p++) if (await portFree(p)) return p;
  return null;
}
function waitHttp(url, tries = 60) {
  const started = Date.now();
  return new Promise((resolve) => {
    (function attempt() {
      const req = require('http').get(url, (res) => { res.resume(); resolve(true); });
      req.on('error', () => {
        if (Date.now() - started > 30000) resolve(false);
        else setTimeout(attempt, 500);
      });
    })();
  });
}

// ---------- تشغيل الخادم ----------
async function startServer(port) {
  if (app.isPackaged) {
    // داخل التطبيق المُجمّع: الخادم في نفس العملية (better-sqlite3 مُعاد بناؤه لـ Electron)
    // البيانات خارج asar (قابل للكتابة)
    const userDir = app.getPath('userData');
    process.env.DATA_DIR = path.join(userDir, 'data');
    process.env.UPLOADS_DIR = path.join(userDir, 'uploads');
    fs.mkdirSync(process.env.DATA_DIR, { recursive: true });
    fs.mkdirSync(process.env.UPLOADS_DIR, { recursive: true });
    process.env.HOST = '127.0.0.1';
    process.env.PORT = String(port);
    const server = require(path.join(__dirname, '..', 'server', 'index.js'));
    inProcServer = server;
    console.log('[desktop] الخادم يعمل داخل التطبيق على المنفذ', port);
    return true;
  }
  // وضع التطوير: عملية node منفصلة
  const root = path.join(__dirname, '..');
  const nodeBin = process.platform === 'win32' ? 'node.exe' : 'node';
  const logStream = fs.openSync(path.join(app.getPath('userData'), 'server.log'), 'a');
  serverProc = spawn(nodeBin, [path.join(root, 'server', 'index.js')],
    {
      cwd: root,
      env: { ...process.env, PORT: String(port), DATA_DIR: process.env.SS_DATA_DIR || undefined },
      stdio: ['ignore', logStream, logStream],
    });
  serverProc.on('exit', (code) => {
    console.log('[desktop] الخادم الفرعي خرج بكود', code);
    if (win && !app.isQuitting) win.loadURL(`data:text/html,<h2 style="font-family:Tajawal">الخادم توقف (${code})</h2>`);
  });
  const up = await waitHttp(`http://127.0.0.1:${port}/`);
  console.log('[desktop] الخادم الفرعي', up ? 'جاهز' : 'لم ينجح في البدء (شغّل node أولًا)');
  return up;
}

// ---------- النافذة ----------
function createWindow(port) {
  win = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1024,
    minHeight: 640,
    title: APP_NAME,
    backgroundColor: '#f2f4f7',
    autoHideMenuBar: true,
    show: false,
    icon: path.join(__dirname, 'assets', 'icon.png'),
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      spellcheck: false,
    },
  });
  Menu.setApplicationMenu(null);

  win.once('ready-to-show', () => win.show());

  // الروابط الخارجية (واتساب/بريد/رقم جوال) في متصفح النظام
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e, url) => {
    const base = `http://127.0.0.1:${port}`;
    if (!url.startsWith(base)) {
      e.preventDefault();
      if (/^https?:/.test(url)) shell.openExternal(url);
    }
  });
  win.on('closed', () => (win = null));

  win.loadURL(`http://127.0.0.1:${port}/`);
}

// ---------- دورة الحياة ----------
async function boot() {
  nativeTheme.themeSource = 'light';
  const port = await pickPort();
  if (!port) {
    console.error('[desktop] لا يوجد منفذ حر — أغلق البرامج الأخرى');
    app.quit();
    return;
  }
  chosenPort = port;
  const up = await startServer(port);
  createWindow(port);
  if (!up) {
    setTimeout(() => win && win.loadURL(`data:text/html;charset=utf-8,<div style="font-family:Tajawal;max-width:460px;margin:15vh auto;text-align:center"><h2>تعذر بدء الخادم</h2><p>تأكد من تثبيت Node.js ثم أعد فتح التطبيق.<br>أو شغّل الخادم يدويًا: <code>npm start</code> على المنفذ ${port}</p></div>`), 1500);
  }
}

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) boot();
});
app.on('before-quit', (e) => {
  if (app.isQuitting) return;
  e.preventDefault();
  app.isQuitting = true;
  try { if (serverProc) serverProc.kill(); } catch { /* */ }
  try { if (inProcServer) inProcServer.close(); } catch { /* */ }
  setTimeout(() => app.quit(), 300);
});

app.whenReady().then(boot);
