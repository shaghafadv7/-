'use strict';
// أدوات مساعدة مشتركة للطرق (Validation + Patch عام + Soft Delete)
const { q } = require('./db');
const { nowStr } = require('./time');
const { httpError } = require('./middleware/errors');
const audit = require('./services/audit');

const S = (v) => (v === undefined || v === null ? null : String(v).trim() === '' ? null : String(v).trim());
const N = (v, d = null) => { if (v === undefined || v === null || v === '') return d; const n = Number(v); return Number.isFinite(n) ? n : d; };
const B = (v) => (v === true || v === 'true' || v === 1 || v === '1' ? 1 : 0);
const I = (v) => { if (v === undefined || v === null || v === '') return null; const n = Number(v); return Number.isFinite(n) ? n : null; };

const STATUS_LABELS = {
  task: { new: 'جديدة', in_progress: 'قيد التنفيذ', waiting: 'بانتظار الرد', completed: 'مكتملة', cancelled: 'ملغاة' },
  followup: { waiting: 'بانتظار الرد', needs: 'يحتاج متابعة', done: 'تمت المتابعة', completed: 'مكتمل', postponed: 'مؤجل' },
  priority: { low: 'منخفضة', medium: 'متوسطة', high: 'عالية', urgent: 'عاجلة' },
};

// تحديث عام: fields = قائمة الحقول المسموح تعديلها، labels = أسماء عربية للتفاصيل
function patch(table, id, body, fields, user, entity, labels = {}) {
  const row = q.get(`SELECT * FROM ${table} WHERE id=? AND deleted_at IS NULL`, id);
  if (!row) throw httpError(404, 'العنصر غير موجود');
  const sets = []; const params = []; const changed = [];
  for (const f of fields) {
    if (body[f] !== undefined) {
      const v = body[f] === '' ? null : body[f];
      sets.push(`${f}=?`); params.push(v);
      if (String(row[f] ?? '') !== String(v ?? '')) changed.push(labels[f] || f);
    }
  }
  if (!sets.length) throw httpError(400, 'لا توجد بيانات للتحديث');
  sets.push('updated_at=?'); params.push(nowStr(), id);
  q.run(`UPDATE ${table} SET ${sets.join(', ')} WHERE id=?`, ...params);
  audit.log(user, 'update', entity, id, changed.length ? `تم تعديل: ${changed.join('، ')}` : null);
  return q.get(`SELECT * FROM ${table} WHERE id=?`, id);
}

function softDelete(table, id, user, entity, res, title) {
  const row = q.get(`SELECT * FROM ${table} WHERE id=? AND deleted_at IS NULL`, id);
  if (!row) throw httpError(404, 'العنصر غير موجود');
  q.run(`UPDATE ${table} SET deleted_at=?, updated_at=? WHERE id=?`, nowStr(), nowStr(), id);
  audit.log(user, 'delete', entity, id, title ? `تم حذف «${title}»` : null);
  res.json({ ok: true });
}

function mustRow(table, id) {
  const row = q.get(`SELECT * FROM ${table} WHERE id=? AND deleted_at IS NULL`, id);
  if (!row) throw httpError(404, 'العنصر غير موجود');
  return row;
}

module.exports = { S, N, B, I, patch, softDelete, mustRow, STATUS_LABELS, audit, nowStr };
