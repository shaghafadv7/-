'use strict';
// بيانات تجريبية غنية تُزرع عند أول تشغيل فقط — كل التواريخ نسبية لليوم الحالي
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const { q, db, DATA_DIR } = require('./db');
const { todayStr, addDays } = require('./time');

const UPLOADS = process.env.UPLOADS_DIR || path.join(__dirname, '..', 'public', 'uploads');
fs.mkdirSync(UPLOADS, { recursive: true });

function seed() {
  const today = todayStr();
  const d = (n) => addDays(today, n);
  const dt = (dayOffset, time) => `${d(dayOffset)} ${time}:00`;
  const now = dt(0, '09:00');
  const hash = (p) => bcrypt.hashSync(p, 10);

  const tx = db.transaction(() => {
    // ===== المستخدمون =====
    const insUser = db.prepare('INSERT INTO users (name, email, phone, password_hash, role_id, is_active, created_at, updated_at) VALUES (?,?,?,?,?,1,?,?)');
    const adminId = insUser.run('أحمد الشمري', 'admin@company.sa', '0550000001', hash('admin123'), 1, now, now).lastInsertRowid;
    insUser.run('سارة العتيبي', 'sara@company.sa', '0550000002', hash('sara123'), 2, now, now);
    insUser.run('خالد الدوسري', 'khalid@company.sa', '0550000003', hash('khalid123'), 3, now, now);

    // ===== الإعدادات =====
    const setSetting = (k, v) => q.run('INSERT INTO settings (key, value) VALUES (?,?)', k, JSON.stringify(v));
    setSetting('company', { name: 'شركة الأفق للتقنية', phone: '0126543210', email: 'info@ufq-tech.sa', address: 'الرياض — حي العليا', logo: null });
    setSetting('system', { currency: 'SAR', timezone: 'Asia/Riyadh', language: 'ar' });
    q.run('INSERT INTO user_settings (user_id, value) VALUES (?,?)', adminId, JSON.stringify({ theme: 'light', primary: 'emerald', language: 'ar', notify: { tasks: true, events: true, followups: true, browser: false } }));

    // ===== المشاريع =====
    const insP = db.prepare('INSERT INTO projects (name, description, client_name, contact_id, owner_user_id, start_date, due_date, status, progress, color, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)');
    const p1 = insP.run('إطلاق موقع الشركة الجديد', 'تطوير وإطلاق الموقع الإلكتروني الجديد مع التدريب على لوحة التحكم', 'الأفق لتجارة التقنية', null, adminId, d(-20), d(10), 'active', 60, '#0f9d8f', now, now).lastInsertRowid;
    const p2 = insP.run('نظام إدارة العملاء CRM', 'تخصيص نظام CRM وفريق العملاء مع التدريب', 'شركة النخبة', null, adminId, d(-15), d(25), 'active', 35, '#6d5bd0', now, now).lastInsertRowid;
    const p3 = insP.run('حملة التسويق الرقمي', 'إدارة الحملة الإعلانية على منصات التواصل', 'ليلى السديري للتسويق', null, adminId, d(-10), d(5), 'active', 80, '#d97706', now, now).lastInsertRowid;
    const p4 = insP.run('تجديد العقد مع البنك', 'تجديد عقد الخدمة السنوي مع بنك التنمية', 'بنك التنمية', null, adminId, d(-5), d(30), 'on_hold', 20, '#1e3a5f', now, now).lastInsertRowid;

    // ===== الأشخاص =====
    const insC = db.prepare('INSERT INTO contacts (first_name, last_name, job_title, company, phone, whatsapp, email, relation_type, project_id, last_contact_at, next_follow_up_at, notes, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
    const c = (a) => insC.run(...a, now, now).lastInsertRowid;
    const c1 = c(['أحمد', 'الغامدي', 'مدير المشتريات', 'الأفق لتجارة التقنية', '0551112233', '966551112233', 'a.ghamdi@ufq.sa', 'client', p1, dt(-3, '14:20'), d(1), 'يفضل التواصل صباحًا. حساس من التأخير في التسليم.']);
    const c2 = c(['نورة', 'القحطاني', 'مديرة التسويق', 'الأفق لتجارة التقنية', '0552223344', '966552223344', 'n.qahtani@ufq.sa', 'client', p1, dt(-1, '10:05'), d(2), null]);
    const c3 = c(['محمد', 'العتيبي', 'شريك تجاري', 'شركة النخبة', '0553334455', '966553334455', 'm.otaibi@nukhba.sa', 'partner', p2, dt(-4, '16:40'), d(4), 'يراهن على نتائج الربع الثالث.']);
    const c4 = c(['فهد', 'السالم', 'مستشار قانوني', 'مكتب السالم للمحاماة', '0554445566', '966554445566', 'dr.fahad@salem-legal.sa', 'consultant', p4, dt(-2, '12:00'), d(3), 'يراجع العقود — يطلب تعديلات بنود الحماية.']);
    const c5 = c(['ريم', 'الزهراني', 'مديرة المشاريع', 'شركة النخبة', '0555556677', '966555556677', 'r.zahrani@nukhba.sa', 'client', p2, dt(-5, '09:30'), d(1), null]);
    const c6 = c(['سلطان', 'الحربي', 'مورد رئيسي', 'التوريدات الحديثة', '0556667788', '966556667788', null, 'vendor', null, dt(-2, '13:15'), d(2), null]);
    const c7 = c(['هند', 'العنزي', 'محاسبة', 'شركة الأفق للتقنية', '0557778899', '966557778899', 'hind@ufq-tech.sa', 'employee', null, dt(-1, '11:00'), d(5), null]);
    const c8 = c(['ماجد', 'المطيري', 'مدير حسابات', 'بنك التنمية', '0558889900', '966558889900', 'majed@tdbank.sa', 'client', p4, dt(-4, '15:20'), d(3), 'قرار التجديد مرهون بمراجعة الإدارة المالية.']);
    const c9 = c(['ليلى', 'السديري', 'مديرة التسويق', 'ليلى سديري للتسويق', '0559990011', '966559990011', 'layla@sudairy-marketing.sa', 'client', p3, dt(-3, '17:10'), d(1), null]);
    const c10 = c(['عمر', 'باوزير', 'صاحب المطبعة', 'مطبعة النجاح', '0550001122', '966550001122', null, 'vendor', null, dt(-2, '10:45'), d(2), null]);

    // ربط المشاريع بالأشخاص
    q.run('UPDATE projects SET contact_id=? WHERE id=?', c1, p1);
    q.run('UPDATE projects SET contact_id=? WHERE id=?', c5, p2);
    q.run('UPDATE projects SET contact_id=? WHERE id=?', c9, p3);
    q.run('UPDATE projects SET contact_id=? WHERE id=?', c8, p4);

    // ===== المهام =====
    const insT = db.prepare(`INSERT INTO tasks (title, description, priority, status, start_date, due_date, due_time, reminder_at, contact_id, project_id, meeting_id, notes, sort_order, completed_at, created_by, created_at, updated_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
    const t = (a, completedAt = null) => insT.run(...a, 0, completedAt, adminId, dt(-1, '09:00'), now).lastInsertRowid;
    const t1 = t(['إرسال العرض المعدل لأحمد الغامدي', 'إرسال النسخة النهائية من العرض مع جدول التسليم', 'urgent', 'in_progress', today, today, '12:00', dt(0, '09:00'), c1, p1, null, 'انتظر موافقة الإدارة على السعر']);
    t(['تجهيز تقرير إطلاق الموقع', 'تقرير شامل للمرحلة الأخيرة', 'high', 'new', today, today, '17:00', null, c2, p1, null, null]);
    t(['مراجعة عقد البنك (الفقرة 12)', 'بند الحماية — طلب التعديل من المستشار', 'high', 'in_progress', d(-2), d(-2), null, null, c8, p4, null, 'متأخرة — أولوية قصوى']);
    t(['تأكيد موعد عرض CRM التجريبي', 'التنسيق مع فريق النخبة', 'medium', 'new', today, today, '14:00', null, c5, p2, null, null]);
    t(['إرسال تقرير تقدم الحملة', 'أرقام الأسبوع: نقرات، تحويلات، تكلفة', 'medium', 'new', d(1), d(1), '11:00', null, c9, p3, null, null]);
    t(['تحديث الفواتير المالية', 'فواتير يوليو وأغسطس', 'low', 'new', null, d(3), null, null, c7, null, null, null]);
    t(['تجهيز محضر اجتماع اللجنة', '', 'medium', 'new', today, today, '16:00', null, null, p3, null, null]);
    t(['متابعة عرض سعر الموردين', '', 'high', 'waiting', d(-1), d(-1), null, null, c6, null, null, 'بانتظار رد المورد']);
    t(['تصميم الشعار الجديد', '3 مسودات أولية', 'medium', 'in_progress', d(2), d(5), null, null, null, p1, null, null]);
    t(['تحديث قاعدة بيانات العملاء', 'استيراد العملاء الجدد', 'low', 'new', null, d(7), null, null, null, p2, null, null]);
    t(['إرسال العقد للمستشار القانوني', 'نسخة التجديد بعد تعديل البند 12', 'high', 'waiting', today, today, '15:00', null, c4, p4, null, null]);
    t(['سداد رسوم النطاق والاستضافة', '', 'medium', 'new', null, d(-3), null, null, null, p1, null, 'متأخرة']);
    const t13 = t(['مراجعة خطة التسويق الرقمي', '', 'medium', 'completed', d(-2), today, '09:40', null, c9, p3, null, null], dt(0, '09:40'));
    const t14 = t(['تحديد مسودة عرض البنك', '', 'high', 'completed', d(-4), d(-1), null, null, c8, p4, null, null], dt(-1, '13:20'));

    // ===== الاجتماعات =====
    const insM = db.prepare('INSERT INTO meetings (title, start_at, end_at, location, link, subject, agenda, minutes, decisions, status, project_id, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)');
    const m1 = insM.run('متابعة تطوير الموقع', dt(0, '08:00'), dt(0, '08:30'), null, 'https://meet.ufq-tech.sa/website', 'مناقشة آخر مستجدات التصميم والاختبارات', '1) حالة التصميم\n2) نتائج الاختبارات\n3) خطة الإطلاق', null, null, 'scheduled', p1, now, now).lastInsertRowid;
    const m2 = insM.run('اجتماع اللجنة — عميل النخبة', dt(0, '11:00'), dt(0, '12:00'), 'مقر الشركة — قاعة الاجتماعات', null, 'مراجعة متطلبات CRM والمراحل القادمة', '1) المراحل المنجزة\n2) متطلبات الفريق\n3) الجدول الزمني', null, null, 'scheduled', p2, now, now).lastInsertRowid;
    const m3 = insM.run('مراجعة خطة التسويق', dt(-1, '10:00'), dt(-1, '11:00'), 'مقر الشركة', null, 'نتائج الأسبوع الأول للحملة', '', 'أُقرت زيادة الميزانية الإعلانية 15% أسبوعيًا.\nتم إسناد محتوى الفيديو لفريق التصميم.', '1) زيادة الميزانية 15%\n2) تسليم الفيديو خلال 5 أيام', 'done', p3, now, now).lastInsertRowid;
    const m4 = insM.run('تجديد العقد — بنك التنمية', dt(3, '09:30'), dt(3, '10:30'), 'فروع بنك التنمية — الدور 3', null, 'التفاوض على تجديد العقد السنوي', '1) بنود العقد\n2) الأسعار\n3) مدة التجديد', null, null, 'scheduled', p4, now, now).lastInsertRowid;
    for (const [mid, cids] of [[m1, [c1, c2]], [m2, [c3, c5]], [m3, [c9]], [m4, [c8]]]) {
      for (const cid of cids) q.run('INSERT OR IGNORE INTO meeting_attendees (meeting_id, contact_id) VALUES (?,?)', mid, cid);
    }
    // مهام ناتجة عن اجتماع أمس
    q.run(`INSERT INTO tasks (title, description, priority, status, due_date, project_id, meeting_id, notes, created_by, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
      'زيادة الميزانية الإعلانية 15%', 'مهمة ناتجة عن اجتماع: مراجعة خطة التسويق', 'medium', 'new', d(2), p3, m3, 'من محضر الاجتماع', adminId, dt(-1, '11:30'), now);
    q.run(`INSERT INTO tasks (title, description, priority, status, due_date, project_id, meeting_id, notes, created_by, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
      'تسليم فيديو الحملة', 'مهمة ناتجة عن اجتماع: مراجعة خطة التسويق', 'high', 'new', d(4), p3, m3, 'من محضر الاجتماع', adminId, dt(-1, '11:30'), now);

    // ===== المواعيد (Events) =====
    const insE = db.prepare('INSERT INTO events (title, type, start_at, end_at, location, link, description, status, contact_id, project_id, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)');
    insE.run('اتصال بالعميلة ليلى', 'call', dt(0, '09:30'), dt(0, '09:45'), null, null, 'مناقشة أرقام الحملة', 'scheduled', c9, p3, now, now);
    insE.run('متابعة مشروع CRM', 'followup', dt(0, '11:30'), dt(0, '12:00'), null, null, 'مراجعة التقدم مع ريم', 'scheduled', c5, p2, now, now);
    insE.run('موعد بنك التنمية', 'appointment', dt(0, '13:00'), dt(0, '14:00'), 'بنك التنمية — الدور 3', null, 'تسليم المستندات', 'scheduled', c8, p4, now, now);
    insE.run('مراجعة مستندات المشروع', 'other', dt(0, '15:00'), dt(0, '16:00'), 'مكتب الإدارة', null, 'مراجعة العقود والمستندات النهائية', 'scheduled', null, p1, now, now);
    insE.run('زيارة المورد — التوريدات', 'appointment', dt(1, '09:30'), dt(1, '10:30'), 'مستودع المورد', null, null, 'scheduled', c6, null, now, now);
    insE.run('اجتماع داخلي — فريق التسويق', 'meeting', dt(1, '16:00'), dt(1, '17:00'), 'مقر الشركة', null, 'مراجعة أداء الأسبوع', 'scheduled', null, p3, now, now);
    insE.run('توقيع عقد التجديد', 'appointment', dt(2, '12:00'), dt(2, '13:00'), 'مكتب المستشار القانوني', null, 'التوقيع النهائي بعد المراجعة', 'scheduled', c4, p4, now, now);

    // ===== التذكيرات =====
    const insR = db.prepare('INSERT INTO reminders (title, description, remind_at, status, contact_id, task_id, project_id, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)');
    insR.run('اتصال بأحمد الغامدي', 'سؤال عن رأيهم في العرض', dt(0, '10:00'), 'pending', c1, t1, p1, now, now);
    insR.run('إرسال عرض السعر', '', dt(0, '12:00'), 'pending', null, null, p1, now, now);
    insR.run('مراجعة العقد', 'قبل اجتماع البنك', dt(0, '14:30'), 'pending', c4, null, p4, now, now);
    insR.run('متابعة نورة', 'سؤال عن موافقة الإدارة', dt(1, '09:00'), 'pending', c2, null, p1, now, now);
    insR.run('تجهيز جدول الأعمال', 'لاجتماع اللجنة القادم', dt(2, '10:00'), 'pending', null, null, p2, now, now);

    // ===== المتابعات (7 مستحقة اليوم) =====
    const insF = db.prepare('INSERT INTO follow_ups (contact_id, project_id, subject, last_contact_at, next_date, status, priority, notes, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)');
    insF.run(c1, p1, 'اعتماد العرض المعدل', dt(-3, '14:20'), today, 'needs', 'high', 'أهم متابعة اليوم', now, now);
    insF.run(c5, p2, 'رد على عرض CRM', dt(-5, '09:30'), d(-1), 'waiting', 'high', 'تجاوز الموعد', now, now);
    insF.run(c10, null, 'تأكيد طلب الطباعة', dt(-2, '10:45'), today, 'needs', 'medium', null, now, now);
    insF.run(c9, p3, 'تأكيد إطلاق الحملة', dt(-3, '17:10'), today, 'waiting', 'high', null, now, now);
    insF.run(c4, p4, 'متابعة مراجعة العقد', dt(-2, '12:00'), d(-1), 'waiting', 'high', 'مرتبط بتوقيع العقد', now, now);
    insF.run(c8, p4, 'الاتصال بالبنك حول التجديد', dt(-4, '15:20'), today, 'needs', 'medium', null, now, now);
    insF.run(c7, null, 'تأكيد الفواتير الشهرية', dt(-1, '11:00'), today, 'waiting', 'low', null, now, now);
    insF.run(c2, p1, 'موافقة الإدارة على الموقع', dt(-6, '13:00'), today, 'done', 'medium', null, now, now);
    insF.run(c3, p2, 'جدولة اجتماع الربع الثالث', dt(-8, '16:00'), d(5), 'postponed', 'medium', 'أجّل للاجتماع القادم', now, now);

    // ===== الاتصالات =====
    const insCall = db.prepare('INSERT INTO calls (contact_id, phone, direction, called_at, duration_seconds, subject, outcome, needs_follow_up, follow_up_date, follow_up_notes, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)');
    insCall.run(c1, '0551112233', 'in', dt(0, '08:12'), 540, 'متابعة العرض', 'وعد بالرد قبل نهاية اليوم', 1, today, 'اتصال بعد موافقة الإدارة', now, now);
    insCall.run(c8, '0558889900', 'missed', dt(0, '07:30'), 0, '', 'مكالمه فائتة — حاول الاتصال مجددًا', 1, today, null, now, now);
    insCall.run(c5, '0555556677', 'out', dt(-1, '11:20'), 720, 'عرض CRM التجريبي', 'ممتاز — اتفقنا على الاجتماع', 0, null, null, now, now);
    insCall.run(c10, '0550001122', 'out', dt(-2, '13:30'), 300, 'طلب الطباعة', 'التسليم خلال 3 أيام', 0, null, null, now, now);
    insCall.run(c9, '0559990011', 'in', dt(-3, '17:10'), 480, 'أسئلة عن الحملة', 'أرسلت التقرير بالتفاصيل', 0, null, null, now, now);
    insCall.run(c4, '0554445566', 'out', dt(-4, '12:00'), 900, 'مراجعة العقد', 'طلب إضافة بند حماية المنافسة', 1, d(2), 'ارسل العقد المعدل', now, now);

    // ===== الملاحظات =====
    const insN = db.prepare('INSERT INTO notes (title, content, type, contact_id, project_id, is_pinned, is_favorite, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)');
    const n1 = insN.run('محضر اجتماع خطة التسويق', 'الحضور: ليلى، فريق التسويق\n\n- نتائج الأسبوع الأول إيجابية\n- تكلفة النقرة انخفضت 12%\n- التحويل ارتفع 8%\n\nالقرارات:\n- زيادة الميزانية 15%\n- فيديو ترويجي خلال 5 أيام', 'meeting', null, p3, 1, 0, dt(-1, '11:30'), now).lastInsertRowid;
    const n2 = insN.run('أفكار لصفحة الهبوط الجديدة', '1) عنوان قوي + CTA واضح\n2) شهادات عملاء حقيقيين\n3) عرض خاص لأول 10 عملاء\n4) فيديو تعريفي 60 ثانية', 'quick', null, p1, 1, 1, dt(-2, '09:10'), now).lastInsertRowid;
    const n3 = insN.run('ملاحظات عن أحمد الغامدي', 'حساس من التأخير — أرسل التقارير قبل الموعد.\nيفضل الاجتماعات القصيرة في الصباح.\nقرار المشتريات يمر بمدير الإدارة.', 'contact', c1, p1, 0, 0, dt(-3, '15:00'), now).lastInsertRowid;
    const n4 = insN.run('متطلبات CRM — فريق النخبة', '1) لوحة متابعة عملاء\n2) تقارير أسبوعية آلية\n3) تكامل واتساب\n4) تنبيهات للمبيعات', 'project', null, p2, 0, 0, dt(-4, '10:00'), now).lastInsertRowid;
    const n5 = insN.run('تجهيز التقرير الشهري', 'اجمع: مهام مكتملة، مصروفات، اجتماعات، متابعات\nأرسله للإدارة قبل الخميس', 'personal', null, null, 0, 0, dt(-1, '18:00'), now).lastInsertRowid;
    const tag = (noteId, name) => {
      const ex = q.get('SELECT id FROM tags WHERE lower(name)=lower(?)', name);
      const tid = ex ? ex.id : q.run('INSERT INTO tags (name) VALUES (?)', name).lastInsertRowid;
      q.run('INSERT OR IGNORE INTO note_tags (note_id, tag_id) VALUES (?,?)', noteId, tid);
    };
    tag(n1, 'تسويق'); tag(n1, 'محضر'); tag(n2, 'أفكار'); tag(n4, 'CRM'); tag(n4, 'متطلبات'); tag(n5, 'تقارير');

    // ===== الملفات =====
    const fileDefs = [
      ['خطة إطلاق الموقع.txt', 'document', p1, c2, 'خطة المراحل النهائية مع جدول التسليم.\n\nالأسبوع الأول: اختبارات الأداء\nالأسبوع الثاني: تدريب الفريق\nالأسبوع الثالث: الإطلاق التجريبي\nالأسبوع الرابع: الإطلاق الرسمي'],
      ['عرض السعر المعدل - الأفق.txt', 'quote', p1, c1, 'عرض سعر — مشروع الموقع الجديد\n\n- تطوير الواجهة: 18,000 ر.س\n- لوحة التحكم: 12,000 ر.س\n- التدريب والدعم (شهر): 4,000 ر.س\n\nالإجمالي: 34,000 ر.س (شامل الضريبة)'],
      ['عقد بنك التنمية - مسودة.txt', 'contract', p4, c8, 'مسودة عقد تجديد الخدمة السنوي\n\nالبند 12: بند الحماية — بانتظار تعديل المستشار\nمدة العقد: 12 شهرًا\nسعر الخدمة السنوية: 96,000 ر.س'],
      ['تقرير الحملة - أغسطس.txt', 'report', p3, c9, 'تقرير الحملة الإعلانية — أغسطس\n\nالإنفاق: 15,400 ر.س\nالنقرات: 48,200\nالتحويلات: 1,240\nالتكلفة لكل تحويل: 12.4 ر.س\n\nتوصية: زيادة ميزانية الفيديو 20%'],
      ['فاتورة رقم 123.txt', 'invoice', null, c7, 'فاتورة #123 — شهري سبتمبر\n\nخدمات الاستضافة والدعم: 2,500 ر.س\nتاريخ الاستحقاق: نهاية الشهر'],
    ];
    for (const [name, cat, proj, cont, content] of fileDefs) {
      const stored = `seed-${Date.now()}-${Math.random().toString(36).slice(2, 8)}.txt`;
      fs.writeFileSync(path.join(UPLOADS, stored), content, 'utf8');
      q.run('INSERT INTO files (original_name, stored_name, mime, size, category, contact_id, project_id, task_id, meeting_id, notes, uploaded_by, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',
        name, stored, 'text/plain', Buffer.byteLength(content), cat, cont, proj, null, null, null, adminId, dt(0, '08:00'), now);
    }

    // ===== المصروفات =====
    const insX = db.prepare('INSERT INTO expenses (amount, category, expense_date, payment_method, description, contact_id, project_id, file_id, notes, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)');
    insX.run(120, 'meals', today, 'cash', 'قهوة وفطور اجتماع اللجنة', null, p3, null, null, now, now);
    insX.run(60, 'transport', today, 'card', 'مواصلات — بنك التنمية', null, p4, null, null, now, now);
    insX.run(450, 'marketing', d(-1), 'card', 'مواد إعلانية الحملة', c9, p3, null, null, now, now);
    insX.run(350, 'software', d(-2), 'card', 'رسوم النطاق والاستHosting', null, p1, null, null, now, now);
    insX.run(800, 'meals', d(-4), 'card', 'عشاء عمل —Client Meeting', c1, p1, null, null, now, now);
    insX.run(180, 'supplies', d(-6), 'cash', 'حبر وسائط طباعة', c10, null, null, null, now, now);
    insX.run(600, 'software', d(-8), 'bank', 'اشتراك CRM الشهري', null, p2, null, null, now, now);
    insX.run(240, 'supplies', d(-12), 'cash', 'قرطاسية مكتبية', null, null, null, null, now, now);
    insX.run(550, 'travel', d(-15), 'card', 'رحلة عمل الرياض', c8, p4, null, null, now, now);
    insX.run(300, 'utilities', d(-20), 'bank', 'إنترنت المكتب', null, null, null, null, now, now);

    // ===== إشعارات أولية =====
    q.run('INSERT INTO notifications (user_id, type, title, body, entity, entity_id, is_read, created_at) VALUES (?,?,?,?,?,?,0,?)', adminId, 'task', 'مهمة متاخرة: مراجعة عقد البنك', 'متأخرة منذ يومين', 'tasks', 3, dt(0, '08:00'));
    q.run('INSERT INTO notifications (user_id, type, title, body, entity, entity_id, is_read, created_at) VALUES (?,?,?,?,?,?,0,?)', adminId, 'followup', '7 متابعات مستحقة اليوم', 'راجع قسم المتابعات للبدء', 'followups', null, dt(0, '08:00'));
    q.run('INSERT INTO notifications (user_id, type, title, body, entity, entity_id, is_read, created_at) VALUES (?,?,?,?,?,?,1,?)', adminId, 'meeting', 'اجتماع بعد 30 دقيقة: متابعة تطوير الموقع', 'رابط الاجتماع في التقويم', 'meetings', m1, dt(0, '07:30'));

    // ===== سجل عمليات =====
    const insA = db.prepare('INSERT INTO activity_logs (user_id, action, entity, entity_id, details, created_at) VALUES (?,?,?,?,?,?)');
    insA.run(adminId, 'login', 'auth', adminId, 'تسجيل دخول (admin@company.sa)', dt(0, '07:55'));
    insA.run(adminId, 'create', 'tasks', t1, 'إنشاء مهمة «إرسال العرض المعدل لأحمد الغامدي»', dt(-1, '09:05'));
    insA.run(adminId, 'create', 'meetings', m2, 'اجتماع «اجتماع اللجنة — عميل النخبة»', dt(-1, '10:00'));
    insA.run(adminId, 'status', 'tasks', t13, 'تغيير حالة «مراجعة خطة التسويق الرقمي» من (قيد التنفيذ) إلى (مكتملة)', dt(0, '09:40'));
    insA.run(adminId, 'create', 'files', 1, 'رفع ملف «خطة إطلاق الموقع.txt»', dt(0, '08:00'));
    insA.run(2, 'update', 'notes', n2, 'تعديل ملاحظة «أفكار لصفحة الهبوط الجديدة»', dt(-1, '20:15'));
  });
  tx();
  console.log('🌱 تم زرع البيانات التجريبية بنجاح');
  console.log('   المدير:   admin@company.sa  / admin123');
  console.log('   السكرتير: sara@company.sa   / sara123');
  console.log('   الموظف:   khalid@company.sa / khalid123');
}

function maybeSeed() {
  const { c } = q.get('SELECT COUNT(*) c FROM users');
  if (c === 0) seed();
}

module.exports = { maybeSeed, seed };

if (require.main === module) {
  const force = process.argv.includes('--force');
  if (force) {
    console.log('⚠️  مسح كل البيانات وإعادة الزرع...');
    const tables = q.all(`SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'`);
    for (const t of tables) q.run(`DELETE FROM ${t.name}`);
  }
  maybeSeed();
  if (force) seed();
}
