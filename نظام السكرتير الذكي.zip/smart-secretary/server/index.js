'use strict';
const { PORT } = require('./config');
const { q } = require('./db');
const app = require('./app');
const { tick } = require('./services/notify');
const { maybeSeed } = require('./seed');

maybeSeed();

const HOST = process.env.HOST || '0.0.0.0';
const server = app.listen(PORT, HOST, () => {
  console.log(`✅ السكرتير الذكي يعمل على http://${HOST}:${PORT}`);
});

// الجدولة: كل 60 ثانية نفحص التذكيرات والمواعيد والمتابعات
tick();
setInterval(tick, 60 * 1000);

process.on('SIGINT', () => { server.close(); process.exit(0); });
process.on('unhandledRejection', (e) => console.error('[unhandledRejection]', e));

module.exports = server;
