'use strict';
// معالجة أخطاء موحدة + Rate Limit بسيط على تسجيل الدخول
const { q } = require('../db');

function notFound(req, res) {
  if (req.originalUrl.startsWith('/api/')) return res.status(404).json({ error: 'الendpoint غير موجود' });
  return res.status(404).send('404');
}

function errorHandler(err, req, res, next) { // eslint-disable-line no-unused-vars
  const status = err.status || 500;
  if (status >= 500) console.error('[error]', req.method, req.originalUrl, err);
  res.status(status).json({ error: err.expose ? err.message : (status >= 500 ? 'خطأ في الخادم' : err.message) });
}

const httpError = (status, message) => {
  const e = new Error(message);
  e.status = status;
  e.expose = status < 500;
  return e;
};

// Rate limit: N طلبات لكل فترة لكل مفتاح
function rateLimit(max, windowMs, keyFn) {
  const hits = new Map();
  return (req, res, next) => {
    const key = keyFn(req) || req.ip;
    const now = Date.now();
    const arr = (hits.get(key) || []).filter((t) => now - t < windowMs);
    if (arr.length >= max) {
      return res.status(429).json({ error: 'محاولات كثيرة، حاول بعد قليل' });
    }
    arr.push(now);
    hits.set(key, arr);
    next();
  };
}

module.exports = { notFound, errorHandler, httpError, rateLimit, q };
