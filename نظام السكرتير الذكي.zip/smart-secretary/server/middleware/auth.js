'use strict';
const jwt = require('jsonwebtoken');
const { q } = require('../db');
const { SECRET } = require('../config');

function loadUser(id) {
  const user = q.get(`SELECT u.*, r.name AS role FROM users u LEFT JOIN roles r ON r.id=u.role_id WHERE u.id=? AND u.deleted_at IS NULL`, id);
  if (!user || !user.is_active) return null;
  delete user.password_hash;
  if (user.role === 'admin') {
    user.permissions = q.all('SELECT code FROM permissions').map((r) => r.code);
  } else {
    user.permissions = q.all(
      'SELECT p.code FROM permissions p JOIN role_permissions rp ON rp.permission_id=p.id WHERE rp.role_id=?',
      user.role_id
    ).map((r) => r.code);
  }
  return user;
}

function auth(req, res, next) {
  const h = req.headers.authorization || '';
  let token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (!token && req.query && req.query.tk) token = String(req.query.tk); // روابط مباشرة (معاينة صور، تنزيل)
  if (!token) return res.status(401).json({ error: 'تسجيل الدخول مطلوب' });
  try {
    const payload = jwt.verify(token, SECRET);
    const user = loadUser(payload.id);
    if (!user) return res.status(401).json({ error: 'الحساب غير صالح أو غير فعال' });
    req.user = user;
    next();
  } catch {
    return res.status(401).json({ error: 'انتهت الجلسة، يرجى تسجيل الدخول' });
  }
}

const requirePerm = (...codes) => (req, res, next) => {
  if (!req.user) return res.status(401).json({ error: 'unauthorized' });
  if (req.user.role === 'admin' || codes.some((c) => req.user.permissions.includes(c))) return next();
  return res.status(403).json({ error: 'ليس لديك صلاحية لأداء هذه العملية' });
};

module.exports = { auth, requirePerm, loadUser };
