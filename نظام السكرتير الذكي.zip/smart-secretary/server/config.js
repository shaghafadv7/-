'use strict';
// إعدادات عامة — المفتاح السري يُخزَّن في ملف محلي ليتبقى صالحًا بعد إعادة التشغيل
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });

const SECRET_FILE = path.join(DATA_DIR, 'secret.key');
let SECRET = process.env.JWT_SECRET;
if (!SECRET) {
  if (fs.existsSync(SECRET_FILE)) SECRET = fs.readFileSync(SECRET_FILE, 'utf8').trim();
  else {
    SECRET = crypto.randomBytes(48).toString('hex');
    fs.writeFileSync(SECRET_FILE, SECRET, { mode: 0o600 });
  }
}

module.exports = {
  SECRET,
  PORT: parseInt(process.env.PORT || '4000', 10),
  DATA_DIR,
  TOKEN_TTL: '7d',
};
