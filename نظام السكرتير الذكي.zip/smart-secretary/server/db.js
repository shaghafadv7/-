'use strict';
// طبقة قاعدة البيانات — SQLite (WAL) بالعلاقات والفهارس
const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });
const DB_PATH = process.env.DB_PATH || path.join(DATA_DIR, 'app.db');

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 5000');

const SCHEMA = `
CREATE TABLE IF NOT EXISTS roles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  is_system INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS permissions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  label TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS role_permissions (
  role_id INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  permission_id INTEGER NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
  PRIMARY KEY (role_id, permission_id)
);
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  phone TEXT,
  password_hash TEXT NOT NULL,
  role_id INTEGER REFERENCES roles(id) ON DELETE RESTRICT,
  avatar TEXT,
  is_active INTEGER NOT NULL DEFAULT 1,
  last_login_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);
CREATE TABLE IF NOT EXISTS contacts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  first_name TEXT NOT NULL,
  last_name TEXT,
  job_title TEXT,
  company TEXT,
  phone TEXT,
  whatsapp TEXT,
  email TEXT,
  relation_type TEXT NOT NULL DEFAULT 'client',
  project_id INTEGER REFERENCES projects(id) ON DELETE SET NULL,
  last_contact_at TEXT,
  next_follow_up_at TEXT,
  notes TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_contacts_name ON contacts(first_name, company);
CREATE TABLE IF NOT EXISTS projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT,
  client_name TEXT,
  contact_id INTEGER REFERENCES contacts(id) ON DELETE SET NULL,
  owner_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  start_date TEXT,
  due_date TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  progress INTEGER NOT NULL DEFAULT 0,
  color TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);
CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  description TEXT,
  priority TEXT NOT NULL DEFAULT 'medium',
  status TEXT NOT NULL DEFAULT 'new',
  start_date TEXT,
  due_date TEXT,
  due_time TEXT,
  reminder_at TEXT,
  contact_id INTEGER REFERENCES contacts(id) ON DELETE SET NULL,
  project_id INTEGER REFERENCES projects(id) ON DELETE SET NULL,
  meeting_id INTEGER REFERENCES meetings(id) ON DELETE SET NULL,
  notes TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  completed_at TEXT,
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_tasks_status_due ON tasks(status, due_date);
CREATE INDEX IF NOT EXISTS idx_tasks_project ON tasks(project_id);
CREATE INDEX IF NOT EXISTS idx_tasks_contact ON tasks(contact_id);
CREATE TABLE IF NOT EXISTS reminders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  description TEXT,
  remind_at TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  contact_id INTEGER REFERENCES contacts(id) ON DELETE SET NULL,
  task_id INTEGER REFERENCES tasks(id) ON DELETE SET NULL,
  project_id INTEGER REFERENCES projects(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_reminders_at ON reminders(remind_at, status);
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'appointment',
  start_at TEXT NOT NULL,
  end_at TEXT,
  location TEXT,
  link TEXT,
  description TEXT,
  status TEXT NOT NULL DEFAULT 'scheduled',
  contact_id INTEGER REFERENCES contacts(id) ON DELETE SET NULL,
  project_id INTEGER REFERENCES projects(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_events_start ON events(start_at);
CREATE TABLE IF NOT EXISTS meetings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  start_at TEXT NOT NULL,
  end_at TEXT,
  location TEXT,
  link TEXT,
  subject TEXT,
  agenda TEXT,
  minutes TEXT,
  decisions TEXT,
  status TEXT NOT NULL DEFAULT 'scheduled',
  project_id INTEGER REFERENCES projects(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_meetings_start ON meetings(start_at);
CREATE TABLE IF NOT EXISTS meeting_attendees (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  meeting_id INTEGER NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
  contact_id INTEGER NOT NULL REFERENCES contacts(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS calls (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  contact_id INTEGER REFERENCES contacts(id) ON DELETE SET NULL,
  phone TEXT,
  direction TEXT NOT NULL DEFAULT 'out',
  called_at TEXT NOT NULL,
  duration_seconds INTEGER NOT NULL DEFAULT 0,
  subject TEXT,
  outcome TEXT,
  needs_follow_up INTEGER NOT NULL DEFAULT 0,
  follow_up_date TEXT,
  follow_up_notes TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_calls_at ON calls(called_at);
CREATE TABLE IF NOT EXISTS follow_ups (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  contact_id INTEGER REFERENCES contacts(id) ON DELETE SET NULL,
  project_id INTEGER REFERENCES projects(id) ON DELETE SET NULL,
  subject TEXT NOT NULL,
  last_contact_at TEXT,
  next_date TEXT,
  status TEXT NOT NULL DEFAULT 'waiting',
  priority TEXT NOT NULL DEFAULT 'medium',
  notes TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_followups_next ON follow_ups(status, next_date);
CREATE TABLE IF NOT EXISTS notes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  content TEXT,
  type TEXT NOT NULL DEFAULT 'quick',
  contact_id INTEGER REFERENCES contacts(id) ON DELETE SET NULL,
  project_id INTEGER REFERENCES projects(id) ON DELETE SET NULL,
  is_pinned INTEGER NOT NULL DEFAULT 0,
  is_favorite INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);
CREATE TABLE IF NOT EXISTS tags (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS note_tags (
  note_id INTEGER NOT NULL REFERENCES notes(id) ON DELETE CASCADE,
  tag_id INTEGER NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
  PRIMARY KEY (note_id, tag_id)
);
CREATE TABLE IF NOT EXISTS files (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  original_name TEXT NOT NULL,
  stored_name TEXT NOT NULL,
  mime TEXT,
  size INTEGER NOT NULL DEFAULT 0,
  category TEXT NOT NULL DEFAULT 'document',
  contact_id INTEGER REFERENCES contacts(id) ON DELETE SET NULL,
  project_id INTEGER REFERENCES projects(id) ON DELETE SET NULL,
  task_id INTEGER REFERENCES tasks(id) ON DELETE SET NULL,
  meeting_id INTEGER REFERENCES meetings(id) ON DELETE SET NULL,
  notes TEXT,
  uploaded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);
CREATE TABLE IF NOT EXISTS expenses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  amount REAL NOT NULL,
  category TEXT NOT NULL DEFAULT 'other',
  expense_date TEXT NOT NULL,
  payment_method TEXT NOT NULL DEFAULT 'cash',
  description TEXT,
  contact_id INTEGER REFERENCES contacts(id) ON DELETE SET NULL,
  project_id INTEGER REFERENCES projects(id) ON DELETE SET NULL,
  file_id INTEGER REFERENCES files(id) ON DELETE SET NULL,
  notes TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(expense_date);
CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type TEXT NOT NULL DEFAULT 'info',
  title TEXT NOT NULL,
  body TEXT,
  entity TEXT,
  entity_id INTEGER,
  is_read INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, is_read);
CREATE TABLE IF NOT EXISTS activity_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  entity TEXT,
  entity_id INTEGER,
  details TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_logs_entity ON activity_logs(entity, created_at);
CREATE INDEX IF NOT EXISTS idx_logs_user ON activity_logs(user_id, created_at);
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS user_settings (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS notify_flags (
  flag_key TEXT PRIMARY KEY,
  at TEXT NOT NULL
);
`;

db.exec(SCHEMA);

const q = {
  get: (sql, ...a) => db.prepare(sql).get(...a),
  all: (sql, ...a) => db.prepare(sql).all(...a),
  run: (sql, ...a) => db.prepare(sql).run(...a),
};

const PERMS = [
  ['dashboard.view', 'لوحة التحكم'],
  ['workcenter.view', 'مركز العمل'],
  ['tasks.view', 'عرض المهام'], ['tasks.create', 'إنشاء مهام'], ['tasks.edit', 'تعديل المهام'], ['tasks.delete', 'حذف المهام'],
  ['calendar.view', 'عرض التقويم'], ['calendar.create', 'إضافة مواعيد'], ['calendar.edit', 'تعديل المواعيد'], ['calendar.delete', 'حذف المواعيد'],
  ['reminders.view', 'عرض التذكيرات'], ['reminders.create', 'إضافة تذكيرات'], ['reminders.edit', 'تعديل التذكيرات'], ['reminders.delete', 'حذف التذكيرات'],
  ['contacts.view', 'عرض الأشخاص'], ['contacts.create', 'إضافة أشخاص'], ['contacts.edit', 'تعديل الأشخاص'], ['contacts.delete', 'حذف الأشخاص'],
  ['calls.view', 'عرض الاتصالات'], ['calls.create', 'تسجيل اتصالات'], ['calls.edit', 'تعديل الاتصالات'], ['calls.delete', 'حذف الاتصالات'],
  ['meetings.view', 'عرض الاجتماعات'], ['meetings.create', 'إنشاء اجتماعات'], ['meetings.edit', 'تعديل الاجتماعات'], ['meetings.delete', 'حذف الاجتماعات'],
  ['followups.view', 'عرض المتابعات'], ['followups.create', 'إنشاء متابعات'], ['followups.edit', 'تعديل المتابعات'], ['followups.delete', 'حذف المتابعات'],
  ['notes.view', 'عرض الملاحظات'], ['notes.create', 'إضافة ملاحظات'], ['notes.edit', 'تعديل الملاحظات'], ['notes.delete', 'حذف الملاحظات'],
  ['projects.view', 'عرض المشاريع'], ['projects.create', 'إنشاء مشاريع'], ['projects.edit', 'تعديل المشاريع'], ['projects.delete', 'حذف المشاريع'],
  ['files.view', 'عرض الملفات'], ['files.create', 'رفع ملفات'], ['files.edit', 'تعديل الملفات'], ['files.delete', 'حذف الملفات'],
  ['expenses.view', 'عرض المصروفات'], ['expenses.create', 'تسجيل مصروفات'], ['expenses.edit', 'تعديل المصروفات'], ['expenses.delete', 'حذف المصروفات'],
  ['reports.view', 'التقارير'],
  ['settings.view', 'عرض الإعدادات'], ['settings.edit', 'تعديل الإعدادات'],
  ['users.view', 'عرض المستخدمين'], ['users.manage', 'إدارة المستخدمين'],
  ['audit.view', 'سجل العمليات'],
  ['ai.use', 'المساعد الذكي'],
];

function ensureBase() {
  const now = new Date().toISOString();
  const insRole = db.prepare('INSERT OR IGNORE INTO roles (name, description, is_system, created_at) VALUES (?,?,?,?)');
  const insPerm = db.prepare('INSERT OR IGNORE INTO permissions (code, label) VALUES (?,?)');
  for (const p of PERMS) insPerm.run(p[0], p[1]);
  insRole.run('admin', 'مدير النظام — كامل الصلاحيات', 1, now);
  insRole.run('secretary', 'سكرتير — يدير جميع أقسام العمل', 1, now);
  insRole.run('staff', 'موظف — صلاحيات محدودة للعرض والإدخال الأساسي', 1, now);
  // سكرتير: كل شيء عدا users.manage / settings.edit / audit.view
  const skip = new Set(['users.manage', 'settings.edit', 'audit.view']);
  const secRole = q.get('SELECT id FROM roles WHERE name=?', 'secretary');
  for (const [code] of PERMS) {
    if (!skip.has(code)) q.run('INSERT OR IGNORE INTO role_permissions (role_id, permission_id) SELECT ?, id FROM permissions WHERE code=?', secRole.id, code);
  }
  // موظف
  const staffCodes = ['dashboard.view', 'workcenter.view', 'tasks.view', 'tasks.create', 'tasks.edit', 'calendar.view',
    'contacts.view', 'calls.view', 'notes.view', 'notes.create', 'notes.edit', 'reminders.view',
    'followups.view', 'projects.view', 'files.view', 'expenses.view', 'ai.use'];
  const stRole = q.get('SELECT id FROM roles WHERE name=?', 'staff');
  for (const code of staffCodes) q.run('INSERT OR IGNORE INTO role_permissions (role_id, permission_id) SELECT ?, id FROM permissions WHERE code=?', stRole.id, code);
}
ensureBase();

module.exports = { db, q, DB_PATH, DATA_DIR, PERMS };
