'use strict';
const { Router } = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const multer = require('multer');
const { q } = require('../db');
const { auth, requirePerm } = require('../middleware/auth');
const { S, I, patch, softDelete, mustRow, nowStr, audit } = require('../lib');
const { httpError } = require('../middleware/errors');
const { DATA_DIR } = require('../db');

const r = Router();
r.use(auth);
const UPLOADS = process.env.UPLOADS_DIR || path.join(__dirname, '..', '..', 'public', 'uploads');
fs.mkdirSync(UPLOADS, { recursive: true });

const CATEGORIES = ['contract', 'quote', 'invoice', 'image', 'document', 'report', 'other'];

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOADS),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase().slice(0, 10) || '';
    cb(null, `${Date.now()}-${crypto.randomBytes(6).toString('hex')}${ext}`);
  },
});
const upload = multer({ storage, limits: { fileSize: 20 * 1024 * 1024 } });

r.get('/', requirePerm('files.view'), (req, res) => {
  const { category, q: search, contact_id, project_id, limit, offset } = req.query;
  const where = ['f.deleted_at IS NULL']; const params = [];
  if (category) { where.push(`f.category=?`); params.push(category); }
  if (contact_id) { where.push(`f.contact_id=?`); params.push(I(contact_id)); }
  if (project_id) { where.push(`f.project_id=?`); params.push(I(project_id)); }
  if (search) {
    const like = `%${String(search).replace(/[%_]/g, '\\$&')}%`;
    where.push(`(f.original_name LIKE ? ESCAPE '${String.fromCharCode(92)}' OR f.notes LIKE ? ESCAPE '${String.fromCharCode(92)}')`); params.push(like, like);
  }
  const lim = Math.min(Number(limit) || 50, 200);
  const off = Math.max(Number(offset) || 0, 0);
  const rows = q.all(`SELECT f.*, c.first_name, c.last_name, p.name project_name, u.name uploader
    FROM files f LEFT JOIN contacts c ON c.id=f.contact_id LEFT JOIN projects p ON p.id=f.project_id LEFT JOIN users u ON u.id=f.uploaded_by
    WHERE ${where.join(' AND ')} ORDER BY f.created_at DESC LIMIT ? OFFSET ?`, ...params, lim, off);
  const total = q.get(`SELECT COUNT(*) c FROM files f WHERE ${where.join(' AND ')}`, ...params).c;
  res.json({ items: rows, total, limit: lim, offset: off });
});

r.post('/', requirePerm('files.create'), upload.single('file'), (req, res) => {
  if (!req.file) throw httpError(400, 'أرفق ملفًا للرفع');
  const b = req.body || {};
  const category = CATEGORIES.includes(b.category) ? b.category : 'document';
  q.run('INSERT INTO files (original_name, stored_name, mime, size, category, contact_id, project_id, task_id, meeting_id, notes, uploaded_by, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',
    req.file.originalname, req.file.filename, req.file.mimetype, req.file.size, category,
    I(b.contact_id), I(b.project_id), I(b.task_id), I(b.meeting_id), S(b.notes), req.user.id, nowStr(), nowStr());
  const id = q.get('SELECT last_insert_rowid() id').id;
  audit.log(req.user, 'create', 'files', id, `رفع ملف «${req.file.originalname}»`);
  res.status(201).json({ id, file: q.get('SELECT * FROM files WHERE id=?', id) });
});

r.get('/:id', requirePerm('files.view'), (req, res) => {
  res.json({ file: mustRow('files', req.params.id) });
});

r.get('/:id/download', requirePerm('files.view'), (req, res) => {
  const f = mustRow('files', req.params.id);
  const p = path.join(UPLOADS, f.stored_name);
  if (!fs.existsSync(p)) throw httpError(404, 'الملف غير موجود على القرص');
  const inline = (f.mime || '').startsWith('image/');
  res.download(p, f.original_name, { headers: { 'Content-Type': f.mime || 'application/octet-stream', 'Content-Disposition': inline ? 'inline' : undefined } });
});

const FIELDS = ['original_name', 'category', 'contact_id', 'project_id', 'task_id', 'meeting_id', 'notes'];
r.patch('/:id', requirePerm('files.edit'), (req, res) => {
  const f = mustRow('files', req.params.id);
  res.json({ file: patch('files', f.id, req.body || {}, FIELDS, req.user, 'files', { original_name: 'الاسم', category: 'التصنيف' }) });
});

r.delete('/:id', requirePerm('files.delete'), (req, res) => {
  const f = mustRow('files', req.params.id);
  q.run('UPDATE files SET deleted_at=?, updated_at=? WHERE id=?', nowStr(), nowStr(), f.id);
  try { fs.unlinkSync(path.join(UPLOADS, f.stored_name)); } catch { /* ignore */ }
  audit.log(req.user, 'delete', 'files', f.id, `حذف ملف «${f.original_name}»`);
  res.json({ ok: true });
});

module.exports = r;
module.exports.DATA_DIR = DATA_DIR;
