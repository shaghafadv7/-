'use strict';
const { Router } = require('express');
const { q } = require('../db');
const { auth, requirePerm } = require('../middleware/auth');
const { todayStr, addDays, rangeDates } = require('../time');

const r = Router();
r.use(auth, requirePerm('reports.view'));

r.get('/summary', (req, res) => {
  const range = ['week', 'month', 'quarter', 'year'].includes(req.query.range) ? req.query.range : 'month';
  const { from, to } = rangeDates(range, todayStr());
  const t = (sql, ...p) => q.get(sql, ...p).c;
  res.json({
    range, from, to,
    tasks: {
      completed: t(`SELECT COUNT(*) c FROM tasks WHERE deleted_at IS NULL AND status='completed' AND date(completed_at) BETWEEN ? AND ?`, from, to),
      created: t(`SELECT COUNT(*) c FROM tasks WHERE deleted_at IS NULL AND date(created_at) BETWEEN ? AND ?`, from, to),
      overdue: t(`SELECT COUNT(*) c FROM tasks WHERE deleted_at IS NULL AND status NOT IN ('completed','cancelled') AND due_date < ?`, todayStr()),
      open: t(`SELECT COUNT(*) c FROM tasks WHERE deleted_at IS NULL AND status NOT IN ('completed','cancelled')`),
      byStatus: q.all(`SELECT status, COUNT(*) c FROM tasks WHERE deleted_at IS NULL AND status!='cancelled' GROUP BY status`),
    },
    meetings: t(`SELECT COUNT(*) c FROM meetings WHERE deleted_at IS NULL AND date(start_at) BETWEEN ? AND ?`, from, to),
    calls: {
      total: t(`SELECT COUNT(*) c FROM calls WHERE deleted_at IS NULL AND date(called_at) BETWEEN ? AND ?`, from, to),
      byDirection: q.all(`SELECT direction, COUNT(*) c FROM calls WHERE deleted_at IS NULL AND date(called_at) BETWEEN ? AND ? GROUP BY direction`, from, to),
    },
    followups: {
      done: t(`SELECT COUNT(*) c FROM follow_ups WHERE deleted_at IS NULL AND status IN ('done','completed') AND date(updated_at) BETWEEN ? AND ?`, from, to),
      open: t(`SELECT COUNT(*) c FROM follow_ups WHERE deleted_at IS NULL AND status IN ('waiting','needs')`),
      overdue: t(`SELECT COUNT(*) c FROM follow_ups WHERE deleted_at IS NULL AND status IN ('waiting','needs') AND next_date < ?`, todayStr()),
    },
    expenses: {
      total: q.get(`SELECT COALESCE(SUM(amount),0) t, COUNT(*) n FROM expenses WHERE deleted_at IS NULL AND expense_date BETWEEN ? AND ?`, from, to),
    },
    newContacts: t(`SELECT COUNT(*) c FROM contacts WHERE deleted_at IS NULL AND date(created_at) BETWEEN ? AND ?`, from, to),
  });
});

// إنتاجية يومية (آخر N يوم): مكتمل/جديد
r.get('/productivity', (req, res) => {
  const days = Math.min(Math.max(Number(req.query.days) || 30, 7), 90);
  const today = todayStr();
  const rows = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = addDays(today, -i);
    rows.push({
      date: d,
      done: q.get(`SELECT COUNT(*) c FROM tasks WHERE deleted_at IS NULL AND status='completed' AND date(completed_at)=?`, d).c,
      created: q.get(`SELECT COUNT(*) c FROM tasks WHERE deleted_at IS NULL AND date(created_at)=?`, d).c,
    });
  }
  res.json({ rows });
});

// مصروفات: حسب التصنيف أو الشهر
r.get('/expenses', (req, res) => {
  const range = ['week', 'month', 'quarter', 'year'].includes(req.query.range) ? req.query.range : 'month';
  const { from, to } = rangeDates(range, todayStr());
  const group = req.query.group === 'month' ? 'month' : 'category';
  if (group === 'month') {
    const rows = q.all(`SELECT substr(expense_date,1,7) period, SUM(amount) total, COUNT(*) n FROM expenses
      WHERE deleted_at IS NULL AND expense_date BETWEEN ? AND ? GROUP BY period ORDER BY period DESC LIMIT 12`, from, to);
    return res.json({ group, rows });
  }
  const rows = q.all(`SELECT category, SUM(amount) total, COUNT(*) n FROM expenses
    WHERE deleted_at IS NULL AND expense_date BETWEEN ? AND ? GROUP BY category ORDER BY total DESC`, from, to);
  res.json({ group, rows });
});

// الأعمال حسب المشروع
r.get('/projects', (req, res) => {
  const rows = q.all(
    `SELECT p.id, p.name, p.status, p.progress, p.due_date,
      (SELECT COUNT(*) c FROM tasks t WHERE t.project_id=p.id AND t.deleted_at IS NULL) total_tasks,
      (SELECT COUNT(*) c FROM tasks t WHERE t.project_id=p.id AND t.deleted_at IS NULL AND t.status='completed') done_tasks,
      (SELECT COALESCE(SUM(e.amount),0) s FROM expenses e WHERE e.project_id=p.id AND e.deleted_at IS NULL) expenses
     FROM projects p WHERE p.deleted_at IS NULL ORDER BY p.created_at DESC`);
  res.json({ rows });
});

// نشاط المستخدمين
r.get('/activity', (req, res) => {
  const days = Math.min(Math.max(Number(req.query.days) || 14, 7), 60);
  const from = addDays(todayStr(), -days + 1);
  const rows = q.all(
    `SELECT u.id, u.name, COUNT(a.id) actions, SUM(CASE WHEN a.action='create' THEN 1 ELSE 0 END) created
     FROM users u LEFT JOIN activity_logs a ON a.user_id=u.id AND date(a.created_at) >= ?
     WHERE u.deleted_at IS NULL GROUP BY u.id ORDER BY actions DESC`, from);
  res.json({ rows });
});

// تصدير CSV (بـ BOM ليقرأه Excel عربيًا)
r.get('/export.csv', (req, res) => {
  const type = String(req.query.type || 'tasks');
  const range = ['week', 'month', 'quarter', 'year'].includes(req.query.range) ? req.query.range : 'quarter';
  const { from, to } = rangeDates(range, todayStr());
  const esc = (v) => {
    if (v === null || v === undefined) return '';
    const s = String(v).replace(/"/g, '""');
    return /[",\n]/.test(s) ? `"${s}"` : s;
  };
  const csv = (headers, rows) => ['\uFEFF' + headers.map(esc).join(','), ...rows.map((r) => headers.map((h) => esc(r[h])).join(','))].join('\n');
  let body = '';
  if (type === 'tasks') {
    const rows = q.all(`SELECT t.id, t.title, t.priority, t.status, t.due_date, p.name project, c.first_name contact
      FROM tasks t LEFT JOIN projects p ON p.id=t.project_id LEFT JOIN contacts c ON c.id=t.contact_id
      WHERE t.deleted_at IS NULL AND COALESCE(t.due_date, t.created_at) BETWEEN ? AND ? ORDER BY t.created_at DESC`, from, to);
    body = csv(['id', 'title', 'priority', 'status', 'due_date', 'project', 'contact'], rows);
  } else if (type === 'calls') {
    const rows = q.all(`SELECT cl.id, c.first_name contact, cl.phone, cl.direction, cl.called_at, cl.duration_seconds, cl.subject, cl.outcome
      FROM calls cl LEFT JOIN contacts c ON c.id=cl.contact_id
      WHERE cl.deleted_at IS NULL AND cl.called_at BETWEEN ? AND ? ORDER BY cl.called_at DESC`, from + ' 00:00:00', to + ' 23:59:59');
    body = csv(['id', 'contact', 'phone', 'direction', 'called_at', 'duration_seconds', 'subject', 'outcome'], rows);
  } else if (type === 'expenses') {
    const rows = q.all(`SELECT e.id, e.amount, e.category, e.expense_date, e.payment_method, e.description, c.first_name contact, p.name project
      FROM expenses e LEFT JOIN contacts c ON c.id=e.contact_id LEFT JOIN projects p ON p.id=e.project_id
      WHERE e.deleted_at IS NULL AND e.expense_date BETWEEN ? AND ? ORDER BY e.expense_date DESC`, from, to);
    body = csv(['id', 'amount', 'category', 'expense_date', 'payment_method', 'description', 'contact', 'project'], rows);
  } else if (type === 'followups') {
    const rows = q.all(`SELECT f.id, c.first_name contact, f.subject, f.status, f.last_contact_at, f.next_date, f.notes
      FROM follow_ups f LEFT JOIN contacts c ON c.id=f.contact_id
      WHERE f.deleted_at IS NULL ORDER BY f.next_date`);
    body = csv(['id', 'contact', 'subject', 'status', 'last_contact_at', 'next_date', 'notes'], rows);
  } else if (type === 'contacts') {
    const rows = q.all(`SELECT id, first_name, last_name, job_title, company, phone, email, relation_type FROM contacts WHERE deleted_at IS NULL`);
    body = csv(['id', 'first_name', 'last_name', 'job_title', 'company', 'phone', 'email', 'relation_type'], rows);
  } else {
    return res.status(400).json({ error: 'نوع غير معروف' });
  }
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="${type}-${range}.csv"`);
  res.send(body);
});

module.exports = r;
