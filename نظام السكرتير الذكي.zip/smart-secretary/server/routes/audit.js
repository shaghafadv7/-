'use strict';
const { Router } = require('express');
const { q } = require('../db');
const { auth, requirePerm } = require('../middleware/auth');
const { I } = require('../lib');

const r = Router();
r.use(auth, requirePerm('audit.view'));

r.get('/', (req, res) => {
  const { entity, user_id, q: search, from, to, limit, offset } = req.query;
  const where = ['1=1']; const params = [];
  if (entity) { where.push(`a.entity=?`); params.push(entity); }
  if (user_id) { where.push(`a.user_id=?`); params.push(I(user_id)); }
  if (from) { where.push(`date(a.created_at)>=?`); params.push(from); }
  if (to) { where.push(`date(a.created_at)<=?`); params.push(to); }
  if (search) {
    const like = `%${String(search).replace(/[%_]/g, '\\$&')}%`;
    where.push(`(a.details LIKE ? ESCAPE '${String.fromCharCode(92)}' OR a.action LIKE ? ESCAPE '${String.fromCharCode(92)}')`);
    params.push(like, like);
  }
  const lim = Math.min(Number(limit) || 30, 100);
  const off = Math.max(Number(offset) || 0, 0);
  const rows = q.all(
    `SELECT a.*, u.name user_name FROM activity_logs a LEFT JOIN users u ON u.id=a.user_id
     WHERE ${where.join(' AND ')} ORDER BY a.created_at DESC, a.id DESC LIMIT ? OFFSET ?`, ...params, lim, off);
  const total = q.get(`SELECT COUNT(*) c FROM activity_logs a WHERE ${where.join(' AND ')}`, ...params).c;
  const entities = q.all('SELECT entity, COUNT(*) c FROM activity_logs WHERE entity IS NOT NULL GROUP BY entity ORDER BY c DESC LIMIT 20');
  res.json({ items: rows, total, entities, limit: lim, offset: off });
});

module.exports = r;
