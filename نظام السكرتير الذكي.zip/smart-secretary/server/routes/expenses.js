'use strict';
const { Router } = require('express');
const { q } = require('../db');
const { auth, requirePerm } = require('../middleware/auth');
const { S, I, N, patch, softDelete, mustRow, nowStr, audit } = require('../lib');
const { httpError } = require('../middleware/errors');
const { todayStr, addDays, rangeDates } = require('../time');

const r = Router();
r.use(auth);
const FIELDS = ['amount', 'category', 'expense_date', 'payment_method', 'description', 'contact_id', 'project_id', 'file_id', 'notes'];
const METHODS = ['cash', 'card', 'bank', 'wallet', 'other'];

r.get('/', requirePerm('expenses.view'), (req, res) => {
  const { from, to, category, contact_id, project_id, q: search, limit, offset } = req.query;
  const where = ['e.deleted_at IS NULL']; const params = [];
  if (from) { where.push(`e.expense_date>=?`); params.push(from); }
  if (to) { where.push(`e.expense_date<=?`); params.push(to); }
  if (category) { where.push(`e.category=?`); params.push(category); }
  if (contact_id) { where.push(`e.contact_id=?`); params.push(I(contact_id)); }
  if (project_id) { where.push(`e.project_id=?`); params.push(I(project_id)); }
  if (search) {
    const like = `%${String(search).replace(/[%_]/g, '\\$&')}%`;
    where.push(`(e.description LIKE ? ESCAPE '${String.fromCharCode(92)}' OR e.notes LIKE ? ESCAPE '${String.fromCharCode(92)}')`); params.push(like, like);
  }
  const lim = Math.min(Number(limit) || 50, 200);
  const off = Math.max(Number(offset) || 0, 0);
  const rows = q.all(`SELECT e.*, c.first_name, c.last_name, p.name project_name FROM expenses e
    LEFT JOIN contacts c ON c.id=e.contact_id LEFT JOIN projects p ON p.id=e.project_id
    WHERE ${where.join(' AND ')} ORDER BY e.expense_date DESC, e.id DESC LIMIT ? OFFSET ?`, ...params, lim, off);
  const total = q.get(`SELECT COUNT(*) c, COALESCE(SUM(amount),0) sum FROM expenses e WHERE ${where.join(' AND ')}`, ...params);
  res.json({ items: rows, total: total.c, sum: total.sum, limit: lim, offset: off });
});

// ملخص مصروفات: اليوم/الأسبوع/الشهر + حسب التصنيف
r.get('/summary', requirePerm('expenses.view'), (req, res) => {
  const today = todayStr();
  const week = rangeDates('week', today);
  const month = rangeDates('month', today);
  const by = (from, to) => q.get(`SELECT COALESCE(SUM(amount),0) total, COUNT(*) n FROM expenses WHERE deleted_at IS NULL AND expense_date BETWEEN ? AND ?`, from, to);
  const categories = q.all(`SELECT category, SUM(amount) total FROM expenses WHERE deleted_at IS NULL AND expense_date BETWEEN ? AND ? GROUP BY category ORDER BY total DESC`, month.from, today);
  const recent = q.all(`SELECT e.*, c.first_name, c.last_name, p.name project_name FROM expenses e
    LEFT JOIN contacts c ON c.id=e.contact_id LEFT JOIN projects p ON p.id=e.project_id
    WHERE e.deleted_at IS NULL ORDER BY e.expense_date DESC, e.id DESC LIMIT 10`, );
  res.json({
    today: by(today, today),
    week: by(week.from, week.to),
    month: by(month.from, today),
    byCategory: categories,
    recent,
  });
});

r.post('/', requirePerm('expenses.create'), (req, res) => {
  const b = req.body || {};
  const amount = N(b.amount);
  if (!amount || amount <= 0) throw httpError(400, 'المبلغ يجب أن يكون رقمًا أكبر من صفر');
  const date = S(b.expense_date) || todayStr();
  q.run('INSERT INTO expenses (amount, category, expense_date, payment_method, description, contact_id, project_id, file_id, notes, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
    amount, S(b.category) || 'other', date, METHODS.includes(b.payment_method) ? b.payment_method : 'cash',
    S(b.description), I(b.contact_id), I(b.project_id), I(b.file_id), S(b.notes), nowStr(), nowStr());
  const id = q.get('SELECT last_insert_rowid() id').id;
  audit.log(req.user, 'create', 'expenses', id, `مصروف ${amount} (${S(b.category) || 'other'})`);
  res.status(201).json({ id, expense: q.get('SELECT * FROM expenses WHERE id=?', id) });
});

r.patch('/:id', requirePerm('expenses.edit'), (req, res) => {
  const row = mustRow('expenses', req.params.id);
  const b = req.body || {};
  if (b.amount !== undefined) {
    const amount = N(b.amount);
    if (!amount || amount <= 0) throw httpError(400, 'المبلغ يجب أن يكون رقمًا أكبر من صفر');
  }
  res.json({ expense: patch('expenses', row.id, b, FIELDS, req.user, 'expenses', { amount: 'المبلغ', category: 'التصنيف', expense_date: 'التاريخ' }) });
});

r.delete('/:id', requirePerm('expenses.delete'), (req, res) => {
  const row = mustRow('expenses', req.params.id);
  softDelete('expenses', row.id, req.user, 'expenses', res, row.description || String(row.amount));
});

module.exports = r;
module.exports.addDays = addDays;
