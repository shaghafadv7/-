'use strict';
const { Router } = require('express');
const bcrypt = require('bcryptjs');
const { q } = require('../db');
const { auth, requirePerm } = require('../middleware/auth');
const { S, I, B } = require('../lib');
const { nowStr } = require('../time');
const { httpError } = require('../middleware/errors');
const audit = require('../services/audit');

const r = Router();
r.use(auth, requirePerm('users.view'));

r.get('/', (req, res) => {
  const rows = q.all(`SELECT u.id, u.name, u.email, u.phone, u.role_id, r.name role_name, u.is_active, u.last_login_at, u.avatar, u.created_at,
    (SELECT COUNT(*) c FROM tasks t WHERE t.created_by=u.id AND t.deleted_at IS NULL) tasks_count
    FROM users u LEFT JOIN roles r ON r.id=u.role_id WHERE u.deleted_at IS NULL ORDER BY u.created_at`);
  const roles = q.all(`SELECT r.*, (SELECT COUNT(*) c FROM role_permissions rp WHERE rp.role_id=r.id) perms_count,
    (SELECT COUNT(*) c FROM users u WHERE u.role_id=r.id AND u.deleted_at IS NULL) users_count
    FROM roles r ORDER BY r.id`);
  const rolePerms = {};
  for (const rp of q.all('SELECT rp.role_id, p.code FROM role_permissions rp JOIN permissions p ON p.id=rp.permission_id'))
    (rolePerms[rp.role_id] ||= []).push(rp.code);
  for (const r of roles) r.permissions = r.name === 'admin' ? 'all' : (rolePerms[r.id] || []);
  res.json({ items: rows, roles });
});

r.post('/', requirePerm('users.manage'), (req, res) => {
  const b = req.body || {};
  const name = S(b.name); const email = S(b.email); const password = String(b.password || '');
  if (!name || !email || !password) throw httpError(400, 'الاسم والبريد وكلمة المرور مطلوبون');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw httpError(400, 'بريد إلكتروني غير صالح');
  if (password.length < 6) throw httpError(400, 'كلمة المرور يجب ألا تقل عن 6 أحرف');
  if (q.get('SELECT id FROM users WHERE lower(email)=lower(?) AND deleted_at IS NULL', email)) throw httpError(409, 'البريد مستخدم بالفعل');
  const roleId = I(b.role_id) || q.get("SELECT id FROM roles WHERE name='staff'").id;
  q.run('INSERT INTO users (name, email, phone, password_hash, role_id, is_active, created_at, updated_at) VALUES (?,?,?,?,?,1,?,?)',
    name, email, S(b.phone), bcrypt.hashSync(password, 10), roleId, nowStr(), nowStr());
  const id = q.get('SELECT last_insert_rowid() id').id;
  audit.log(req.user, 'create', 'users', id, `إضافة مستخدم «${name}»`);
  res.status(201).json({ id });
});

r.patch('/:id', requirePerm('users.manage'), (req, res) => {
  const target = q.get('SELECT * FROM users WHERE id=? AND deleted_at IS NULL', I(req.params.id));
  if (!target) throw httpError(404, 'المستخدم غير موجود');
  const b = req.body || {};
  if (b.is_active !== undefined && Number(b.is_active) === 0 && target.id === req.user.id) throw httpError(400, 'لا يمكنك تعطيل حسابك الحالي');
  const sets = []; const params = [];
  if (b.name !== undefined) { sets.push('name=?'); params.push(S(b.name)); }
  if (b.email !== undefined) {
    const em = S(b.email);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)) throw httpError(400, 'بريد إلكتروني غير صالح');
    if (q.get('SELECT id FROM users WHERE lower(email)=lower(?) AND id<>? AND deleted_at IS NULL', em, target.id)) throw httpError(409, 'البريد مستخدم بالفعل');
    sets.push('email=?'); params.push(em);
  }
  if (b.phone !== undefined) { sets.push('phone=?'); params.push(S(b.phone)); }
  if (b.role_id !== undefined) { sets.push('role_id=?'); params.push(I(b.role_id)); }
  if (b.is_active !== undefined) { sets.push('is_active=?'); params.push(B(b.is_active)); }
  if (!sets.length) throw httpError(400, 'لا توجد بيانات');
  sets.push('updated_at=?'); params.push(nowStr(), target.id);
  q.run(`UPDATE users SET ${sets.join(', ')} WHERE id=?`, ...params);
  audit.log(req.user, 'update', 'users', target.id, `تعديل مستخدم «${target.name}»`);
  res.json({ ok: true });
});

r.post('/:id/reset-password', requirePerm('users.manage'), (req, res) => {
  const target = q.get('SELECT * FROM users WHERE id=? AND deleted_at IS NULL', I(req.params.id));
  if (!target) throw httpError(404, 'المستخدم غير موجود');
  const password = String((req.body || {}).password || '');
  if (password.length < 6) throw httpError(400, 'كلمة المرور يجب ألا تقل عن 6 أحرف');
  q.run('UPDATE users SET password_hash=?, updated_at=? WHERE id=?', bcrypt.hashSync(password, 10), nowStr(), target.id);
  audit.log(req.user, 'update', 'users', target.id, `إعادة تعيين كلمة مرور «${target.name}»`);
  res.json({ ok: true });
});

r.delete('/:id', requirePerm('users.manage'), (req, res) => {
  const target = q.get('SELECT * FROM users WHERE id=? AND deleted_at IS NULL', I(req.params.id));
  if (!target) throw httpError(404, 'المستخدم غير موجود');
  if (target.id === req.user.id) throw httpError(400, 'لا يمكنك حذف حسابك الحالي');
  q.run('UPDATE users SET deleted_at=?, is_active=0, updated_at=? WHERE id=?', nowStr(), nowStr(), target.id);
  audit.log(req.user, 'delete', 'users', target.id, `حذف مستخدم «${target.name}»`);
  res.json({ ok: true });
});

// ---- الأدوار والصلاحيات ----
r.get('/permissions', (req, res) => {
  res.json({ items: q.all('SELECT * FROM permissions ORDER BY id') });
});

r.put('/roles/:id/permissions', requirePerm('users.manage'), (req, res) => {
  const role = q.get('SELECT * FROM roles WHERE id=?', I(req.params.id));
  if (!role) throw httpError(404, 'الدور غير موجود');
  if (role.name === 'admin') throw httpError(400, 'لا يمكن تعديل صلاحيات مدير النظام');
  const codes = Array.isArray((req.body || {}).codes) ? req.body.codes : [];
  const tx = q.run;
  q.run('DELETE FROM role_permissions WHERE role_id=?', role.id);
  for (const code of codes) {
    const p = q.get('SELECT id FROM permissions WHERE code=?', code);
    if (p) q.run('INSERT OR IGNORE INTO role_permissions (role_id, permission_id) VALUES (?,?)', role.id, p.id);
  }
  audit.log(req.user, 'update', 'roles', role.id, `تعديل صلاحيات دور «${role.name}» (${codes.length} صلاحية)`);
  res.json({ ok: true });
});

module.exports = r;
