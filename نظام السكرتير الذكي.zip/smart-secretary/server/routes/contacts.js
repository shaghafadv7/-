'use strict';
const { Router } = require('express');
const { db, q } = require('../db');
const { auth, requirePerm } = require('../middleware/auth');
const { S, I, patch, softDelete, mustRow, nowStr, audit } = require('../lib');
const { httpError } = require('../middleware/errors');
const { todayStr } = require('../time');

const r = Router();
r.use(auth);
const FIELDS = ['first_name', 'last_name', 'job_title', 'company', 'phone', 'whatsapp', 'email', 'relation_type', 'project_id', 'last_contact_at', 'next_follow_up_at', 'notes'];
const LABELS = { first_name: 'الاسم', job_title: 'المسمى', company: 'الشركة', phone: 'الجوال', email: 'البريد', relation_type: 'نوع العلاقة', project_id: 'المشروع', notes: 'الملاحظات' };

r.get('/', requirePerm('contacts.view'), (req, res) => {
  const { q: search, relation_type, project_id, limit, offset } = req.query;
  const where = ['c.deleted_at IS NULL']; const params = [];
  if (relation_type) { where.push(`c.relation_type=?`); params.push(relation_type); }
  if (project_id) { where.push(`c.project_id=?`); params.push(I(project_id)); }
  if (search) {
    const like = `%${String(search).replace(/[%_]/g, '\\$&')}%`;
    where.push(`(c.first_name LIKE ? ESCAPE '${String.fromCharCode(92)}' OR c.last_name LIKE ? ESCAPE '${String.fromCharCode(92)}' OR c.company LIKE ? ESCAPE '${String.fromCharCode(92)}' OR c.phone LIKE ? ESCAPE '${String.fromCharCode(92)}' OR c.email LIKE ? ESCAPE '${String.fromCharCode(92)}' OR c.job_title LIKE ? ESCAPE '${String.fromCharCode(92)}')`);
    params.push(like, like, like, like, like, like);
  }
  const lim = Math.min(Number(limit) || 50, 200);
  const off = Math.max(Number(offset) || 0, 0);
  const rows = q.all(
    `SELECT c.*, p.name project_name FROM contacts c LEFT JOIN projects p ON p.id=c.project_id
     WHERE ${where.join(' AND ')} ORDER BY c.first_name ASC LIMIT ? OFFSET ?`, ...params, lim, off);
  const total = q.get(`SELECT COUNT(*) c FROM contacts c WHERE ${where.join(' AND ')}`, ...params).c;
  res.json({ items: rows, total, limit: lim, offset: off });
});

r.post('/', requirePerm('contacts.create'), (req, res) => {
  const b = req.body || {};
  const first = S(b.first_name);
  if (!first) throw httpError(400, 'اسم الشخص مطلوب');
  const email = S(b.email);
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw httpError(400, 'بريد إلكتروني غير صالح');
  q.run('INSERT INTO contacts (first_name, last_name, job_title, company, phone, whatsapp, email, relation_type, project_id, last_contact_at, next_follow_up_at, notes, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
    first, S(b.last_name), S(b.job_title), S(b.company), S(b.phone), S(b.whatsapp), email, S(b.relation_type) || 'client',
    I(b.project_id), S(b.last_contact_at), S(b.next_follow_up_at), S(b.notes), nowStr(), nowStr());
  const id = q.get('SELECT last_insert_rowid() id').id;
  audit.log(req.user, 'create', 'contacts', id, `إضافة شخص «${first}»`);
  res.status(201).json({ id, contact: q.get('SELECT * FROM contacts WHERE id=?', id) });
});

// تفاصيل الشخص + إحصائياته + Timeline كامل
r.get('/:id', requirePerm('contacts.view'), (req, res) => {
  const contact = mustRow('contacts', req.params.id);
  const cid = contact.id;
  const stats = {
    openTasks: q.get(`SELECT COUNT(*) c FROM tasks WHERE contact_id=? AND deleted_at IS NULL AND status NOT IN ('completed','cancelled')`, cid).c,
    calls: q.get(`SELECT COUNT(*) c FROM calls WHERE contact_id=? AND deleted_at IS NULL`, cid).c,
    meetings: q.get(`SELECT COUNT(*) c FROM meeting_attendees ma JOIN meetings m ON m.id=ma.meeting_id WHERE ma.contact_id=? AND m.deleted_at IS NULL`, cid).c,
    followups: q.get(`SELECT COUNT(*) c FROM follow_ups WHERE contact_id=? AND deleted_at IS NULL AND status IN ('waiting','needs')`, cid).c,
    notes: q.get(`SELECT COUNT(*) c FROM notes WHERE contact_id=? AND deleted_at IS NULL`, cid).c,
    files: q.get(`SELECT COUNT(*) c FROM files WHERE contact_id=? AND deleted_at IS NULL`, cid).c,
    expenses: q.get(`SELECT COALESCE(SUM(amount),0) t FROM expenses WHERE contact_id=? AND deleted_at IS NULL`, cid).t,
  };
  const timeline = [];
  for (const c of q.all(`SELECT * FROM calls WHERE contact_id=? AND deleted_at IS NULL ORDER BY called_at DESC LIMIT 20`, cid))
    timeline.push({ kind: 'call', id: c.id, date: c.called_at, title: c.subject || 'اتصال', sub: `${c.direction === 'in' ? 'وارد' : c.direction === 'out' ? 'صادر' : 'فائت'} • ${c.outcome || ''}`.trim(), route: '#/calls' });
  for (const m of q.all(`SELECT m.* FROM meetings m JOIN meeting_attendees ma ON ma.meeting_id=m.id WHERE ma.contact_id=? AND m.deleted_at IS NULL ORDER BY m.start_at DESC LIMIT 10`, cid))
    timeline.push({ kind: 'meeting', id: m.id, date: m.start_at, title: m.title, sub: 'اجتماع', route: '#/meetings' });
  for (const t of q.all(`SELECT * FROM tasks WHERE contact_id=? AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 15`, cid))
    timeline.push({ kind: 'task', id: t.id, date: t.created_at, title: t.title, sub: `مهمة • ${t.status}`, route: '#/tasks' });
  for (const f of q.all(`SELECT * FROM follow_ups WHERE contact_id=? AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 10`, cid))
    timeline.push({ kind: 'followup', id: f.id, date: f.created_at, title: f.subject, sub: 'متابعة', route: '#/followups' });
  for (const n of q.all(`SELECT * FROM notes WHERE contact_id=? AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 10`, cid))
    timeline.push({ kind: 'note', id: n.id, date: n.created_at, title: n.title, sub: 'ملاحظة', route: '#/notes' });
  for (const f of q.all(`SELECT * FROM files WHERE contact_id=? AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 10`, cid))
    timeline.push({ kind: 'file', id: f.id, date: f.created_at, title: f.original_name, sub: 'ملف', route: '#/files' });
  timeline.sort((a, b) => String(b.date).localeCompare(String(a.date)));
  res.json({ contact, stats, timeline: timeline.slice(0, 60) });
});

r.patch('/:id', requirePerm('contacts.edit'), (req, res) => {
  const row = mustRow('contacts', req.params.id);
  const b = req.body || {};
  const email = S(b.email);
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw httpError(400, 'بريد إلكتروني غير صالح');
  const updated = patch('contacts', row.id, b, FIELDS, req.user, 'contacts', LABELS);
  // عند تسجيل "آخر تواصل" جديد يقترح النظام تاريخ المتابعة تلقائيًا إن لم يُحدد
  if (b.last_contact_at && !b.next_follow_up_at && !updated.next_follow_up_at) {
    q.run('UPDATE contacts SET next_follow_up_at=?, updated_at=? WHERE id=?', todayStr(), nowStr(), row.id);
  }
  res.json({ contact: q.get('SELECT * FROM contacts WHERE id=?', row.id) });
});

r.delete('/:id', requirePerm('contacts.delete'), (req, res) => {
  const row = mustRow('contacts', req.params.id);
  const tx = db.transaction(() => {
    for (const t of ['tasks', 'follow_ups', 'calls', 'notes', 'expenses', 'files', 'events'])
      q.run(`UPDATE ${t} SET contact_id=NULL, updated_at=? WHERE contact_id=?`, nowStr(), row.id);
    q.run('DELETE FROM meeting_attendees WHERE contact_id=?', row.id);
    q.run(`UPDATE contacts SET deleted_at=?, updated_at=? WHERE id=?`, nowStr(), nowStr(), row.id);
  });
  tx();
  audit.log(req.user, 'delete', 'contacts', row.id, `تم حذف «${row.first_name}»`);
  res.json({ ok: true });
});

module.exports = r;
