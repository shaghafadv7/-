'use strict';
const { Router } = require('express');
const { q } = require('../db');
const { auth, requirePerm } = require('../middleware/auth');
const { S, I, N, patch, softDelete, mustRow, nowStr, audit } = require('../lib');
const { httpError } = require('../middleware/errors');
const { todayStr } = require('../time');

const r = Router();
r.use(auth);
const FIELDS = ['name', 'description', 'client_name', 'contact_id', 'owner_user_id', 'start_date', 'due_date', 'status', 'progress', 'color'];
const STATUS = ['active', 'on_hold', 'paused', 'completed'];

function withCounts(p) {
  const t = q.get(`SELECT COUNT(*) total, SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) done FROM tasks WHERE project_id=? AND deleted_at IS NULL`, p.id);
  return { ...p, total_tasks: t.total, done_tasks: t.done || 0 };
}

r.get('/', requirePerm('projects.view'), (req, res) => {
  const { status, q: search } = req.query;
  const where = ['p.deleted_at IS NULL']; const params = [];
  if (status) { where.push(`p.status=?`); params.push(status); }
  if (search) {
    const like = `%${String(search).replace(/[%_]/g, '\\$&')}%`;
    where.push(`(p.name LIKE ? ESCAPE '${String.fromCharCode(92)}' OR p.description LIKE ? ESCAPE '${String.fromCharCode(92)}' OR p.client_name LIKE ? ESCAPE '${String.fromCharCode(92)}')`);
    params.push(like, like, like);
  }
  const rows = q.all(`SELECT p.*, c.first_name, c.last_name, u.name owner_name FROM projects p
    LEFT JOIN contacts c ON c.id=p.contact_id LEFT JOIN users u ON u.id=p.owner_user_id
    WHERE ${where.join(' AND ')} ORDER BY p.created_at DESC`, ...params);
  res.json({ items: rows.map(withCounts) });
});

r.get('/:id', requirePerm('projects.view'), (req, res) => {
  const p = mustRow('projects', req.params.id);
  const today = todayStr();
  const tasks = q.all(`SELECT t.*, c.first_name, c.last_name FROM tasks t LEFT JOIN contacts c ON c.id=t.contact_id
    WHERE t.project_id=? AND t.deleted_at IS NULL ORDER BY CASE t.priority WHEN 'urgent' THEN 4 WHEN 'high' THEN 3 WHEN 'medium' THEN 2 ELSE 1 END DESC, t.due_date ASC LIMIT 100`, p.id);
  const statusCounts = { new: 0, in_progress: 0, waiting: 0, completed: 0, cancelled: 0 };
  for (const t of tasks) statusCounts[t.status] = (statusCounts[t.status] || 0) + 1;
  const meetings = q.all('SELECT id, title, start_at, status FROM meetings WHERE project_id=? AND deleted_at IS NULL AND date(start_at)>=? ORDER BY start_at LIMIT 10', p.id, today);
  const files = q.all('SELECT id, original_name, category, size, created_at FROM files WHERE project_id=? AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 10', p.id);
  const notes = q.all('SELECT id, title, content, created_at FROM notes WHERE project_id=? AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 10', p.id);
  const contacts = q.all('SELECT id, first_name, last_name, job_title, company FROM contacts WHERE project_id=? AND deleted_at IS NULL', p.id);
  const expenses = q.get('SELECT COALESCE(SUM(amount),0) total, COUNT(*) n FROM expenses WHERE project_id=? AND deleted_at IS NULL', p.id);
  const timeline = [];
  for (const t of q.all('SELECT id, title, created_at, status FROM tasks WHERE project_id=? AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 8', p.id))
    timeline.push({ kind: 'task', id: t.id, date: t.created_at, title: t.title, sub: 'مهمة' });
  for (const m of q.all('SELECT id, title, start_at FROM meetings WHERE project_id=? AND deleted_at IS NULL ORDER BY start_at DESC LIMIT 5', p.id))
    timeline.push({ kind: 'meeting', id: m.id, date: m.start_at, title: m.title, sub: 'اجتماع' });
  timeline.sort((a, b) => String(b.date).localeCompare(String(a.date)));
  res.json({
    project: { ...p, contact: p.contact_id ? q.get('SELECT * FROM contacts WHERE id=?', p.contact_id) : null, owner: p.owner_user_id ? q.get('SELECT id, name FROM users WHERE id=?', p.owner_user_id) : null },
    statusCounts, meetings, files, notes, contacts,
    expenses: { total: expenses.total, count: expenses.n },
    timeline: timeline.slice(0, 15),
  });
});

r.post('/', requirePerm('projects.create'), (req, res) => {
  const b = req.body || {};
  const name = S(b.name);
  if (!name) throw httpError(400, 'اسم المشروع مطلوب');
  q.run('INSERT INTO projects (name, description, client_name, contact_id, owner_user_id, start_date, due_date, status, progress, color, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
    name, S(b.description), S(b.client_name), I(b.contact_id), req.user.id, S(b.start_date), S(b.due_date),
    STATUS.includes(b.status) ? b.status : 'active', N(b.progress, 0), S(b.color) || '#0f9d8f', nowStr(), nowStr());
  const id = q.get('SELECT last_insert_rowid() id').id;
  audit.log(req.user, 'create', 'projects', id, `مشروع «${name}»`);
  res.status(201).json({ id, project: q.get('SELECT * FROM projects WHERE id=?', id) });
});

r.patch('/:id', requirePerm('projects.edit'), (req, res) => {
  const p = mustRow('projects', req.params.id);
  const b = req.body || {};
  const updated = patch('projects', p.id, b, FIELDS, req.user, 'projects', { name: 'الاسم', status: 'الحالة', progress: 'نسبة الإنجاز', due_date: 'الموعد النهائي' });
  // تحديث تلقائي للنسبة إن لم يحددها المستخدم
  if (b.progress === undefined && (b.status || b.name)) {
    const t = q.get(`SELECT COUNT(*) total, SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) done FROM tasks WHERE project_id=? AND deleted_at IS NULL`, p.id);
    if (t.total > 0) {
      const prog = Math.round((t.done / t.total) * 100);
      q.run('UPDATE projects SET progress=?, updated_at=? WHERE id=?', prog, nowStr(), p.id);
    }
  }
  res.json({ project: q.get('SELECT * FROM projects WHERE id=?', updated.id) });
});

r.delete('/:id', requirePerm('projects.delete'), (req, res) => {
  const row = mustRow('projects', req.params.id);
  softDelete('projects', row.id, req.user, 'projects', res, row.name);
});

module.exports = r;
