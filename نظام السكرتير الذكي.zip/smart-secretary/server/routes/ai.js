'use strict';
const { Router } = require('express');
const { auth, requirePerm } = require('../middleware/auth');
const ai = require('../services/ai');
const { S } = require('../lib');
const { httpError } = require('../middleware/errors');
const audit = require('../services/audit');

const r = Router();
r.use(auth, requirePerm('ai.use'));

r.post('/chat', (req, res) => {
  const message = S((req.body || {}).message);
  if (!message) throw httpError(400, 'اكتب سؤالك');
  if (message.length > 500) throw httpError(400, 'السؤال طويل جدًا');
  audit.log(req.user, 'ai', 'ai', null, `سؤال: ${message.slice(0, 120)}`);
  res.json(ai.chat(message));
});

r.post('/extract-tasks', (req, res) => {
  const text = S((req.body || {}).text);
  if (!text) throw httpError(400, 'أدخل النص (محضر الاجتماع)');
  res.json({ candidates: ai.extractTasks(text) });
});

r.post('/summarize', (req, res) => {
  const { scope, id } = req.body || {};
  if (!['day', 'contact', 'project'].includes(scope)) throw httpError(400, 'نوع الملخص غير معروف');
  try {
    res.json(ai.summarize(scope, id ? Number(id) : null));
  } catch (e) {
    throw httpError(404, e.message);
  }
});

module.exports = r;
