'use strict';
const { Router } = require('express');
const { q } = require('../db');
const { auth, requirePerm } = require('../middleware/auth');

const r = Router();
r.use(auth, requirePerm('dashboard.view'));

// بحث عام مجمّع حسب النوع
r.get('/', (req, res) => {
  const raw = String(req.query.q || '').trim();
  if (!raw) return res.json({ groups: [] });
  const like = `%${raw.replace(/[%_]/g, '\\$&')}%`;
  const E = "ESCAPE '\\'";
  const groups = [];
  const add = (type, label, items) => { if (items.length) groups.push({ type, label, items: items.slice(0, 5) }); };

  add('contacts', 'الأشخاص', q.all(
    `SELECT id, first_name, last_name, company, phone FROM contacts WHERE deleted_at IS NULL
     AND (first_name LIKE ? ${E} OR last_name LIKE ? ${E} OR company LIKE ? ${E} OR phone LIKE ? ${E} OR email LIKE ? ${E} OR job_title LIKE ? ${E}) LIMIT 5`,
    like, like, like, like, like, like).map((c) => ({
      id: c.id, title: [c.first_name, c.last_name].filter(Boolean).join(' '), sub: [c.job_title, c.company].filter(Boolean).join(' — '), route: `#/contacts/${c.id}`,
    })));

  add('tasks', 'المهام', q.all(
    `SELECT id, title, status, priority, due_date, project_name FROM (
       SELECT t.id, t.title, t.status, t.priority, t.due_date, p.name project_name FROM tasks t
       LEFT JOIN projects p ON p.id=t.project_id WHERE t.deleted_at IS NULL
       AND (t.title LIKE ? ${E} OR t.description LIKE ? ${E} OR t.notes LIKE ? ${E}) LIMIT 5)`,
    like, like, like).map((t) => ({
      id: t.id, title: t.title, sub: [t.due_date ? 'حتى ' + t.due_date : null, t.project_name].filter(Boolean).join(' • '), route: '#/tasks',
    })));

  add('projects', 'المشاريع', q.all(
    `SELECT id, name, client_name, progress, status FROM projects WHERE deleted_at IS NULL
     AND (name LIKE ? ${E} OR description LIKE ? ${E} OR client_name LIKE ? ${E}) LIMIT 5`, like, like, like)
    .map((p) => ({ id: p.id, title: p.name, sub: [p.client_name, `إنجاز ${p.progress}%`].filter(Boolean).join(' • '), route: `#/projects/${p.id}` })));

  add('meetings', 'الاجتماعات', q.all(
    `SELECT id, title, start_at, location, status FROM meetings WHERE deleted_at IS NULL
     AND (title LIKE ? ${E} OR subject LIKE ? ${E} OR agenda LIKE ? ${E}) ORDER BY start_at DESC LIMIT 5`, like, like, like)
    .map((m) => ({ id: m.id, title: m.title, sub: `${String(m.start_at).slice(0, 16)}${m.location ? ' • ' + m.location : ''}`, route: '#/meetings' })));

  add('followups', 'المتابعات', q.all(
    `SELECT f.id, f.subject, f.status, f.next_date, c.first_name, c.last_name FROM follow_ups f
     LEFT JOIN contacts c ON c.id=f.contact_id WHERE f.deleted_at IS NULL
     AND (f.subject LIKE ? ${E} OR f.notes LIKE ? ${E}) LIMIT 5`, like, like)
    .map((f) => ({ id: f.id, title: f.subject, sub: [[f.first_name, f.last_name].filter(Boolean).join(' '), f.next_date ? 'حتى ' + f.next_date : null].filter(Boolean).join(' • '), route: '#/followups' })));

  add('notes', 'الملاحظات', q.all(
    `SELECT id, title, type, created_at FROM notes WHERE deleted_at IS NULL
     AND (title LIKE ? ${E} OR content LIKE ? ${E}) ORDER BY created_at DESC LIMIT 5`, like, like)
    .map((n) => ({ id: n.id, title: n.title, sub: String(n.created_at).slice(0, 10), route: '#/notes' })));

  add('calls', 'الاتصالات', q.all(
    `SELECT cl.id, cl.subject, cl.called_at, cl.direction, c.first_name, c.last_name FROM calls cl
     LEFT JOIN contacts c ON c.id=cl.contact_id WHERE cl.deleted_at IS NULL
     AND (cl.subject LIKE ? ${E} OR cl.outcome LIKE ? ${E} OR cl.phone LIKE ? ${E}) ORDER BY cl.called_at DESC LIMIT 5`, like, like, like)
    .map((c) => ({ id: c.id, title: c.subject || 'اتصال', sub: [[c.first_name, c.last_name].filter(Boolean).join(' '), String(c.called_at).slice(0, 16)].filter(Boolean).join(' • '), route: '#/calls' })));

  add('files', 'الملفات', q.all(
    `SELECT id, original_name, category, created_at FROM files WHERE deleted_at IS NULL
     AND (original_name LIKE ? ${E} OR notes LIKE ? ${E}) ORDER BY created_at DESC LIMIT 5`, like, like)
    .map((f) => ({ id: f.id, title: f.original_name, sub: String(f.created_at).slice(0, 10), route: '#/files' })));

  add('expenses', 'المصروفات', q.all(
    `SELECT id, description, amount, expense_date FROM expenses WHERE deleted_at IS NULL
     AND (description LIKE ? ${E} OR notes LIKE ? ${E}) ORDER BY expense_date DESC LIMIT 5`, like, like)
    .map((x) => ({ id: x.id, title: x.description || String(x.amount), sub: `${x.amount} • ${x.expense_date}`, route: '#/expenses' })));

  add('events', 'المواعيد', q.all(
    `SELECT id, title, start_at, location FROM events WHERE deleted_at IS NULL
     AND (title LIKE ? ${E} OR description LIKE ? ${E}) ORDER BY start_at DESC LIMIT 5`, like, like)
    .map((e) => ({ id: e.id, title: e.title, sub: String(e.start_at).slice(0, 16), route: '#/calendar' })));

  res.json({ groups, total: groups.reduce((s, g) => s + g.items.length, 0) });
});

module.exports = r;
