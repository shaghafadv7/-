'use strict';
const { Router } = require('express');
const { q } = require('../db');
const { auth } = require('../middleware/auth');
const { nowStr } = require('../time');

const r = Router();
r.use(auth);

r.get('/', (req, res) => {
  const { unreadOnly, type, limit } = req.query;
  const where = ['user_id=?']; const params = [req.user.id];
  if (unreadOnly) where.push(`is_read=0`);
  if (type) { where.push(`type=?`); params.push(type); }
  const rows = q.all(`SELECT * FROM notifications WHERE ${where.join(' AND ')} ORDER BY created_at DESC LIMIT ?`, ...params, Math.min(Number(limit) || 50, 200));
  res.json({ items: rows });
});

r.get('/unread-count', (req, res) => {
  res.json({ count: q.get('SELECT COUNT(*) c FROM notifications WHERE user_id=? AND is_read=0', req.user.id).c });
});

r.post('/:id/read', (req, res) => {
  q.run('UPDATE notifications SET is_read=1 WHERE id=? AND user_id=?', req.params.id, req.user.id);
  res.json({ ok: true });
});

r.post('/read-all', (req, res) => {
  q.run('UPDATE notifications SET is_read=1 WHERE user_id=?', req.user.id);
  res.json({ ok: true });
});

r.delete('/:id', (req, res) => {
  q.run('DELETE FROM notifications WHERE id=? AND user_id=?', req.params.id, req.user.id);
  res.json({ ok: true });
});

module.exports = r;
module.exports._nowStr = nowStr;
