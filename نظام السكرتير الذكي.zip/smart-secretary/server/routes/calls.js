'use strict';
const { Router } = require('express');
const { q } = require('../db');
const { auth, requirePerm } = require('../middleware/auth');
const { S, I, N, B, patch, softDelete, mustRow, nowStr, audit } = require('../lib');
const { httpError } = require('../middleware/errors');
const notify = require('../services/notify');

const r = Router();
r.use(auth);
const FIELDS = ['contact_id', 'phone', 'direction', 'called_at', 'duration_seconds', 'subject', 'outcome', 'needs_follow_up', 'follow_up_date', 'follow_up_notes'];

function listRows(where, params, limit) {
  return q.all(
    `SELECT cl.*, c.first_name, c.last_name, c.company, c.phone AS c_phone FROM calls cl
     LEFT JOIN contacts c ON c.id=cl.contact_id
     WHERE cl.deleted_at IS NULL ${where ? 'AND ' + where : ''} ORDER BY cl.called_at DESC LIMIT ?`, ...params, limit);
}

r.get('/', requirePerm('calls.view'), (req, res) => {
  const { contact_id, direction, from, to, q: search, limit, offset } = req.query;
  const where = []; const params = [];
  if (contact_id) { where.push(`cl.contact_id=?`); params.push(I(contact_id)); }
  if (direction) { where.push(`cl.direction=?`); params.push(direction); }
  if (from) { where.push(`date(cl.called_at)>=?`); params.push(from); }
  if (to) { where.push(`date(cl.called_at)<=?`); params.push(to); }
  if (search) {
    const like = `%${String(search).replace(/[%_]/g, '\\$&')}%`;
    where.push(`(cl.subject LIKE ? ESCAPE '${String.fromCharCode(92)}' OR cl.outcome LIKE ? ESCAPE '${String.fromCharCode(92)}' OR cl.phone LIKE ? ESCAPE '${String.fromCharCode(92)}')`);
    params.push(like, like, like);
  }
  const lim = Math.min(Number(limit) || 50, 200);
  const off = Math.max(Number(offset) || 0, 0);
  const rows = q.all(
    `SELECT cl.*, c.first_name, c.last_name, c.company, c.phone AS c_phone FROM calls cl
     LEFT JOIN contacts c ON c.id=cl.contact_id
     WHERE cl.deleted_at IS NULL ${where.join(' AND ')} ORDER BY cl.called_at DESC LIMIT ? OFFSET ?`, ...params, lim, off);
  const total = q.get(`SELECT COUNT(*) c FROM calls cl WHERE cl.deleted_at IS NULL ${where.join(' AND ')}`, ...params).c;
  res.json({ items: rows, total, limit: lim, offset: off });
});

r.post('/', requirePerm('calls.create'), (req, res) => {
  const b = req.body || {};
  const calledAt = S(b.called_at) || nowStr();
  const direction = ['in', 'out', 'missed'].includes(b.direction) ? b.direction : 'out';
  q.run('INSERT INTO calls (contact_id, phone, direction, called_at, duration_seconds, subject, outcome, needs_follow_up, follow_up_date, follow_up_notes, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
    I(b.contact_id), S(b.phone), direction, calledAt, N(b.duration_seconds, 0), S(b.subject), S(b.outcome),
    B(b.needs_follow_up), S(b.follow_up_date), S(b.follow_up_notes), nowStr(), nowStr());
  const id = q.get('SELECT last_insert_rowid() id').id;
  // تسجيل "آخر تواصل" تلقائيًا على الشخص
  if (b.contact_id) q.run('UPDATE contacts SET last_contact_at=?, updated_at=? WHERE id=?', calledAt, nowStr(), I(b.contact_id));
  audit.log(req.user, 'create', 'calls', id, `تسجيل اتصال (${direction})`);
  res.status(201).json({ id, call: listRows('', [], 1)[0] });
});

r.patch('/:id', requirePerm('calls.edit'), (req, res) => {
  const row = mustRow('calls', req.params.id);
  res.json({ call: patch('calls', row.id, req.body || {}, FIELDS, req.user, 'calls', { subject: 'الموضوع', outcome: 'النتيجة', called_at: 'الوقت' }) });
});

// تحويل الاتصال إلى مهمة
r.post('/:id/to-task', requirePerm('tasks.create'), (req, res) => {
  const call = mustRow('calls', req.params.id);
  const b = req.body || {};
  const title = S(b.title) || `متابعة اتصال: ${call.subject || 'بدون موضوع'}`;
  q.run('INSERT INTO tasks (title, description, priority, status, due_date, contact_id, notes, created_by, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
    title, S(b.description) || `أُنشئت من اتصال ${String(call.called_at).slice(0, 16)}`, S(b.priority) || 'medium', 'new', S(b.due_date), call.contact_id, S(b.notes), req.user.id, nowStr(), nowStr());
  const id = q.get('SELECT last_insert_rowid() id').id;
  audit.log(req.user, 'create', 'tasks', id, `مهمة من اتصال «${title}»`);
  notify.push(req.user.id, 'task', 'تم إنشاء مهمة من اتصال', title, 'tasks', id);
  res.status(201).json({ id, task: q.get('SELECT * FROM tasks WHERE id=?', id) });
});

// تحويل الاتصال إلى تذكير
r.post('/:id/to-reminder', requirePerm('reminders.create'), (req, res) => {
  const call = mustRow('calls', req.params.id);
  const b = req.body || {};
  const remindAt = S(b.remind_at) || nowStr();
  const title = S(b.title) || `متابعة اتصال: ${call.subject || 'بدون موضوع'}`;
  q.run('INSERT INTO reminders (title, description, remind_at, status, contact_id, created_at, updated_at) VALUES (?,?,?,?,?,?,?)',
    title, S(b.description) || call.follow_up_notes, remindAt, 'pending', call.contact_id, nowStr(), nowStr());
  const id = q.get('SELECT last_insert_rowid() id').id;
  audit.log(req.user, 'create', 'reminders', id, `تذكير من اتصال «${title}»`);
  res.status(201).json({ id, reminder: q.get('SELECT * FROM reminders WHERE id=?', id) });
});

r.delete('/:id', requirePerm('calls.delete'), (req, res) => {
  const row = mustRow('calls', req.params.id);
  softDelete('calls', row.id, req.user, 'calls', res, row.subject);
});

module.exports = r;
