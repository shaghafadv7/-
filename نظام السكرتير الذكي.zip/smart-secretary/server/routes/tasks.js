'use strict';
const { Router } = require('express');
const { q } = require('../db');
const { auth, requirePerm } = require('../middleware/auth');
const { S, I, N, patch, softDelete, mustRow, STATUS_LABELS, nowStr, audit } = require('../lib');
const { httpError } = require('../middleware/errors');
const { todayStr, addDays } = require('../time');

const r = Router();
r.use(auth);

const FIELDS = ['title', 'description', 'priority', 'status', 'start_date', 'due_date', 'due_time', 'reminder_at', 'contact_id', 'project_id', 'notes', 'sort_order'];
const LABELS = { title: 'العنوان', description: 'الوصف', priority: 'الأولوية', status: 'الحالة', due_date: 'الموعد النهائي', due_time: 'الوقت', reminder_at: 'التذكير', contact_id: 'الشخص', project_id: 'المشروع', notes: 'الملاحظات' };

function validate(b) {
  const title = S(b.title);
  if (!title) throw httpError(400, 'عنوان المهمة مطلوب');
  if (b.priority && !['low', 'medium', 'high', 'urgent'].includes(b.priority)) throw httpError(400, 'أولوية غير صالحة');
  if (b.status && !Object.keys(STATUS_LABELS.task).includes(b.status)) throw httpError(400, 'حالة غير صالحة');
}

function listQuery(where, params) {
  return `SELECT t.*, c.first_name, c.last_name, c.phone AS contact_phone, c.company AS contact_company,
    p.name AS project_name, p.color AS project_color
    FROM tasks t LEFT JOIN contacts c ON c.id=t.contact_id LEFT JOIN projects p ON p.id=t.project_id
    WHERE t.deleted_at IS NULL ${where ? 'AND ' + where : ''}`;
}

r.get('/', requirePerm('tasks.view'), (req, res) => {
  const { status, priority, project_id, contact_id, q: search, due, from, to, sort, dir, limit, offset } = req.query;
  const where = []; const params = [];
  if (status) { where.push(`t.status=?`); params.push(status); }
  if (priority) { where.push(`t.priority=?`); params.push(priority); }
  if (project_id) { where.push(`t.project_id=?`); params.push(I(project_id)); }
  if (contact_id) { where.push(`t.contact_id=?`); params.push(I(contact_id)); }
  const today = todayStr();
  if (due === 'today') { where.push(`t.due_date=?`); params.push(today); }
  if (due === 'overdue') { where.push("t.due_date<? AND t.status NOT IN ('completed','cancelled')"); params.push(today); }
  if (due === 'week') { where.push("t.due_date BETWEEN ? AND ?"); params.push(today, addDays(today, 7)); }
  if (from) { where.push(`t.due_date>=?`); params.push(from); }
  if (to) { where.push(`t.due_date<=?`); params.push(to); }
  if (search) {
    const like = `%${String(search).replace(/[%_]/g, '\\$&')}%`;
    where.push(`(t.title LIKE ? ESCAPE '${String.fromCharCode(92)}' OR t.description LIKE ? ESCAPE '${String.fromCharCode(92)}' OR t.notes LIKE ? ESCAPE '${String.fromCharCode(92)}')`);
    params.push(like, like, like);
  }
  const sortMap = {
    priority: `CASE t.priority WHEN 'urgent' THEN 4 WHEN 'high' THEN 3 WHEN 'medium' THEN 2 ELSE 1 END ${dir === 'asc' ? 'ASC' : 'DESC'}`,
    due: `(t.due_date IS NULL), t.due_date ASC`,
    created: 't.created_at DESC',
  };
  const order = sortMap[sort] || sortMap.due;
  const lim = Math.min(N(limit, 100, 1, 500) || 100, 500);
  const off = Math.max(N(offset, 0) || 0, 0);
  const rows = q.all(listQuery(where.join(' AND '), params) + ` ORDER BY ${order} LIMIT ? OFFSET ?`, ...params, lim, off);
  const total = q.get(listQuery(where.join(' AND '), params).replace(/SELECT t\.\*,[\s\S]*?FROM/, 'SELECT COUNT(*) c FROM') , ...params).c;
  res.json({ items: rows, total, limit, offset });
});

r.post('/', requirePerm('tasks.create'), (req, res) => {
  const b = req.body || {};
  validate(b);
  let status = S(b.status) || 'new';
  if (!Object.keys(STATUS_LABELS.task).includes(status)) status = 'new';
  const reminderAt = S(b.reminder_at);
  q.run(
    `INSERT INTO tasks (title, description, priority, status, start_date, due_date, due_time, reminder_at, contact_id, project_id, meeting_id, notes, sort_order, completed_at, created_by, created_at, updated_at)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    S(b.title), S(b.description), S(b.priority) || 'medium', status, S(b.start_date), S(b.due_date), S(b.due_time),
    reminderAt, I(b.contact_id), I(b.project_id), I(b.meeting_id), S(b.notes), N(b.sort_order, 0),
    status === 'completed' ? nowStr() : null, req.user.id, nowStr(), nowStr()
  );
  const id = q.get('SELECT last_insert_rowid() id').id;
  audit.log(req.user, 'create', 'tasks', id, `إنشاء مهمة «${S(b.title)}»`);
  res.status(201).json({ id, task: q.get('SELECT * FROM tasks WHERE id=?', id) });
});

r.get('/:id', requirePerm('tasks.view'), (req, res) => {
  const row = mustRow('tasks', req.params.id);
  res.json({ row });
});

r.patch('/:id', requirePerm('tasks.edit'), (req, res) => {
  const b = req.body || {};
  if (b.title !== undefined) validate({ title: b.title, priority: b.priority, status: b.status });
  const before = mustRow('tasks', req.params.id);
  const row = patch('tasks', before.id, b, FIELDS, req.user, 'tasks', LABELS);
  if (b.status && b.status !== before.status) {
    q.run('UPDATE tasks SET completed_at=? WHERE id=?', b.status === 'completed' ? nowStr() : null, row.id);
    audit.log(req.user, 'status', 'tasks', row.id,
      `تغيير حالة «${row.title}» من (${STATUS_LABELS.task[before.status] || before.status}) إلى (${STATUS_LABELS.task[b.status] || b.status})`);
  }
  res.json({ task: row });
});

// تغيير سريع للحالة (سحب وإفلات)
r.post('/:id/status', requirePerm('tasks.edit'), (req, res) => {
  const status = S((req.body || {}).status);
  if (!status || !Object.keys(STATUS_LABELS.task).includes(status)) throw httpError(400, 'حالة غير صالحة');
  const before = mustRow('tasks', req.params.id);
  if (before.status === status) return res.json({ task: before });
  q.run('UPDATE tasks SET status=?, completed_at=?, updated_at=? WHERE id=?', status, status === 'completed' ? nowStr() : null, nowStr(), before.id);
  audit.log(req.user, 'status', 'tasks', before.id,
    `تغيير حالة «${before.title}» من (${STATUS_LABELS.task[before.status] || before.status}) إلى (${STATUS_LABELS.task[status] || status})`);
  res.json({ task: q.get('SELECT * FROM tasks WHERE id=?', before.id) });
});

r.delete('/:id', requirePerm('tasks.delete'), (req, res) => {
  const row = mustRow('tasks', req.params.id);
  softDelete('tasks', row.id, req.user, 'tasks', res, row.title);
});

module.exports = r;
