'use strict';
const { Router } = require('express');
const { q } = require('../db');
const { auth, requirePerm } = require('../middleware/auth');
const { S, I, patch, softDelete, mustRow, nowStr, audit } = require('../lib');
const { httpError } = require('../middleware/errors');

const r = Router();
r.use(auth);
const FIELDS = ['title', 'description', 'remind_at', 'contact_id', 'task_id', 'project_id'];

r.get('/', requirePerm('reminders.view'), (req, res) => {
  const { status, from, to, limit } = req.query;
  const where = ['r.deleted_at IS NULL']; const params = [];
  if (status) { where.push(`r.status=?`); params.push(status); }
  if (from) { where.push(`r.remind_at>=?`); params.push(from); }
  if (to) { where.push(`r.remind_at<=?`); params.push(to); }
  const rows = q.all(
    `SELECT r.*, c.first_name, c.last_name FROM reminders r LEFT JOIN contacts c ON c.id=r.contact_id
     WHERE ${where.join(' AND ')} ORDER BY r.remind_at ASC LIMIT ?`, ...params, Math.min(Number(limit) || 100, 500));
  res.json({ items: rows });
});

r.post('/', requirePerm('reminders.create'), (req, res) => {
  const b = req.body || {};
  const title = S(b.title); const remindAt = S(b.remind_at);
  if (!title) throw httpError(400, 'عنوان التذكير مطلوب');
  if (!remindAt) throw httpError(400, 'وقت التذكير مطلوب (YYYY-MM-DD HH:MM)');
  q.run('INSERT INTO reminders (title, description, remind_at, status, contact_id, task_id, project_id, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)',
    title, S(b.description), remindAt, 'pending', I(b.contact_id), I(b.task_id), I(b.project_id), nowStr(), nowStr());
  const id = q.get('SELECT last_insert_rowid() id').id;
  audit.log(req.user, 'create', 'reminders', id, `تذكير «${title}» في ${remindAt}`);
  res.status(201).json({ id, reminder: q.get('SELECT * FROM reminders WHERE id=?', id) });
});

r.patch('/:id', requirePerm('reminders.edit'), (req, res) => {
  const row = mustRow('reminders', req.params.id);
  res.json({ reminder: patch('reminders', row.id, req.body || {}, FIELDS, req.user, 'reminders', { title: 'العنوان', remind_at: 'الوقت', status: 'الحالة' }) });
});

r.post('/:id/status', requirePerm('reminders.edit'), (req, res) => {
  const status = S((req.body || {}).status);
  if (!status || !['pending', 'done', 'dismissed'].includes(status)) throw httpError(400, 'حالة غير صالحة');
  const row = mustRow('reminders', req.params.id);
  q.run('UPDATE reminders SET status=?, updated_at=? WHERE id=?', status, nowStr(), row.id);
  audit.log(req.user, 'status', 'reminders', row.id, `تذكير «${row.title}» → ${status}`);
  res.json({ reminder: q.get('SELECT * FROM reminders WHERE id=?', row.id) });
});

r.delete('/:id', requirePerm('reminders.delete'), (req, res) => {
  const row = mustRow('reminders', req.params.id);
  softDelete('reminders', row.id, req.user, 'reminders', res, row.title);
});

module.exports = r;
