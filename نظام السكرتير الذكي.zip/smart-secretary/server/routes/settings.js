'use strict';
const { Router } = require('express');
const fs = require('fs');
const path = require('path');
const multer = require('multer');
const crypto = require('crypto');
const { q, db, DATA_DIR } = require('../db');
const { auth, requirePerm } = require('../middleware/auth');
const { S } = require('../lib');
const { nowStr } = require('../time');
const { httpError } = require('../middleware/errors');
const audit = require('../services/audit');

const r = Router();
r.use(auth);
const UPLOADS = path.join(__dirname, '..', '..', 'public', 'uploads');
fs.mkdirSync(UPLOADS, { recursive: true });

const getSetting = (key, def) => {
  const row = q.get('SELECT value FROM settings WHERE key=?', key);
  return row ? JSON.parse(row.value) : def;
};
const setSetting = (key, value) => {
  q.run('INSERT INTO settings (key, value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', key, JSON.stringify(value));
};

// بيانات الشركة + النظام
r.get('/', requirePerm('settings.view'), (req, res) => {
  res.json({
    company: getSetting('company', { name: '', phone: '', email: '', address: '', logo: null }),
    system: getSetting('system', { currency: 'SAR', timezone: 'Asia/Riyadh', language: 'ar' }),
  });
});

r.put('/', requirePerm('settings.edit'), (req, res) => {
  const b = req.body || {};
  if (b.company) {
    const c = { ...getSetting('company', {}), ...b.company };
    for (const k of ['name', 'phone', 'email', 'address']) if (c[k] !== undefined) c[k] = S(c[k]);
    setSetting('company', c);
  }
  if (b.system) {
    const s = { ...getSetting('system', {}), ...b.system };
    setSetting('system', s);
  }
  audit.log(req.user, 'update', 'settings', null, 'تحديث إعدادات الشركة/النظام');
  res.json({ ok: true, company: getSetting('company', {}), system: getSetting('system', {}) });
});

// إعدادات المستخدم (ثيم، لغة، إشعارات)
r.get('/user', (req, res) => {
  const row = q.get('SELECT value FROM user_settings WHERE user_id=?', req.user.id);
  res.json({ settings: row ? JSON.parse(row.value) : { theme: 'light', primary: 'emerald', language: 'ar', notify: { tasks: true, events: true, followups: true, browser: false } } });
});

r.put('/user', (req, res) => {
  const b = req.body || {};
  const cur = (() => { const row = q.get('SELECT value FROM user_settings WHERE user_id=?', req.user.id); return row ? JSON.parse(row.value) : {}; })();
  const next = { ...cur, ...b };
  q.run('INSERT INTO user_settings (user_id, value) VALUES (?,?) ON CONFLICT(user_id) DO UPDATE SET value=excluded.value', req.user.id, JSON.stringify(next));
  res.json({ settings: next });
});

// الصورة الشخصية
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOADS),
  filename: (req, file, cb) => cb(null, `avatar-${req.user.id}-${Date.now()}-${crypto.randomBytes(4).toString('hex')}${path.extname(file.originalname).toLowerCase().slice(0, 6)}`),
});
const up = multer({ storage, limits: { fileSize: 3 * 1024 * 1024 } });
r.post('/avatar', up.single('avatar'), (req, res) => {
  if (!req.file) throw httpError(400, 'أرفق صورة');
  q.run('UPDATE users SET avatar=?, updated_at=? WHERE id=?', `/uploads/${req.file.filename}`, nowStr(), req.user.id);
  audit.log(req.user, 'update', 'users', req.user.id, 'تغيير الصورة الشخصية');
  res.json({ ok: true, avatar: `/uploads/${req.file.filename}` });
});

// ---- النسخ الاحتياطي والاستعادة ----
const TABLES = ['roles', 'permissions', 'role_permissions', 'users', 'contacts', 'projects', 'meetings', 'tasks', 'reminders', 'events', 'meeting_attendees', 'calls', 'follow_ups', 'notes', 'tags', 'note_tags', 'files', 'expenses', 'notifications', 'activity_logs', 'settings', 'user_settings'];

r.get('/backup', requirePerm('settings.edit'), (req, res) => {
  const data = {};
  for (const t of TABLES) data[t] = q.all(`SELECT * FROM ${t}`);
  const payload = { app: 'smart-secretary', version: 1, exported_at: nowStr(), data };
  res.setHeader('Content-Disposition', 'attachment; filename="smart-secretary-backup.json"');
  res.json(payload);
});

r.post('/restore', requirePerm('users.manage'), (req, res) => {
  const payload = req.body;
  if (!payload || payload.app !== 'smart-secretary' || !payload.data || typeof payload.data !== 'object') {
    throw httpError(400, 'ملف النسخة الاحتياطية غير صالح');
  }
  const insertRows = (table, rows) => {
    if (!Array.isArray(rows)) return;
    if (!rows.length) return;
    const cols = Object.keys(rows[0]);
    const stmt = db.prepare(`INSERT INTO ${table} (${cols.join(',')}) VALUES (${cols.map((c) => `@${c}`).join(',')})`);
    for (const row of rows) stmt.run(row);
  };
  // ملاحظة: توجد علاقة دائرية بين projects و contacts، لذا نعطّل FK مؤقتًا
  // (النسخة الاحتياطية متسقة بطبيعتها، والبيانات تُستبدل كلها)
  db.pragma('foreign_keys = OFF');
  try {
    db.exec('BEGIN');
    for (const t of [...TABLES].reverse()) q.run(`DELETE FROM ${t}`);
    for (const t of TABLES) insertRows(t, payload.data[t]);
    db.exec('COMMIT');
  } catch (e) {
    try { db.exec('ROLLBACK'); } catch { /* */ }
    throw httpError(500, 'فشل الاستعادة: ' + e.message);
  } finally {
    db.pragma('foreign_keys = ON');
  }
  audit.log(req.user, 'restore', 'settings', null, 'استعادة نسخة احتياطية كاملة');
  res.json({ ok: true, restored: TABLES.length });
});

// تصدير البيانات (JSON)
r.get('/export-data', requirePerm('settings.edit'), (req, res) => {
  const data = {};
  for (const t of TABLES) data[t] = q.all(`SELECT * FROM ${t}`);
  res.json({ app: 'smart-secretary', version: 1, exported_at: nowStr(), data });
});

module.exports = r;
module.exports.DATA_DIR = DATA_DIR;
