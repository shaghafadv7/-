'use strict';
const { Router } = require('express');
const { q } = require('../db');
const { auth, requirePerm } = require('../middleware/auth');
const { S, I, B, patch, softDelete, mustRow, nowStr, audit } = require('../lib');
const { httpError } = require('../middleware/errors');

const r = Router();
r.use(auth);
const FIELDS = ['title', 'content', 'type', 'contact_id', 'project_id', 'is_pinned', 'is_favorite'];

function syncTags(noteId, tags) {
  if (!Array.isArray(tags)) return;
  q.run('DELETE FROM note_tags WHERE note_id=?', noteId);
  for (const t of tags.slice(0, 20)) {
    const name = S(t);
    if (!name) continue;
    const tag = q.get('SELECT id FROM tags WHERE lower(name)=lower(?)', name) || q.run('INSERT INTO tags (name) VALUES (?)', name) && q.get('SELECT id FROM tags WHERE lower(name)=lower(?)', name);
    q.run('INSERT OR IGNORE INTO note_tags (note_id, tag_id) VALUES (?,?)', noteId, tag.id);
  }
}

function withTags(n) {
  const tags = q.all('SELECT t.name FROM note_tags nt JOIN tags t ON t.id=nt.tag_id WHERE nt.note_id=?', n.id);
  return { ...n, tags: tags.map((t) => t.name) };
}

r.get('/', requirePerm('notes.view'), (req, res) => {
  const { q: search, type, contact_id, project_id, tag, pinned, favorite, limit, offset } = req.query;
  const where = ['n.deleted_at IS NULL']; const params = [];
  if (type) { where.push(`n.type=?`); params.push(type); }
  if (contact_id) { where.push(`n.contact_id=?`); params.push(I(contact_id)); }
  if (project_id) { where.push(`n.project_id=?`); params.push(I(project_id)); }
  if (pinned) { where.push(`n.is_pinned=1`); }
  if (favorite) { where.push(`n.is_favorite=1`); }
  if (search) {
    const like = `%${String(search).replace(/[%_]/g, '\\$&')}%`;
    where.push(`(n.title LIKE ? ESCAPE '${String.fromCharCode(92)}' OR n.content LIKE ? ESCAPE '${String.fromCharCode(92)}')`); params.push(like, like);
  }
  if (tag) {
    where.push(`EXISTS (SELECT 1 FROM note_tags nt JOIN tags t ON t.id=nt.tag_id WHERE nt.note_id=n.id AND t.name=?)`);
    params.push(tag);
  }
  const lim = Math.min(Number(limit) || 60, 200);
  const off = Math.max(Number(offset) || 0, 0);
  const rows = q.all(`SELECT n.*, c.first_name, c.last_name, p.name project_name FROM notes n
    LEFT JOIN contacts c ON c.id=n.contact_id LEFT JOIN projects p ON p.id=n.project_id
    WHERE ${where.join(' AND ')} ORDER BY n.is_pinned DESC, n.created_at DESC LIMIT ? OFFSET ?`, ...params, lim, off);
  res.json({ items: rows.map(withTags) });
});

r.get('/tags', requirePerm('notes.view'), (req, res) => {
  res.json({ items: q.all('SELECT name, COUNT(*) n FROM note_tags nt JOIN tags t ON t.id=nt.tag_id GROUP BY t.name ORDER BY n DESC') });
});

r.post('/', requirePerm('notes.create'), (req, res) => {
  const b = req.body || {};
  const title = S(b.title);
  if (!title) throw httpError(400, 'عنوان الملاحظة مطلوب');
  q.run('INSERT INTO notes (title, content, type, contact_id, project_id, is_pinned, is_favorite, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)',
    title, S(b.content), S(b.type) || 'quick', I(b.contact_id), I(b.project_id), B(b.is_pinned), B(b.is_favorite), nowStr(), nowStr());
  const id = q.get('SELECT last_insert_rowid() id').id;
  syncTags(id, b.tags);
  audit.log(req.user, 'create', 'notes', id, `ملاحظة «${title}»`);
  res.status(201).json({ id, note: withTags(q.get('SELECT * FROM notes WHERE id=?', id)) });
});

r.get('/:id', requirePerm('notes.view'), (req, res) => {
  res.json({ note: withTags(mustRow('notes', req.params.id)) });
});

r.patch('/:id', requirePerm('notes.edit'), (req, res) => {
  const n = mustRow('notes', req.params.id);
  const b = req.body || {};
  const updated = patch('notes', n.id, b, FIELDS, req.user, 'notes', { title: 'العنوان', content: 'المحتوى', is_pinned: 'التثبيت', is_favorite: 'المفضلة' });
  if (Array.isArray(b.tags)) syncTags(n.id, b.tags);
  res.json({ note: withTags(q.get('SELECT * FROM notes WHERE id=?', updated.id)) });
});

r.post('/:id/toggle-pin', requirePerm('notes.edit'), (req, res) => {
  const n = mustRow('notes', req.params.id);
  q.run('UPDATE notes SET is_pinned=?, updated_at=? WHERE id=?', n.is_pinned ? 0 : 1, nowStr(), n.id);
  res.json({ note: q.get('SELECT * FROM notes WHERE id=?', n.id) });
});

r.post('/:id/toggle-fav', requirePerm('notes.edit'), (req, res) => {
  const n = mustRow('notes', req.params.id);
  q.run('UPDATE notes SET is_favorite=?, updated_at=? WHERE id=?', n.is_favorite ? 0 : 1, nowStr(), n.id);
  res.json({ note: q.get('SELECT * FROM notes WHERE id=?', n.id) });
});

r.delete('/:id', requirePerm('notes.delete'), (req, res) => {
  const row = mustRow('notes', req.params.id);
  softDelete('notes', row.id, req.user, 'notes', res, row.title);
});

module.exports = r;
