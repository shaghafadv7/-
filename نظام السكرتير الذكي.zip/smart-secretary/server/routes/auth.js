'use strict';
const { Router } = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { q } = require('../db');
const { SECRET, TOKEN_TTL } = require('../config');
const { auth, requirePerm, loadUser } = require('../middleware/auth');
const { httpError, rateLimit } = require('../middleware/errors');
const { nowStr, todayStr } = require('../time');
const { S, I } = require('../lib');
const audit = require('../services/audit');

const r = Router();

r.post('/login', rateLimit(10, 60000, (req) => req.ip), (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) throw httpError(400, 'البريد الإلكتروني وكلمة المرور مطلوبان');
  const user = q.get('SELECT * FROM users WHERE lower(email)=lower(?) AND deleted_at IS NULL', String(email).trim());
  if (!user || !user.is_active) throw httpError(401, 'البريد الإلكتروني أو كلمة المرور غير صحيحة');
  if (!bcrypt.compareSync(String(password), user.password_hash)) throw httpError(401, 'البريد الإلكتروني أو كلمة المرور غير صحيحة');
  q.run('UPDATE users SET last_login_at=?, updated_at=? WHERE id=?', nowStr(), nowStr(), user.id);
  audit.log(user, 'login', 'auth', user.id, `تسجيل دخول (${user.email})`);
  const token = jwt.sign({ id: user.id, name: user.name }, SECRET, { expiresIn: TOKEN_TTL });
  const u = loadUser(user.id);
  const us = q.get('SELECT value FROM user_settings WHERE user_id=?', user.id);
  res.json({ token, user: { ...u, settings: us ? JSON.parse(us.value) : null } });
});

r.post('/logout', auth, (req, res) => {
  audit.log(req.user, 'logout', 'auth', req.user.id, 'تسجيل خروج');
  res.json({ ok: true });
});

r.get('/me', auth, (req, res) => {
  const us = q.get('SELECT value FROM user_settings WHERE user_id=?', req.user.id);
  const company = q.get("SELECT value FROM settings WHERE key='company'");
  res.json({ user: { ...req.user, settings: us ? JSON.parse(us.value) : null }, company: company ? JSON.parse(company.value) : null });
});

r.put('/profile', auth, (req, res) => {
  const { name, phone, avatar } = req.body || {};
  const nameV = S(name);
  if (nameV && nameV.length < 2) throw httpError(400, 'الاسم قصير جدًا');
  q.run('UPDATE users SET name=COALESCE(?,name), phone=COALESCE(?,phone), avatar=COALESCE(?,avatar), updated_at=? WHERE id=?',
    nameV, S(phone), avatar === undefined ? null : S(avatar), nowStr(), req.user.id);
  audit.log(req.user, 'update', 'users', req.user.id, 'تحديث الملف الشخصي');
  res.json({ user: loadUser(req.user.id) });
});

r.put('/password', auth, (req, res) => {
  const { oldPassword, newPassword } = req.body || {};
  if (!oldPassword || !newPassword) throw httpError(400, 'كلمتا المرور مطلوبتان');
  const user = q.get('SELECT * FROM users WHERE id=?', req.user.id);
  if (!bcrypt.compareSync(String(oldPassword), user.password_hash)) throw httpError(400, 'كلمة المرور الحالية غير صحيحة');
  if (String(newPassword).length < 6) throw httpError(400, 'كلمة المرور الجديدة يجب ألا تقل عن 6 أحرف');
  q.run('UPDATE users SET password_hash=?, updated_at=? WHERE id=?', bcrypt.hashSync(String(newPassword), 10), nowStr(), req.user.id);
  audit.log(req.user, 'update', 'users', req.user.id, 'تغيير كلمة المرور');
  res.json({ ok: true });
});

module.exports = r;
module.exports._todayStr = todayStr;
