'use strict';
const { Router } = require('express');
const { q } = require('../db');
const { auth, requirePerm } = require('../middleware/auth');
const { S, I, patch, softDelete, mustRow, nowStr, audit } = require('../lib');
const { httpError } = require('../middleware/errors');

const r = Router();
r.use(auth);
const FIELDS = ['title', 'type', 'start_at', 'end_at', 'location', 'link', 'description', 'status', 'contact_id', 'project_id'];
const TYPES = ['meeting', 'appointment', 'call', 'followup', 'other'];

// جلب فترة زمنية (شهر/أسبوع/يوم/نطاق) — يُستخدم في التقويم
r.get('/range', requirePerm('calendar.view'), (req, res) => {
  const { from, to } = req.query;
  if (!from || !to) throw httpError(400, 'حدد from و to بصيغة YYYY-MM-DD');
  const events = q.all(
    `SELECT e.*, c.first_name, c.last_name FROM events e LEFT JOIN contacts c ON c.id=e.contact_id
     WHERE e.deleted_at IS NULL AND date(e.start_at) BETWEEN ? AND ? ORDER BY e.start_at`, from, to);
  const meetings = q.all(
    `SELECT m.*, p.name project_name FROM meetings m LEFT JOIN projects p ON p.id=m.project_id
     WHERE m.deleted_at IS NULL AND date(m.start_at) BETWEEN ? AND ? ORDER BY m.start_at`, from, to);
  const tasks = q.all(
    `SELECT id, title, priority, status, due_date, due_time FROM tasks
     WHERE deleted_at IS NULL AND status NOT IN ('completed','cancelled') AND due_date BETWEEN ? AND ?`, from, to);
  const reminders = q.all(
    `SELECT id, title, status, remind_at FROM reminders
     WHERE deleted_at IS NULL AND status='pending' AND date(remind_at) BETWEEN ? AND ?`, from, to);
  res.json({ events, meetings, tasks, reminders });
});

r.get('/', requirePerm('calendar.view'), (req, res) => {
  const { type, status, from, to, limit } = req.query;
  const where = ['e.deleted_at IS NULL']; const params = [];
  if (type) { where.push(`e.type=?`); params.push(type); }
  if (status) { where.push(`e.status=?`); params.push(status); }
  if (from) { where.push(`date(e.start_at)>=?`); params.push(from); }
  if (to) { where.push(`date(e.start_at)<=?`); params.push(to); }
  const rows = q.all(
    `SELECT e.*, c.first_name, c.last_name FROM events e LEFT JOIN contacts c ON c.id=e.contact_id
     WHERE ${where.join(' AND ')} ORDER BY e.start_at ASC LIMIT ?`, ...params, Math.min(Number(limit) || 200, 500));
  res.json({ items: rows });
});

r.post('/', requirePerm('calendar.create'), (req, res) => {
  const b = req.body || {};
  const title = S(b.title); const startAt = S(b.start_at);
  if (!title) throw httpError(400, 'عنوان الموعد مطلوب');
  if (!startAt) throw httpError(400, 'تاريخ ووقت الموعد مطلوبان (YYYY-MM-DD HH:MM)');
  const type = TYPES.includes(b.type) ? b.type : 'appointment';
  q.run('INSERT INTO events (title, type, start_at, end_at, location, link, description, status, contact_id, project_id, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
    title, type, startAt, S(b.end_at), S(b.location), S(b.link), S(b.description), 'scheduled', I(b.contact_id), I(b.project_id), nowStr(), nowStr());
  const id = q.get('SELECT last_insert_rowid() id').id;
  audit.log(req.user, 'create', 'events', id, `موعد «${title}» في ${startAt}`);
  res.status(201).json({ id, event: q.get('SELECT * FROM events WHERE id=?', id) });
});

r.patch('/:id', requirePerm('calendar.edit'), (req, res) => {
  const row = mustRow('events', req.params.id);
  res.json({ event: patch('events', row.id, req.body || {}, FIELDS, req.user, 'events', { title: 'العنوان', start_at: 'الوقت', status: 'الحالة', type: 'النوع' }) });
});

r.delete('/:id', requirePerm('calendar.delete'), (req, res) => {
  const row = mustRow('events', req.params.id);
  softDelete('events', row.id, req.user, 'events', res, row.title);
});

module.exports = r;
