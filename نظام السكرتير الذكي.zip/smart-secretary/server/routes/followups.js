'use strict';
const { Router } = require('express');
const { q } = require('../db');
const { auth, requirePerm } = require('../middleware/auth');
const { S, I, patch, softDelete, mustRow, nowStr, audit } = require('../lib');
const { httpError } = require('../middleware/errors');
const { todayStr, addDays } = require('../time');
const notify = require('../services/notify');

const r = Router();
r.use(auth);
const FIELDS = ['contact_id', 'project_id', 'subject', 'last_contact_at', 'next_date', 'status', 'priority', 'notes'];
const STATUS = ['waiting', 'needs', 'done', 'completed', 'postponed'];

function rowSql(where, params) {
  return `SELECT f.*, c.first_name, c.last_name, c.job_title, c.company, c.phone, c.whatsapp, c.email,
    p.name project_name FROM follow_ups f
    LEFT JOIN contacts c ON c.id=f.contact_id LEFT JOIN projects p ON p.id=f.project_id
    WHERE f.deleted_at IS NULL ${where ? 'AND ' + where : ''}`;
}

r.get('/', requirePerm('followups.view'), (req, res) => {
  const { status, due, q: search, limit, offset } = req.query;
  const where = []; const params = [];
  const today = todayStr();
  if (status) { where.push(`f.status=?`); params.push(status); }
  if (due === 'today') { where.push("f.status IN ('waiting','needs') AND f.next_date IS NOT NULL AND f.next_date <= ?"); params.push(today); }
  if (due === 'week') { where.push("f.status IN ('waiting','needs') AND f.next_date BETWEEN ? AND ?"); params.push(today, addDays(today, 7)); }
  if (due === 'overdue') { where.push("f.status IN ('waiting','needs') AND f.next_date < ?"); params.push(today); }
  if (search) {
    const like = `%${String(search).replace(/[%_]/g, '\\$&')}%`;
    where.push(`(f.subject LIKE ? ESCAPE '${String.fromCharCode(92)}' OR f.notes LIKE ? ESCAPE '${String.fromCharCode(92)}')`); params.push(like, like);
  }
  const lim = Math.min(Number(limit) || 60, 200);
  const off = Math.max(Number(offset) || 0, 0);
  const rows = q.all(rowSql(where.join(' AND '), params) + ` ORDER BY f.next_date ASC, f.id DESC LIMIT ? OFFSET ?`, ...params, lim, off);
  const total = q.get(rowSql(where.join(' AND '), params).replace(/SELECT f\.\*,[\s\S]*?FROM/, 'SELECT COUNT(*) c FROM'), ...params).c;
  res.json({ items: rows, total, limit: lim, offset: off });
});

r.post('/', requirePerm('followups.create'), (req, res) => {
  const b = req.body || {};
  const subject = S(b.subject);
  if (!subject) throw httpError(400, 'موضوع المتابعة مطلوب');
  q.run('INSERT INTO follow_ups (contact_id, project_id, subject, last_contact_at, next_date, status, priority, notes, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
    I(b.contact_id), I(b.project_id), subject, S(b.last_contact_at) || nowStr(), S(b.next_date) || todayStr(),
    STATUS.includes(b.status) ? b.status : 'waiting', S(b.priority) || 'medium', S(b.notes), nowStr(), nowStr());
  const id = q.get('SELECT last_insert_rowid() id').id;
  audit.log(req.user, 'create', 'followups', id, `متابعة «${subject}»`);
  res.status(201).json({ id, followup: q.get('SELECT * FROM follow_ups WHERE id=?', id) });
});

r.patch('/:id', requirePerm('followups.edit'), (req, res) => {
  const row = mustRow('follow_ups', req.params.id);
  res.json({ followup: patch('follow_ups', row.id, req.body || {}, FIELDS, req.user, 'followups', { subject: 'الموضوع', next_date: 'تاريخ المتابعة', status: 'الحالة', contact_id: 'الشخص' }) });
});

// "تمت المتابعة الآن" — يحدّث الحالة وآخر تواصل ويحدد الموعد القادم
r.post('/:id/done', requirePerm('followups.edit'), (req, res) => {
  const row = mustRow('follow_ups', req.params.id);
  const b = req.body || {};
  const nextInDays = Number.isFinite(Number(b.next_in_days)) ? Number(b.next_in_days) : 7;
  q.run('UPDATE follow_ups SET status=?, last_contact_at=?, next_date=?, updated_at=? WHERE id=?',
    'done', nowStr(), addDays(todayStr(), nextInDays), nowStr(), row.id);
  if (row.contact_id) q.run('UPDATE contacts SET last_contact_at=?, next_follow_up_at=?, updated_at=? WHERE id=?', nowStr(), addDays(todayStr(), nextInDays), nowStr(), row.contact_id);
  audit.log(req.user, 'status', 'followups', row.id, `«${row.subject}» — تمت المتابعة (التالي بعد ${nextInDays} أيام)`);
  notify.push(req.user.id, 'followup', 'تم إنجاز متابعة', row.subject, 'followups', row.id);
  res.json({ followup: q.get('SELECT * FROM follow_ups WHERE id=?', row.id) });
});

r.delete('/:id', requirePerm('followups.delete'), (req, res) => {
  const row = mustRow('follow_ups', req.params.id);
  softDelete('follow_ups', row.id, req.user, 'followups', res, row.subject);
});

module.exports = r;
