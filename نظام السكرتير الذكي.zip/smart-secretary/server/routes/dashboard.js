'use strict';
const { Router } = require('express');
const { q } = require('../db');
const { auth } = require('../middleware/auth');
const { todayStr, addDays } = require('../time');

const r = Router();
r.use(auth);

// Timeline يوم محدد: أحداث + اجتماعات + مهام + تذكيرات + اتصالات
function dayTimeline(date) {
  const items = [];
  for (const e of q.all("SELECT * FROM events WHERE deleted_at IS NULL AND date(start_at)=? AND status!='cancelled' ORDER BY start_at", date)) {
    items.push({ kind: 'event', id: e.id, title: e.title, time: (e.start_at || '').slice(11, 16) || '09:00', sub: [e.location, e.type === 'call' ? 'اتصال' : null].filter(Boolean).join(' • '), status: e.status, route: '#/calendar' });
  }
  for (const m of q.all("SELECT * FROM meetings WHERE deleted_at IS NULL AND date(start_at)=? AND status!='cancelled' ORDER BY start_at", date)) {
    const att = q.get('SELECT COUNT(*) c FROM meeting_attendees WHERE meeting_id=?', m.id).c;
    items.push({ kind: 'meeting', id: m.id, title: m.title, time: (m.start_at || '').slice(11, 16) || '09:00', sub: [att ? `${att} حضار` : null, m.location, m.link ? 'رابط' : null].filter(Boolean).join(' • '), status: m.status, route: '#/meetings' });
  }
  for (const t of q.all("SELECT t.*, c.first_name, c.last_name FROM tasks t LEFT JOIN contacts c ON c.id=t.contact_id WHERE t.deleted_at IS NULL AND t.due_date=? AND t.status NOT IN ('cancelled') ORDER BY t.due_time", date)) {
    items.push({ kind: 'task', id: t.id, title: t.title, time: t.due_time || '00:00', sub: `مهمة • ${t.status === 'completed' ? 'مكتملة' : t.priority}${t.first_name ? ' • ' + t.first_name : ''}`, status: t.status, route: '#/tasks' });
  }
  for (const rm of q.all("SELECT * FROM reminders WHERE deleted_at IS NULL AND date(remind_at)=? ORDER BY remind_at", date)) {
    items.push({ kind: 'reminder', id: rm.id, title: rm.title, time: (rm.remind_at || '').slice(11, 16) || '00:00', sub: 'تذكير', status: rm.status, route: '#/today' });
  }
  for (const c of q.all("SELECT cl.*, c.first_name FROM calls cl LEFT JOIN contacts c ON c.id=cl.contact_id WHERE cl.deleted_at IS NULL AND date(cl.called_at)=? ORDER BY cl.called_at", date)) {
    items.push({ kind: 'call', id: c.id, title: c.subject || `اتصال${c.first_name ? ' مع ' + c.first_name : ''}`, time: (c.called_at || '').slice(11, 16) || '00:00', sub: c.direction === 'in' ? 'وارد' : c.direction === 'out' ? 'صادر' : 'فائت', status: 'logged', route: '#/calls' });
  }
  return items.sort((a, b) => a.time.localeCompare(b.time));
}

// ملخص Dashboard — كل الأرقام والأقسام
r.get('/summary', (req, res) => {
  const today = todayStr();
  const in7 = addDays(today, 7);
  const stats = {
    todayTasks: q.get(`SELECT COUNT(*) c FROM tasks WHERE deleted_at IS NULL AND due_date=? AND status NOT IN ('completed','cancelled')`, today).c,
    overdueTasks: q.get(`SELECT COUNT(*) c FROM tasks WHERE deleted_at IS NULL AND due_date<? AND status NOT IN ('completed','cancelled')`, today).c,
    todayEvents: q.get("SELECT COUNT(*) c FROM events WHERE deleted_at IS NULL AND date(start_at)=? AND status!='cancelled'", today).c
      + q.get("SELECT COUNT(*) c FROM meetings WHERE deleted_at IS NULL AND date(start_at)=? AND status='scheduled'", today).c,
    upcomingMeetings: q.get("SELECT COUNT(*) c FROM meetings WHERE deleted_at IS NULL AND status='scheduled' AND date(start_at) BETWEEN ? AND ?", today, in7).c,
    dueFollowups: q.get(`SELECT COUNT(*) c FROM follow_ups WHERE deleted_at IS NULL AND status IN ('waiting','needs') AND next_date IS NOT NULL AND next_date <= ?`, today).c,
    pendingReplies: q.get(`SELECT COUNT(*) c FROM follow_ups WHERE deleted_at IS NULL AND status='waiting'`).c
      + q.get(`SELECT COUNT(*) c FROM tasks WHERE deleted_at IS NULL AND status='waiting'`).c,
    newFiles: q.get(`SELECT COUNT(*) c FROM files WHERE deleted_at IS NULL AND date(created_at) >= ?`, addDays(today, -7)).c,
    completedToday: q.get(`SELECT COUNT(*) c FROM tasks WHERE deleted_at IS NULL AND status='completed' AND date(completed_at)=?`, today).c,
    expensesToday: q.get(`SELECT COALESCE(SUM(amount),0) t FROM expenses WHERE deleted_at IS NULL AND expense_date=?`, today).t,
  };
  const sections = {
    todayTimeline: dayTimeline(today),
    urgentTasks: q.all(
      `SELECT t.*, c.first_name, c.last_name, p.name project_name FROM tasks t
       LEFT JOIN contacts c ON c.id=t.contact_id LEFT JOIN projects p ON p.id=t.project_id
       WHERE t.deleted_at IS NULL AND t.status NOT IN ('completed','cancelled')
         AND (t.priority='urgent' OR t.due_date IS NOT NULL AND t.due_date < ?)
       ORDER BY t.due_date ASC LIMIT 6`, today),
    dueFollowups: q.all(
      `SELECT f.*, c.first_name, c.last_name, c.phone, c.whatsapp FROM follow_ups f
       LEFT JOIN contacts c ON c.id=f.contact_id
       WHERE f.deleted_at IS NULL AND f.status IN ('waiting','needs') AND f.next_date IS NOT NULL AND f.next_date <= ?
       ORDER BY f.next_date ASC LIMIT 6`, today),
    upcomingEvents: (() => {
      const ev = q.all(`SELECT 'event' kind, id, title, start_at, location FROM events WHERE deleted_at IS NULL AND status!='cancelled' AND date(start_at) BETWEEN ? AND ? ORDER BY start_at`, today, in7);
      const mt = q.all(`SELECT 'meeting' kind, id, title, start_at, location FROM meetings WHERE deleted_at IS NULL AND status='scheduled' AND date(start_at) BETWEEN ? AND ? ORDER BY start_at`, today, in7);
      return [...ev, ...mt].sort((a, b) => String(a.start_at).localeCompare(String(b.start_at))).slice(0, 6);
    })(),
    recentCalls: q.all(
      `SELECT cl.*, c.first_name, c.last_name FROM calls cl LEFT JOIN contacts c ON c.id=cl.contact_id
       WHERE cl.deleted_at IS NULL ORDER BY cl.called_at DESC LIMIT 5`),
    recentActivity: q.all(
      `SELECT a.*, u.name user_name FROM activity_logs a LEFT JOIN users u ON u.id=a.user_id
       WHERE a.entity NOT IN ('auth') ORDER BY a.created_at DESC LIMIT 8`),
    pendingReminders: q.all(
      `SELECT r.*, c.first_name FROM reminders r LEFT JOIN contacts c ON c.id=r.contact_id
       WHERE r.deleted_at IS NULL AND r.status='pending' AND r.remind_at >= ? ORDER BY r.remind_at LIMIT 5`, today + ' 00:00:00'),
  };
  res.json({ today, stats, sections });
});

// قسم "يومي"
r.get('/today', (req, res) => {
  const date = String(req.query.date || todayStr()).slice(0, 10);
  res.json({ date, items: dayTimeline(date) });
});

// مركز العمل — "صندوق عمل السكرتير"
r.get('/workcenter', (req, res) => {
  const today = todayStr();
  const in7 = addDays(today, 7);
  const join = 'LEFT JOIN contacts c ON c.id=?.contact_id LEFT JOIN projects p ON p.id=?.project_id';
  res.json({
    urgent: q.all(
      `SELECT t.*, c.first_name, c.last_name, p.name project_name FROM tasks t
       LEFT JOIN contacts c ON c.id=t.contact_id LEFT JOIN projects p ON p.id=t.project_id
       WHERE t.deleted_at IS NULL AND t.status NOT IN ('completed','cancelled')
         AND (t.priority='urgent' OR (t.due_date IS NOT NULL AND t.due_date < ?))
       ORDER BY t.due_date ASC LIMIT 20`, today),
    today: q.all(
      `SELECT t.*, c.first_name, c.last_name, p.name project_name FROM tasks t
       LEFT JOIN contacts c ON c.id=t.contact_id LEFT JOIN projects p ON p.id=t.project_id
       WHERE t.deleted_at IS NULL AND t.due_date=? AND t.status NOT IN ('completed','cancelled')
       ORDER BY t.due_time ASC LIMIT 20`, today),
    waiting: {
      followups: q.all(`SELECT f.*, c.first_name, c.last_name, c.phone FROM follow_ups f LEFT JOIN contacts c ON c.id=f.contact_id
        WHERE f.deleted_at IS NULL AND f.status='waiting' ORDER BY f.next_date ASC LIMIT 20`),
      tasks: q.all(`SELECT t.*, c.first_name, c.last_name FROM tasks t LEFT JOIN contacts c ON c.id=t.contact_id
        WHERE t.deleted_at IS NULL AND t.status='waiting' ORDER BY t.due_date ASC LIMIT 20`),
    },
    followups: q.all(`SELECT f.*, c.first_name, c.last_name, c.phone, c.whatsapp, c.email FROM follow_ups f
      LEFT JOIN contacts c ON c.id=f.contact_id
      WHERE f.deleted_at IS NULL AND f.status IN ('waiting','needs') AND f.next_date IS NOT NULL AND f.next_date <= ?
      ORDER BY f.next_date ASC LIMIT 20`, today),
    upcoming: (() => {
      const ev = q.all(`SELECT 'event' kind, id, title, start_at, location, type FROM events WHERE deleted_at IS NULL AND status!='cancelled' AND date(start_at) BETWEEN ? AND ? ORDER BY start_at LIMIT 15`, today, in7);
      const mt = q.all(`SELECT 'meeting' kind, id, title, start_at, location, '' type FROM meetings WHERE deleted_at IS NULL AND status='scheduled' AND date(start_at) BETWEEN ? AND ? ORDER BY start_at LIMIT 15`, today, in7);
      return [...ev, ...mt].sort((a, b) => String(a.start_at).localeCompare(String(b.start_at)));
    })(),
    postponed: q.all(`SELECT f.*, c.first_name, c.last_name FROM follow_ups f LEFT JOIN contacts c ON c.id=f.contact_id
      WHERE f.deleted_at IS NULL AND f.status='postponed' ORDER BY f.next_date ASC LIMIT 20`),
  });
});

module.exports = r;
