'use strict';
const { Router } = require('express');
const { q } = require('../db');
const { auth, requirePerm } = require('../middleware/auth');
const { S, I, patch, softDelete, mustRow, nowStr, audit } = require('../lib');
const { httpError } = require('../middleware/errors');

const r = Router();
r.use(auth);
const FIELDS = ['title', 'start_at', 'end_at', 'location', 'link', 'subject', 'agenda', 'minutes', 'decisions', 'status', 'project_id'];

function withAttendees(m) {
  const attendees = q.all(
    `SELECT c.id, c.first_name, c.last_name, c.job_title, c.company FROM meeting_attendees ma
     JOIN contacts c ON c.id=ma.contact_id WHERE ma.meeting_id=? AND c.deleted_at IS NULL`, m.id);
  return { ...m, attendees };
}

r.get('/', requirePerm('meetings.view'), (req, res) => {
  const { from, to, status, project_id, limit } = req.query;
  const where = ['m.deleted_at IS NULL']; const params = [];
  if (from) { where.push(`date(m.start_at)>=?`); params.push(from); }
  if (to) { where.push(`date(m.start_at)<=?`); params.push(to); }
  if (status) { where.push(`m.status=?`); params.push(status); }
  if (project_id) { where.push(`m.project_id=?`); params.push(I(project_id)); }
  const rows = q.all(
    `SELECT m.*, p.name project_name FROM meetings m LEFT JOIN projects p ON p.id=m.project_id
     WHERE ${where.join(' AND ')} ORDER BY m.start_at DESC LIMIT ?`, ...params, Math.min(Number(limit) || 100, 300));
  res.json({ items: rows.map(withAttendees) });
});

r.get('/:id', requirePerm('meetings.view'), (req, res) => {
  const m = mustRow('meetings', req.params.id);
  const tasks = q.all('SELECT id, title, priority, status, due_date FROM tasks WHERE meeting_id=? AND deleted_at IS NULL ORDER BY created_at', m.id);
  res.json({ meeting: withAttendees(m), tasks });
});

function setAttendees(meetingId, contactIds) {
  q.run('DELETE FROM meeting_attendees WHERE meeting_id=?', meetingId);
  for (const cid of contactIds || []) {
    if (Number.isInteger(cid)) q.run('INSERT OR IGNORE INTO meeting_attendees (meeting_id, contact_id) VALUES (?,?)', meetingId, cid);
  }
}

r.post('/', requirePerm('meetings.create'), (req, res) => {
  const b = req.body || {};
  const title = S(b.title); const startAt = S(b.start_at);
  if (!title) throw httpError(400, 'عنوان الاجتماع مطلوب');
  if (!startAt) throw httpError(400, 'تاريخ ووقت الاجتماع مطلوبان (YYYY-MM-DD HH:MM)');
  q.run('INSERT INTO meetings (title, start_at, end_at, location, link, subject, agenda, minutes, decisions, status, project_id, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',
    title, startAt, S(b.end_at), S(b.location), S(b.link), S(b.subject), S(b.agenda), S(b.minutes), S(b.decisions), 'scheduled', I(b.project_id), nowStr(), nowStr());
  const id = q.get('SELECT last_insert_rowid() id').id;
  setAttendees(id, (b.attendees || []).map(Number).filter(Number.isInteger));
  audit.log(req.user, 'create', 'meetings', id, `اجتماع «${title}» في ${startAt}`);
  res.status(201).json({ id, meeting: withAttendees(q.get('SELECT * FROM meetings WHERE id=?', id)) });
});

r.patch('/:id', requirePerm('meetings.edit'), (req, res) => {
  const m = mustRow('meetings', req.params.id);
  const b = req.body || {};
  if (b.agenda !== undefined || b.minutes !== undefined || b.decisions !== undefined) {
    audit.log(req.user, 'minutes', 'meetings', m.id, `تحديث محضر/جدول أعمال اجتماع «${m.title}»`);
  }
  const updated = patch('meetings', m.id, b, FIELDS, req.user, 'meetings', { title: 'العنوان', start_at: 'الوقت', status: 'الحالة' });
  if (Array.isArray(b.attendees)) setAttendees(m.id, b.attendees.map(Number).filter(Number.isInteger));
  res.json({ meeting: withAttendees(q.get('SELECT * FROM meetings WHERE id=?', updated.id)) });
});

// إضافة حضور
r.post('/:id/attend', requirePerm('meetings.edit'), (req, res) => {
  const m = mustRow('meetings', req.params.id);
  const cid = I((req.body || {}).contact_id);
  if (!cid) throw httpError(400, 'حدد الشخص');
  q.run('INSERT OR IGNORE INTO meeting_attendees (meeting_id, contact_id) VALUES (?,?)', m.id, cid);
  res.json({ ok: true, meeting: withAttendees(q.get('SELECT * FROM meetings WHERE id=?', m.id)) });
});

// إنشاء مهام من محضر الاجتماع
r.post('/:id/tasks', requirePerm('tasks.create'), (req, res) => {
  const m = mustRow('meetings', req.params.id);
  const list = Array.isArray((req.body || {}).tasks) ? req.body.tasks : [];
  if (!list.length) throw httpError(400, 'لا توجد مهام للإنشاء');
  const created = [];
  for (const t of list.slice(0, 30)) {
    const title = S(t.title || t.text);
    if (!title) continue;
    q.run('INSERT INTO tasks (title, description, priority, status, due_date, contact_id, project_id, meeting_id, notes, created_by, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
      title, 'مهمة ناتجة عن اجتماع: ' + m.title, S(t.priority) || 'medium', 'new', S(t.due_date), I(t.contact_id), m.project_id, m.id, S(t.notes), req.user.id, nowStr(), nowStr());
    created.push(q.get('SELECT * FROM tasks WHERE id=last_insert_rowid()'));
  }
  if (created.length) audit.log(req.user, 'create', 'tasks', created[0].id, `إنشاء ${created.length} مهمة من اجتماع «${m.title}»`);
  res.status(201).json({ tasks: created });
});

r.delete('/:id', requirePerm('meetings.delete'), (req, res) => {
  const row = mustRow('meetings', req.params.id);
  softDelete('meetings', row.id, req.user, 'meetings', res, row.title);
});

module.exports = r;
