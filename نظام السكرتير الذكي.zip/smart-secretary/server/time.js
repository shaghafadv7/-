'use strict';
// أدوات وقت — النظام يخزّن التواريخ بنمط "YYYY-MM-DD HH:MM:SS" بتوقيت منطقة الرياض المحلية
// (حسابات "اليوم" تعمل نصيًا، بلا تعقيدات UTC)
const TZ = process.env.TZ_NAME || 'Asia/Riyadh';

function parts(d = new Date()) {
  const p = new Intl.DateTimeFormat('en-CA', {
    timeZone: TZ,
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit',
    hour12: false,
  }).formatToParts(d);
  const g = (t) => p.find((x) => x.type === t).value;
  const hour = g('hour') === '24' ? '00' : g('hour');
  return { date: `${g('year')}-${g('month')}-${g('day')}`, time: `${hour}:${g('minute')}:${g('second')}` };
}

function nowStr(d) { const p = parts(d); return `${p.date} ${p.time}`; }
function todayStr(d) { return parts(d).date; }
function nowTimeStr(d) { return parts(d).time; }

function addDays(dateStr, n) {
  const d = new Date(`${dateStr}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

// بداية/نهاية النطاق: week | month | quarter | year
function rangeDates(range, baseDate = todayStr()) {
  const d = new Date(`${baseDate}T00:00:00Z`);
  let from;
  if (range === 'week') {
    const wd = (d.getUTCDay() + 6) % 7; // الأسبوع يبدأ الأحد
    d.setUTCDate(d.getUTCDate() - wd);
    from = d.toISOString().slice(0, 10);
    return { from, to: addDays(from, 6) };
  }
  if (range === 'month') {
    const y = parseInt(baseDate.slice(0, 4), 10);
    const m = parseInt(baseDate.slice(5, 7), 10);
    const nextMonth = m === 12 ? `${y + 1}-01-01` : `${y}-${String(m + 1).padStart(2, '0')}-01`;
    return { from: baseDate.slice(0, 8) + '01', to: addDays(nextMonth, -1) };
  }
  if (range === 'quarter') {
    const m = Math.floor((parseInt(baseDate.slice(5, 7), 10) - 1) / 3) * 3 + 1;
    from = `${baseDate.slice(0, 4)}-${String(m).padStart(2, '0')}-01`;
    return { from, to: addDays(from, 92) };
  }
  from = `${baseDate.slice(0, 4)}-01-01`;
  return { from, to: `${baseDate.slice(0, 4)}-12-31` };
}

function dayLabelAr(dateStr) {
  try {
    const d = new Date(`${dateStr}T12:00:00Z`);
    const wd = new Intl.DateTimeFormat('ar', { timeZone: TZ, weekday: 'long' }).format(d);
    const md = new Intl.DateTimeFormat('ar', { timeZone: TZ, day: 'numeric', month: 'long' }).format(d);
    return `${wd}، ${md}`;
  } catch { return dateStr; }
}

module.exports = { nowStr, todayStr, nowTimeStr, addDays, rangeDates, dayLabelAr, TZ };
