'use strict';
// الإشعارات + الجدولة (Scheduler)
const { q } = require('../db');
const { nowStr, todayStr } = require('../time');

function push(userId, type, title, body, entity, entityId) {
  q.run(
    'INSERT INTO notifications (user_id, type, title, body, entity, entity_id, is_read, created_at) VALUES (?,?,?,?,?,?,0,?)',
    userId, type, title, body || '', entity || null, entityId || null, nowStr()
  );
}

function pushAll(type, title, body, entity, entityId) {
  const users = q.all('SELECT id FROM users WHERE is_active=1 AND deleted_at IS NULL');
  for (const u of users) push(u.id, type, title, body, entity, entityId);
}

// منع تكرار إشعار معيّن (flag لمدة غير محدودة)
function flag(key) {
  const row = q.get('SELECT 1 x FROM notify_flags WHERE flag_key=?', key);
  if (row) return false;
  q.run('INSERT OR IGNORE INTO notify_flags (flag_key, at) VALUES (?,?)', key, nowStr());
  return true;
}

function minuteDiff(a, b) {
  const [h1, m1] = a.split(':').map(Number);
  const [h2, m2] = b.split(':').map(Number);
  return (h2 * 60 + m2) - (h1 * 60 + m1);
}

// الفحص الدوري: تذكيرات، تذكيرات مهام، اجتماعات قريبة، ملخص متابعات يومي
function tick() {
  try {
    const now = nowStr();
    const today = todayStr();

    // 1) تذكيرات مستحقة
    const dueRem = q.all("SELECT * FROM reminders WHERE status='pending' AND remind_at <= ? AND deleted_at IS NULL", now);
    for (const r of dueRem) {
      pushAll('reminder', r.title, r.description || 'تذكير', 'reminders', r.id);
      q.run('UPDATE reminders SET status=?, updated_at=? WHERE id=?', 'fired', now, r.id);
    }

    // 2) تذكيرات مدمجة مع مهام
    const remTasks = q.all(
      "SELECT * FROM tasks WHERE reminder_at IS NOT NULL AND reminder_at <= ? AND status NOT IN ('completed','cancelled') AND deleted_at IS NULL",
      now
    );
    for (const t of remTasks) {
      if (flag(`task-rem-${t.id}`)) {
        pushAll('task', `تذكير: ${t.title}`, t.due_date ? `الموعد النهائي ${t.due_date}` : '', 'tasks', t.id);
      }
    }

    // 3) اجتماعات اليوم خلال الساعة القادمة
    const todaysMeetings = q.all("SELECT * FROM meetings WHERE date(start_at)=? AND status='scheduled' AND deleted_at IS NULL", today);
    const nowHM = now.slice(11, 16);
    for (const m of todaysMeetings) {
      const startHM = (m.start_at || '').slice(11, 16);
      if (!startHM) continue;
      const diff = minuteDiff(nowHM, startHM);
      if (diff >= 0 && diff <= 60 && flag(`mtg-${m.id}-${today}`)) {
        pushAll('meeting', `اجتماع بعد ${diff} دقيقة: ${m.title}`, m.location || m.link || '', 'meetings', m.id);
      }
    }

    // 4) ملخص يومي للمتابعات المستحقة
    if (flag(`follow-digest-${today}`)) {
      const { c } = q.get(
        "SELECT COUNT(*) c FROM follow_ups WHERE deleted_at IS NULL AND status IN ('waiting','needs') AND next_date IS NOT NULL AND next_date <= ?",
        today
      );
      if (c > 0) pushAll('followup', `${c} متابعة مستحقة اليوم`, 'راجع قسم المتابعات للبدء', 'followups', null);
    }
  } catch (e) {
    console.error('[scheduler] tick error:', e.message);
  }
}

module.exports = { push, pushAll, flag, tick };
