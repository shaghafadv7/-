'use strict';
// AI Secretary — مساعد محلي (Rule-based) يعمل بدون مفاتيح خارجية.
// التوقيع جاهز للتبديل إلى LLM حقيقي لاحقًا: chat({message}), extractTasks({text}), summarize({scope,id})
const { q } = require('../db');
const { todayStr, addDays } = require('../time');

function norm(s) {
  return String(s || '')
    .replace(/[\u064B-\u0652\u0640]/g, '')
    .replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي').replace(/ؤ/g, 'و').replace(/ئ/g, 'ي')
    .toLowerCase().trim();
}

const cName = (c) => (c ? [c.first_name, c.last_name].filter(Boolean).join(' ') || 'غير معروف' : 'غير مرتبط');
const dOnly = (s) => (s ? String(s).slice(0, 10) : null);
const hm = (s) => (s ? String(s).slice(11, 16) : '');

function dueFollowups(limit = 10) {
  const today = todayStr();
  return q.all(
    `SELECT f.*, c.first_name, c.last_name, c.phone FROM follow_ups f
     LEFT JOIN contacts c ON c.id=f.contact_id
     WHERE f.deleted_at IS NULL AND f.status IN ('waiting','needs') AND f.next_date IS NOT NULL AND f.next_date <= ?
     ORDER BY f.next_date ASC, f.id DESC LIMIT ?`, today, limit
  );
}

function urgentTasks(limit = 10) {
  const today = todayStr();
  return q.all(
    `SELECT t.*, c.first_name, c.last_name, p.name project_name FROM tasks t
     LEFT JOIN contacts c ON c.id=t.contact_id LEFT JOIN projects p ON p.id=t.project_id
     WHERE t.deleted_at IS NULL AND t.status NOT IN ('completed','cancelled')
       AND (t.priority='urgent' OR t.due_date IS NOT NULL AND t.due_date < ?)
     ORDER BY CASE WHEN t.due_date < ? THEN 0 ELSE 1 END, t.due_date ASC LIMIT ?`,
    today, today, limit
  );
}

function upcomingEvents(days = 7, limit = 12) {
  const now = todayStr();
  const to = addDays(now, days);
  const ev = q.all(
    `SELECT 'event' AS kind, id, title, start_at, end_at, location, link, description, status, contact_id, type
     FROM events WHERE deleted_at IS NULL AND status != 'cancelled' AND date(start_at) BETWEEN ? AND ? ORDER BY start_at`, now, to);
  const mt = q.all(
    `SELECT 'meeting' AS kind, id, title, start_at, end_at, location, link, subject AS description, status, project_id
     FROM meetings WHERE deleted_at IS NULL AND status='scheduled' AND date(start_at) BETWEEN ? AND ? ORDER BY start_at`, now, to);
  return [...ev, ...mt].sort((a, b) => String(a.start_at).localeCompare(String(b.start_at))).slice(0, limit);
}

function waitingReplies(limit = 10) {
  const f = q.all(
    `SELECT f.*, c.first_name, c.last_name FROM follow_ups f LEFT JOIN contacts c ON c.id=f.contact_id
     WHERE f.deleted_at IS NULL AND f.status='waiting' ORDER BY f.next_date ASC LIMIT ?`, limit);
  const t = q.all(
    `SELECT t.id, t.title, c.first_name, c.last_name, t.due_date FROM tasks t LEFT JOIN contacts c ON c.id=t.contact_id
     WHERE t.deleted_at IS NULL AND t.status='waiting' LIMIT ?`, limit);
  return { followups: f, tasks: t };
}

function pendingReminders(limit = 8) {
  return q.all(
    `SELECT r.*, c.first_name, c.last_name FROM reminders r LEFT JOIN contacts c ON c.id=r.contact_id
     WHERE r.deleted_at IS NULL AND r.status='pending' AND r.remind_at >= ? ORDER BY r.remind_at LIMIT ?`,
    todayStr() + ' 00:00:00', limit
  );
}

function monthExpenses() {
  const today = todayStr();
  const from = today.slice(0, 8) + '01';
  const rows = q.all(
    `SELECT category, COUNT(*) n, SUM(amount) total FROM expenses
     WHERE deleted_at IS NULL AND expense_date BETWEEN ? AND ? GROUP BY category ORDER BY total DESC`, from, today
  );
  const total = q.get(`SELECT COALESCE(SUM(amount),0) t, COUNT(*) n FROM expenses WHERE deleted_at IS NULL AND expense_date BETWEEN ? AND ?`, from, today);
  return { total: total.t, count: total.n, byCategory: rows };
}

function last7Productivity() {
  const today = todayStr();
  const out = [];
  for (let i = 6; i >= 0; i--) {
    const d = addDays(today, -i);
    const done = q.get(`SELECT COUNT(*) c FROM tasks WHERE deleted_at IS NULL AND status='completed' AND date(completed_at)=?`, d).c;
    const created = q.get(`SELECT COUNT(*) c FROM tasks WHERE deleted_at IS NULL AND date(created_at)=?`, d).c;
    out.push({ date: d, done, created });
  }
  return out;
}

function matchContact(msg) {
  const n = norm(msg);
  const contacts = q.all('SELECT * FROM contacts WHERE deleted_at IS NULL LIMIT 500');
  for (const c of contacts) {
    const full = norm([c.first_name, c.last_name].join(' '));
    if (full && n.includes(full)) return c;
  }
  return null;
}

function contactSummary(c) {
  const openTasks = q.get(`SELECT COUNT(*) c FROM tasks WHERE contact_id=? AND deleted_at IS NULL AND status NOT IN ('completed','cancelled')`, c.id).c;
  const fups = q.get(`SELECT COUNT(*) c FROM follow_ups WHERE contact_id=? AND deleted_at IS NULL AND status IN ('waiting','needs')`, c.id).c;
  const calls = q.all(`SELECT * FROM calls WHERE contact_id=? AND deleted_at IS NULL ORDER BY called_at DESC LIMIT 3`, c.id);
  const lastCall = calls[0];
  const lines = [
    `ملخص التواصل مع ${cName(c)}${c.job_title ? ` (${c.job_title})` : ''}${c.company ? ` — ${c.company}` : ''}:`,
    `• آخر تواصل: ${c.last_contact_at ? String(c.last_contact_at).slice(0, 10) : 'غير مسجل'}`,
    `• مهام مفتوحة: ${openTasks} | متابعات مستحقة: ${fups}`,
    lastCall ? `• آخر اتصال: ${String(lastCall.called_at).slice(0, 16).replace('T', ' ')} — ${lastCall.subject || 'بدون موضوع'} (${lastCall.outcome || 'بدون نتيجة'})` : '• لا توجد اتصالات مسجلة',
  ];
  if (c.next_follow_up_at) lines.push(`• موعد المتابعة القادمة: ${String(c.next_follow_up_at).slice(0, 10)}`);
  return lines.join('\n');
}

function contactTimeline(c) {
  const items = [];
  const today = todayStr();
  const f = q.all(`SELECT f.* FROM follow_ups f WHERE f.contact_id=? AND f.deleted_at IS NULL AND f.status IN ('waiting','needs') AND f.next_date <= ? ORDER BY f.next_date`, c.id, today);
  for (const x of f) items.push({ title: `متابعة: ${x.subject}`, sub: `الموعد ${dOnly(x.next_date)} (${x.status === 'waiting' ? 'بانتظار الرد' : 'يحتاج متابعة'})`, route: '#/followups' });
  const t = q.all(`SELECT t.* FROM tasks t WHERE t.contact_id=? AND t.deleted_at IS NULL AND t.status NOT IN ('completed','cancelled') ORDER BY t.due_date LIMIT 5`, c.id);
  for (const x of t) items.push({ title: x.title, sub: `مهمة ${x.due_date ? 'حتى ' + x.due_date : ''} — ${x.priority}`, route: '#/tasks' });
  const k = waitingReplies(50).followups.filter((x) => x.id !== undefined && q.get('SELECT 1 x FROM follow_ups WHERE id=? AND contact_id=?', x.id, c.id));
  for (const x of k) items.push({ title: `ينتظر رد: ${x.subject}`, sub: x.last_contact_at ? `آخر تواصل ${dOnly(x.last_contact_at)}` : '', route: '#/followups' });
  return items;
}

function buildDaily() {
  const today = todayStr();
  const fups = dueFollowups(8);
  const utasks = urgentTasks(8);
  const events = upcomingEvents(1, 6);
  const wait = waitingReplies(8);
  const rem = pendingReminders(5);
  const sections = [];
  if (fups.length) sections.push({ title: 'متابعات مستحقة اليوم', icon: 'target', route: '#/followups', items: fups.map((x) => ({ title: x.subject, sub: `${cName({ first_name: x.first_name, last_name: x.last_name })} — ${dOnly(x.next_date)}`, route: '#/followups' })) });
  if (utasks.length) sections.push({ title: 'مهام عاجلة / متأخرة', icon: 'alert', route: '#/tasks', items: utasks.map((x) => ({ title: x.title, sub: `${x.due_date ? 'حتى ' + x.due_date : ''}${x.project_name ? ' • ' + x.project_name : ''}`.trim(), route: '#/tasks' })) });
  if (events.length) sections.push({ title: 'مواعيد واجتماعات اليوم والقادم', icon: 'calendar', route: '#/calendar', items: events.map((x) => ({ title: x.title, sub: `${dOnly(x.start_at)} ${hm(x.start_at)}${x.location ? ' • ' + x.location : ''}`, route: x.kind === 'meeting' ? '#/meetings' : '#/calendar' })) });
  if (wait.followups.length + wait.tasks.length) sections.push({ title: 'أشخاص ينتظرون ردك', icon: 'users', route: '#/workcenter', items: [
    ...wait.followups.map((x) => ({ title: x.subject, sub: cName({ first_name: x.first_name, last_name: x.last_name }), route: '#/followups' })),
    ...wait.tasks.map((x) => ({ title: x.title, sub: cName({ first_name: x.first_name, last_name: x.last_name }) || 'بانتظار الرد', route: '#/tasks' })),
  ] });
  if (rem.length) sections.push({ title: 'تذكيرات قادمة', icon: 'bell', route: '#/notifications', items: rem.map((x) => ({ title: x.title, sub: String(x.remind_at).slice(0, 16).replace(' ', ' '), route: '#/today' })) });
  if (!sections.length) sections.push({ title: 'كل شيء تحت السيطرة', icon: 'check', route: '#/dashboard', items: [{ title: 'لا يوجد ما يحتاج انتباهك الآن', sub: 'استمتع بيومك', route: '#/' }] });
  const reply = sections.length <= 1
    ? 'لا يوجد ما يحتاج انتباهك الآن — كل الأعمال مرتبة.'
    : `إليك ما يحتاج انتباهك الآن: ${sections.map((s) => s.title).join('، ')}.`;
  return { reply, sections };
}

function chat(message) {
  const m = norm(message);
  const today = todayStr();

  // سؤال عن شخص بالاسم
  if (/حاله|ملف|تقرير|تواصل/.test(m)) {
    const c = matchContact(m);
    if (c) return { reply: contactSummary(c), sections: [{ title: `أعمال ${cName(c)}`, icon: 'user', route: `#/contacts/${c.id}`, items: contactTimeline(c) }] };
  }

  if (/متابعه|تابع|يستحق|استحق|متابعات/.test(m)) {
    const items = dueFollowups(15);
    return {
      reply: items.length ? `لديك ${items.length} متابعة مستحقة حتى اليوم (${today}).` : `لا توجد متابعات مستحقة حتى اليوم.`,
      sections: [{ title: 'المتابعات المستحقة', icon: 'target', route: '#/followups', items: items.map((x) => ({ title: x.subject, sub: `${cName({ first_name: x.first_name, last_name: x.last_name })} — ${dOnly(x.next_date)}`, route: '#/followups' })) }],
    };
  }

  if (/مهمه|مهام|واجب|مشوار|فرقه/.test(m) && /تاك|تأخر|متأخر|عاجل|عاجله|قائمه|قادم|اليوم|باقي/.test(m)) {
    const items = urgentTasks(15);
    return {
      reply: items.length ? `عندك ${items.length} مهمة عاجلة أو متأخرة تحتاج إنجازها.` : 'لا توجد مهام عاجلة أو متأخرة حاليًا.',
      sections: [{ title: 'مهام عاجلة ومتأخرة', icon: 'alert', route: '#/tasks', items: items.map((x) => ({ title: x.title, sub: `${x.due_date ? 'حتى ' + x.due_date : ''}${x.project_name ? ' • ' + x.project_name : ''}`.trim(), route: '#/tasks' })) }],
    };
  }

  if (/اجتماع|موعد|جلسه|مقابل/.test(m)) {
    const items = upcomingEvents(7, 12);
    return {
      reply: items.length ? `لديك ${items.length} اجتماع/موعد خلال الأيام القادمة.` : 'لا توجد اجتماعات أو مواعيد قادمة.',
      sections: [{ title: 'الاجتماعات والمواعيد القادمة', icon: 'calendar', route: '#/calendar', items: items.map((x) => ({ title: x.title, sub: `${dOnly(x.start_at)} ${hm(x.start_at)}${x.location ? ' • ' + x.location : ''}`, route: x.kind === 'meeting' ? '#/meetings' : '#/calendar' })) }],
    };
  }

  if (/ينتظر|لحد|بانتظار|لم يرد|لا يرد|بدون رد|رد علي|ترد/.test(m)) {
    const wait = waitingReplies(15);
    const items = [
      ...wait.followups.map((x) => ({ title: x.subject, sub: cName({ first_name: x.first_name, last_name: x.last_name }), route: '#/followups' })),
      ...wait.tasks.map((x) => ({ title: x.title, sub: 'مهمة بانتظار الرد', route: '#/tasks' })),
    ];
    return { reply: items.length ? `${items.length} أمرًا ينتظر ردك أو رد الطرف الآخر.` : 'لا أحد ينتظر ردك حاليًا.', sections: [{ title: 'بانتظار الرد', icon: 'users', route: '#/workcenter', items }] };
  }

  if (/مصروف|تكاليف|حساب|فلس|رسمه|دفعت/.test(m)) {
    const ex = monthExpenses();
    return {
      reply: `مصروفات هذا الشهر حتى الآن: ${ex.total} (عدد ${ex.count}).`,
      sections: [{ title: 'مصروفات هذا الشهر حسب التصنيف', icon: 'dollar', route: '#/expenses', items: ex.byCategory.map((x) => ({ title: x.category, sub: `${x.total} — ${x.n} عملية`, route: '#/expenses' })) }],
    };
  }

  if (/تذكير|تذكيرات|ذكري/.test(m)) {
    const items = pendingReminders(12);
    return { reply: items.length ? `${items.length} تذكير قادم.` : 'لا توجد تذكيرات قادمة.', sections: [{ title: 'التذكيرات القادمة', icon: 'bell', route: '#/notifications', items: items.map((x) => ({ title: x.title, sub: String(x.remind_at).slice(0, 16).replace(' ', ' '), route: '#/today' })) }] };
  }

  if (/مشروع|مشاريع/.test(m)) {
    const rows = q.all(`SELECT p.*, (SELECT COUNT(*) c FROM tasks t WHERE t.project_id=p.id AND t.deleted_at IS NULL AND t.status NOT IN ('completed','cancelled')) open_tasks
      FROM projects p WHERE p.deleted_at IS NULL AND p.status='active' ORDER BY p.due_date`);
    return {
      reply: rows.length ? `${rows.length} مشروع نشط.` : 'لا توجد مشاريع نشطة.',
      sections: [{ title: 'المشاريع النشطة', icon: 'briefcase', route: '#/projects', items: rows.map((x) => ({ title: x.name, sub: `إنجاز ${x.progress}% — ${x.open_tasks} مهام مفتوحة`, route: `#/projects/${x.id}` })) }],
    };
  }

  if (/ملف|مستند|عقد|فاصطوره|فوتيره/.test(m)) {
    const rows = q.all('SELECT * FROM files WHERE deleted_at IS NULL ORDER BY created_at DESC LIMIT 10');
    return { reply: rows.length ? `${rows.length} من أحدث الملفات.` : 'لا توجد ملفات.', sections: [{ title: 'أحدث الملفات', icon: 'file', route: '#/files', items: rows.map((x) => ({ title: x.original_name, sub: x.category, route: '#/files' })) }] };
  }

  if (/انتاجيه|تقرير|اداء|اكملت|انجزت/.test(m)) {
    const rows = last7Productivity();
    const done = rows.reduce((s, x) => s + x.done, 0);
    return { reply: `أنجزت ${done} مهمة خلال آخر 7 أيام.`, sections: [{ title: 'الإنتاجية (آخر 7 أيام)', icon: 'chart', route: '#/reports', items: rows.map((x) => ({ title: x.date, sub: `${x.done} مكتملة • ${x.created} جديدة`, route: '#/reports' })) }] };
  }

  if (/صباح|مساء|مرحبا|هلا|ازيك|ايك|كيفك|ملخص|اليوم|نبض/.test(m)) return buildDaily();

  // افتراضي: ملخص قصير + اقتراحات
  const d = buildDaily();
  d.reply = 'يمكنني مساعدتك بأسئلة مثل: "ما المتابعات المستحقة؟" — أو "ما المهام العاجلة؟" — أو "من ينتظر ردّي؟" — أو "حالة أحمد". ' + d.reply;
  return d;
}

// استخراج مهام من نص (محضر اجتماع / ملاحظة)
function extractTasks(text) {
  const lines = String(text || '').split(/\n+/).map((l) => l.trim().replace(/^[\-•*،,.\d)\]]+\s*/, '')).filter((l) => l.length >= 4 && l.length <= 120);
  const keep = (l) => /يجب|علي|عليه|تتم|تم الاتفا|الاتفاق|سنقوم|ساقوم|اقتراح|تسليم|ارسال|اعتماد|مراجعه|متابعه|تجهيز|اعداد|توقيع|دفع|حجز|تحديد/.test(l) || l.length >= 8;
  const today = todayStr();
  const out = [];
  for (const l of lines) {
    if (!keep(l)) continue;
    let due = null;
    if (/غد|الغد|بكره/.test(l)) due = addDays(today, 1);
    else if (/بعد يومين/.test(l)) due = addDays(today, 2);
    else if (/اسبوع/.test(l)) due = addDays(today, 7);
    const c = matchContact(l);
    out.push({ text: l.replace(/[.]+$/, '').trim(), due_date: due, contact_id: c ? c.id : null, suggested_contact: c ? cName(c) : null });
    if (out.length >= 15) break;
  }
  return out;
}

function summarize(scope, id) {
  const today = todayStr();
  if (scope === 'day') {
    const done = q.get(`SELECT COUNT(*) c FROM tasks WHERE deleted_at IS NULL AND status='completed' AND date(completed_at)=?`, today).c;
    const open = q.get(`SELECT COUNT(*) c FROM tasks WHERE deleted_at IS NULL AND status NOT IN ('completed','cancelled')`, today).c;
    const ev = upcomingEvents(0, 50).length;
    const fups = dueFollowups(50).length;
    return { title: 'ملخص اليوم', text: `أنجزت ${done} مهمة اليوم، وما زالت ${open} مهمة مفتوحة. لديك ${ev} مواعيد واجتماعات، و${fups} متابعة مستحقة.`, stats: [{ label: 'مهام مكتملة اليوم', value: done }, { label: 'مهام مفتوحة', value: open }, { label: 'مواعيد اليوم', value: ev }, { label: 'متابعات مستحقة', value: fups }] };
  }
  if (scope === 'contact') {
    const c = q.get('SELECT * FROM contacts WHERE id=? AND deleted_at IS NULL', id);
    if (!c) throw new Error('الشخص غير موجود');
    return { title: `ملخص ${cName(c)}`, text: contactSummary(c).replace(/^ملخص التواصل مع[^:]*:\n?/, ''), stats: [] };
  }
  if (scope === 'project') {
    const p = q.get('SELECT * FROM projects WHERE id=? AND deleted_at IS NULL', id);
    if (!p) throw new Error('المشروع غير موجود');
    const total = q.get(`SELECT COUNT(*) c FROM tasks WHERE project_id=? AND deleted_at IS NULL`, id).c;
    const done = q.get(`SELECT COUNT(*) c FROM tasks WHERE project_id=? AND deleted_at IS NULL AND status='completed'`, id).c;
    const exp = q.get(`SELECT COALESCE(SUM(amount),0) t FROM expenses WHERE project_id=? AND deleted_at IS NULL`, id).t;
    const next = q.get(`SELECT * FROM meetings WHERE project_id=? AND status='scheduled' AND date(start_at)>=? AND deleted_at IS NULL ORDER BY start_at LIMIT 1`, id, today);
    return { title: `ملخص مشروع «${p.name}»`, text: `إنجاز ${p.progress}% — ${done} من ${total} مهمة مكتملة. مصروفات مسجلة: ${exp}. ${next ? `الاجتماع القادم: ${next.title} في ${dOnly(next.start_at)}.` : 'لا اجتماعات قادمة.'}`, stats: [{ label: 'نسبة الإنجاز', value: p.progress + '%' }, { label: 'مهام مكتملة', value: `${done}/${total}` }, { label: 'المصروفات', value: exp }] };
  }
  throw new Error('نوع الملخص غير معروف');
}

module.exports = { chat, extractTasks, summarize, buildDaily };
