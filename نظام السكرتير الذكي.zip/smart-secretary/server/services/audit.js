'use strict';
// سجل العمليات (Audit Log)
const { q } = require('../db');
const { nowStr } = require('../time');

function log(user, action, entity, entityId, details) {
  try {
    q.run(
      'INSERT INTO activity_logs (user_id, action, entity, entity_id, details, created_at) VALUES (?,?,?,?,?,?)',
      user ? user.id : null, action, entity || null, entityId || null, details || null, nowStr()
    );
  } catch (e) {
    console.error('audit log failed', e.message);
  }
}

module.exports = { log };
